<?php 
if(!session_id()){
	session_start();
}
require("config/db.php");
$title = "My room";
require("layout/head.php"); // $title = "page title"

if(checkUserSession($db) !== True){
	header("location: $_LOGIN_FILE");exit; //$_LOGIN_FILE --> /config/value.php
}

$user = searchUser_bSession($db, $_COOKIE["user_session"]);
$myRoomMenu = "active";
$userName = $user["firstName"] . " " . $user["lastName"];
$profilePicture = $user["profilePicture"] ?? "default-avatar.png";
$inLogin = true;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Rooms</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<style>
    .notification-badge {
        animation: pulse 2s infinite;
    }

    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.1); }
        100% { transform: scale(1); }
    }

    .custom-scrollbar {
        scrollbar-width: thin;
        scrollbar-color: rgba(156, 163, 175, 0.5) transparent;
    }

    .custom-scrollbar::-webkit-scrollbar {
        width: 6px;
    }

    .custom-scrollbar::-webkit-scrollbar-track {
        background: transparent;
    }

    .custom-scrollbar::-webkit-scrollbar-thumb {
        background-color: rgba(156, 163, 175, 0.5);
        border-radius: 3px;
    }

    /* Room card hover effect */
    .room-card {
        transition: all 0.3s ease;
    }

    .room-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    }

    /* Toast notifications */
    .toast-notification {
        animation: slideIn 0.3s ease forwards;
    }

    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    /* Pagination */
    .pagination-item {
        transition: all 0.2s ease;
    }

    .pagination-item:hover:not(.disabled) {
        background-color: #EFF6FF;
    }
</style>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-10">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="home.php" class="flex items-center">
                        <i class="fas fa-comments text-blue-600 text-2xl mr-2"></i>
                        <span class="text-xl font-bold text-gray-800">VN</span>
                    </a>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <button onclick="toggleNotifications()" class="text-gray-600 hover:text-gray-800">
                            <i class="fas fa-bell"></i>
                            <span class="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 text-xs flex items-center justify-center">2</span>
                        </button>
                    </div>
                    <div class="relative group">
                        <button class="flex items-center space-x-2">
                            <img src="<?php echo $profilePicture; ?>" 
                                 alt="Profile" 
                                 class="w-8 h-8 rounded-full">
                            <span class="text-gray-700"><?php echo htmlspecialchars($userName); ?></span>
                        </button>
                        <div class="absolute right-0 w-48 mt-2 bg-white rounded-md shadow-lg hidden group-hover:block">
                            <a href="account.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-user mr-2"></i> Account
                            </a>
                            <a href="create_room.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-plus mr-2"></i> Create Room
                            </a>
                            <a href="my_room.php" class="block px-4 py-2 text-gray-700 bg-gray-100">
                                <i class="fas fa-th-large mr-2"></i> My Rooms
                            </a>
                            <?php if(isset($isAdmin) && $isAdmin): ?>
                            <a href="secret_admin.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-cogs mr-2"></i> Admin Area
                            </a>
                            <?php endif; ?>
                            <a href="<?= $_LOGOUT_FILE ?? 'logout.php' ?>" class="block px-4 py-2 text-red-600 hover:bg-gray-100">
                                <i class="fas fa-sign-out-alt mr-2"></i> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="flex min-h-screen pt-16">
        <!-- Sidebar -->
        <div class="w-64 bg-white shadow-lg fixed h-full">
            <div class="p-4">
                <div class="flex items-center mb-6">
                    <img src="<?php echo $profilePicture; ?>" alt="Profile" class="w-10 h-10 rounded-full mr-3">
                    <div>
                        <h3 class="font-medium text-gray-800"><?php echo htmlspecialchars($userName); ?></h3>
                        <span class="text-xs text-gray-500">Member</span>
                    </div>
                </div>
                <h2 class="text-xl font-semibold text-gray-800 mb-4">Menu</h2>
                <ul class="space-y-2">
                    <li>
                        <a href="<?= $_HOME_FILE ?? 'home.php' ?>" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-home"></i>
                            <span>Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="account.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-user"></i>
                            <span>Account</span>
                        </a>
                    </li>
                    <li>
                        <a href="create_room.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-plus"></i>
                            <span>Create Room</span>
                        </a>
                    </li>
                    <li>
                        <a href="my_room.php" class="flex items-center space-x-2 p-2 rounded-lg bg-blue-50 text-blue-600">
                            <i class="fas fa-th-large"></i>
                            <span>My Room</span>
                        </a>
                    </li>
                    <?php if(isset($isAdmin) && $isAdmin): ?>
                    <li>
                        <a href="secret_admin.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-cogs"></i>
                            <span>Admin Area</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li>
                        <a href="<?= $_LOGOUT_FILE ?? 'logout.php' ?>" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-red-50 text-red-600">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="flex-1 ml-64 p-8">
            <!-- Page Header -->
            <div class="mb-6">
                <h1 class="text-2xl font-bold text-gray-800">My Rooms</h1>
                <div class="text-sm breadcrumbs">
                    <ul class="flex space-x-2 text-gray-500">
                        <li><a href="<?= $_HOME_FILE ?>" class="text-gray-500 hover:text-blue-600">Home</a></li>
                        <li class="text-blue-600">My Rooms</li>
                    </ul>
                </div>
            </div>

            <!-- Rooms I Own Section -->
            <div class="bg-white rounded-lg shadow-sm p-6 mb-8">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-lg font-semibold">Rooms I Own</h2>
                    <a href="create_room.php" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200 text-sm flex items-center">
                        <i class="fas fa-plus mr-2"></i> Create New Room
                    </a>
                </div>
                
                <div class="space-y-4">
                    <?php
                    if($_GET['room_page'] == null)
                        $_GET['room_page'] = 1;
                    if($_GET['room_page'] >= 2)
                        $room_pages = ($_GET['room_page'] - 1) * 5;
                    else
                        $room_pages = 0;
                                            
                    $query = mysqli_query($db, "select * from chat_room where owner = {$user["id"]} LIMIT 5 OFFSET {$room_pages}") or error("Can't get room data", $_HOME_FILE);
                    
                    if(mysqli_num_rows($query) < 1): ?>
                        <div class="text-center py-8">
                            <div class="w-16 h-16 bg-blue-100 rounded-full mx-auto flex items-center justify-center mb-4">
                                <i class="fas fa-comment-slash text-blue-600 text-2xl"></i>
                            </div>
                            <h3 class="text-gray-500 font-medium mb-2">No Rooms Created Yet</h3>
                            <p class="text-gray-400 mb-4">You haven't created any rooms yet. Create your first one now!</p>
                            <a href="create_room.php" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200 inline-flex items-center">
                                <i class="fas fa-plus mr-2"></i> Create Room
                            </a>
                        </div>
                    <?php else: ?>
                        <?php while($room = mysqli_fetch_array($query)): ?>
                            <div class="border rounded-lg room-card overflow-hidden" id="room-<?= $room["room_id"] ?>">
                                <div class="bg-gray-50 px-4 py-3 border-b flex justify-between items-center">
                                    <h3 class="font-medium text-gray-800"><?= htmlspecialchars($room["room_name"]) ?></h3>
                                    <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">Owner</span>
                                </div>
                                <div class="p-4">
                                    <p class="text-gray-600 mb-4">
                                        <span class="font-medium">Description:</span> 
                                        <?= !empty($room["room_description"]) ? htmlspecialchars($room["room_description"]) : "No description provided"; ?>
                                    </p>
                                    <div class="flex flex-wrap gap-2">
                                        <a href="<?= $_CHAT_FILE ?>?room_id=<?= $room["room_id"] ?>" class="px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition duration-200 text-sm flex items-center">
                                            <i class="fas fa-sign-in-alt mr-2"></i> Enter Room
                                        </a>
                                        <button onclick="delete_room(<?= $room["room_id"] ?>)" class="px-3 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition duration-200 text-sm flex items-center">
                                            <i class="fas fa-trash-alt mr-2"></i> Delete Room
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    
                        <?php
                        $query1 = mysqli_query($db, "select * from chat_room where owner = {$user["id"]}") or error("Can't get room data", $_HOME_FILE);
                        
                        $n = mysqli_num_rows($query1) / 5;							
                        if(mysqli_num_rows($query1) % 5 > 0)
                            $n+=1;
                        $n = (int) $n;
                        ?>
                        
                        <!-- Pagination -->
                        <div class="flex justify-center mt-6">
                            <nav class="flex" aria-label="Pagination">
                                <a href="my_room.php?room_page=1" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['room_page'] == 1) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                    <span class="sr-only">First</span>
                                    <i class="fas fa-angle-double-left"></i>
                                </a>
                                <a href="my_room.php?room_page=<?php echo ($_GET['room_page']-1 > 0) ? $_GET['room_page']-1 : 1; ?>" class="relative inline-flex items-center px-2 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['room_page'] == 1) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                    <span class="sr-only">Previous</span>
                                    <i class="fas fa-angle-left"></i>
                                </a>
                                
                                <?php for($i = 1; $i <= $n; $i++): ?>
                                <a href="my_room.php?room_page=<?php echo $i ?>" class="relative inline-flex items-center px-4 py-2 border border-gray-300 <?php echo ($_GET['room_page'] == $i) ? 'bg-blue-50 text-blue-600 border-blue-300' : 'bg-white text-gray-500'; ?> text-sm font-medium hover:bg-gray-50">
                                    <?php echo $i ?>
                                </a>
                                <?php endfor; ?>
                                
                                <a href="my_room.php?room_page=<?php echo ($_GET['room_page']+1 <= $n) ? $_GET['room_page']+1 : $_GET['room_page']; ?>" class="relative inline-flex items-center px-2 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['room_page'] >= $n) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                    <span class="sr-only">Next</span>
                                    <i class="fas fa-angle-right"></i>
                                </a>
                                <a href="my_room.php?room_page=<?php echo $n ?>" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['room_page'] >= $n) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                    <span class="sr-only">Last</span>
                                    <i class="fas fa-angle-double-right"></i>
                                </a>
                            </nav>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Rooms I've Joined Section -->
            <div class="bg-white rounded-lg shadow-sm p-6">
                <h2 class="text-lg font-semibold mb-6">Rooms I've Joined</h2>
                
                <div class="space-y-4">
                    <?php
                    if($_GET['room_joined'] == null)
                        $_GET['room_joined'] = 1;
                    if($_GET['room_joined'] >= 2)
                        $room_joined = ($_GET['room_joined'] - 1) * 5;
                    else
                        $room_joined = 0;
                                            
                    $query = mysqli_query($db, "select * from room_member where user_id = {$user["id"]} ORDER BY join_date DESC LIMIT 5 OFFSET {$room_joined}") or error("Can't get member data", $_HOME_FILE);
                    
                    if(mysqli_num_rows($query) < 1): ?>
                        <div class="text-center py-8">
                            <div class="w-16 h-16 bg-purple-100 rounded-full mx-auto flex items-center justify-center mb-4">
                                <i class="fas fa-user-friends text-purple-600 text-2xl"></i>
                            </div>
                            <h3 class="text-gray-500 font-medium mb-2">No Rooms Joined</h3>
                            <p class="text-gray-400 mb-4">You haven't joined any rooms yet. Start by joining a room or creating your own!</p>
                            <a href="<?= $_HOME_FILE ?>" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200 inline-flex items-center">
                                <i class="fas fa-search mr-2"></i> Find Rooms
                            </a>
                        </div>
                    <?php else: ?>
                        <?php while($mem = mysqli_fetch_array($query)): 
                        $room_query = mysqli_query($db, "select * from chat_room where room_id = {$mem["room_id"]}") or error("Can't get room data", $_HOME_FILE);
                        $room = mysqli_fetch_array($room_query);
                        ?>
                            <div class="border rounded-lg room-card overflow-hidden" id="joined-room-<?= $room["room_id"] ?>">
                                <div class="bg-gray-50 px-4 py-3 border-b flex justify-between items-center">
                                    <h3 class="font-medium text-gray-800"><?= htmlspecialchars($room["room_name"]) ?></h3>
                                    <span class="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded-full">Joined <?= format_time_ago(strtotime($mem["join_date"])) ?></span>
                                </div>
                                <div class="p-4">
                                    <p class="text-gray-600 mb-4">
                                        <span class="font-medium">Description:</span> 
                                        <?= !empty($room["room_description"]) ? htmlspecialchars($room["room_description"]) : "No description provided"; ?>
                                    </p>
                                    <a href="<?= $_CHAT_FILE ?>?room_id=<?= $room["room_id"] ?>" class="px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition duration-200 text-sm inline-flex items-center">
                                        <i class="fas fa-sign-in-alt mr-2"></i> Enter Room
                                    </a>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    
                        <?php
                        $query1 = mysqli_query($db, "select * from room_member where user_id = {$user["id"]}") or error("Can't get room data", $_HOME_FILE);
                        
                        $n = mysqli_num_rows($query1) / 5;							
                        if(mysqli_num_rows($query1) % 5 > 0)
                            $n+=1;
                        $n = (int) $n;
                        ?>
                        
                        <!-- Pagination -->
                        <div class="flex justify-center mt-6">
                            <nav class="flex" aria-label="Pagination">
                                <a href="my_room.php?room_joined=1" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['room_joined'] == 1) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                    <span class="sr-only">First</span>
                                    <i class="fas fa-angle-double-left"></i>
                                </a>
                                <a href="my_room.php?room_joined=<?php echo ($_GET['room_joined']-1 > 0) ? $_GET['room_joined']-1 : 1; ?>" class="relative inline-flex items-center px-2 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['room_joined'] == 1) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                    <span class="sr-only">Previous</span>
                                    <i class="fas fa-angle-left"></i>
                                </a>
                                
                                <?php for($i = 1; $i <= $n; $i++): ?>
                                <a href="my_room.php?room_joined=<?php echo $i ?>" class="relative inline-flex items-center px-4 py-2 border border-gray-300 <?php echo ($_GET['room_joined'] == $i) ? 'bg-blue-50 text-blue-600 border-blue-300' : 'bg-white text-gray-500'; ?> text-sm font-medium hover:bg-gray-50">
                                    <?php echo $i ?>
                                </a>
                                <?php endfor; ?>
                                
                                <a href="my_room.php?room_joined=<?php echo ($_GET['room_joined']+1 <= $n) ? $_GET['room_joined']+1 : $_GET['room_joined']; ?>" class="relative inline-flex items-center px-2 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['room_joined'] >= $n) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                    <span class="sr-only">Next</span>
                                    <i class="fas fa-angle-right"></i>
                                </a>
                                <a href="my_room.php?room_joined=<?php echo $n ?>" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['room_joined'] >= $n) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                    <span class="sr-only">Last</span>
                                    <i class="fas fa-angle-double-right"></i>
                                </a>
                            </nav>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Notification Modal -->
    <div id="notificationModal" class="fixed right-0 mt-16 mr-4 w-80 bg-white rounded-lg shadow-xl hidden z-50">
        <div class="p-4 border-b">
            <h3 class="text-lg font-semibold">Notifications</h3>
        </div>
        <div class="max-h-96 overflow-y-auto">
            <div class="p-4 border-b hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                            <i class="fas fa-comment text-blue-600"></i>
                        </div>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium">New message in Study Group</p>
                        <p class="text-sm text-gray-500">John posted a new message</p>
                        <p class="text-xs text-gray-400 mt-1">2 hours ago</p>
                    </div>
                </div>
            </div>
            <div class="p-4 border-b hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                            <i class="fas fa-user-plus text-green-600"></i>
                        </div>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium">New member joined</p>
                        <p class="text-sm text-gray-500">Sarah joined your Math Help room</p>
                        <p class="text-xs text-gray-400 mt-1">5 hours ago</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="p-4 border-t">
            <a href="notifications.php" class="text-sm text-blue-600 hover:text-blue-800">View all notifications</a>
        </div>
    </div>

    <!-- Delete Room Confirmation Modal -->
    <div id="deleteRoomModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50 flex items-center justify-center">
        <div class="bg-white rounded-lg max-w-md w-full p-6 text-center">
            <div class="w-16 h-16 mx-auto mb-4 flex items-center justify-center bg-red-100 rounded-full">
                <i class="fas fa-exclamation-triangle text-red-600 text-2xl"></i>
            </div>
            <h3 class="text-lg font-bold text-gray-900 mb-2">Delete Room</h3>
            <p class="text-gray-500 mb-6">Are you sure you want to delete this room? This action cannot be undone and all chat history will be permanently deleted.</p>
            <div class="flex justify-center space-x-4">
                <button id="cancelDeleteBtn" class="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition duration-200">
                    Cancel
                </button>
                <button id="confirmDeleteBtn" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition duration-200">
                    Yes, Delete Room
                </button>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery-3.1.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins/toastr/toastr.min.js"></script>
    <script src="assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="assets/js/inspinia.js"></script>
    <script src="assets/js/plugins/pace/pace.min.js"></script>

    <script>
// Notification functionality
function toggleNotifications() {
    const modal = document.getElementById('notificationModal');
    modal.classList.toggle('hidden');
}

// Close notification modal when clicking outside
window.onclick = function(event) {
    const notificationModal = document.getElementById('notificationModal');
    const deleteRoomModal = document.getElementById('deleteRoomModal');
    
    if (!event.target.closest('#notificationModal') && 
        !event.target.closest('button[onclick="toggleNotifications()"]')) {
        notificationModal.classList.add('hidden');
    }
    
    if (event.target === deleteRoomModal) {
        deleteRoomModal.classList.add('hidden');
        roomToDelete = null;
    }
}

// Room deletion handling
let roomToDelete = null;

function delete_room(room_id) {
    roomToDelete = room_id;
    document.getElementById('deleteRoomModal').classList.remove('hidden');
}

// Cancel button for delete modal
document.getElementById('cancelDeleteBtn').addEventListener('click', function() {
    document.getElementById('deleteRoomModal').classList.add('hidden');
    roomToDelete = null;
});

// Confirm button for delete modal
document.getElementById('confirmDeleteBtn').addEventListener('click', function() {
    if (roomToDelete) {
        // Keep the original AJAX functionality
        $.ajax({
            url: "ajax/request/delete_room.php",
            type: "POST",
            data: {
                room_id: roomToDelete
            },
            dataType: 'json',
            beforeSend: function () {
                document.getElementById('confirmDeleteBtn').innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Deleting...';
                document.getElementById('confirmDeleteBtn').disabled = true;
            },
            success: function(r) {
                if(r.success){
                    $("#room-" + roomToDelete).remove();
                    toastr.success(r.message);
                } else {
                    toastr.error(r.message);
                }
            },
            error: function(){
                toastr.error("Unknown error occurred!");
            },
            complete: function(){
                document.getElementById('deleteRoomModal').classList.add('hidden');
                document.getElementById('confirmDeleteBtn').innerHTML = 'Yes, Delete Room';
                document.getElementById('confirmDeleteBtn').disabled = false;
                roomToDelete = null;
            }
        });
    }
});

// Template selection functionality for create room if needed
document.querySelectorAll('.room-template').forEach(template => {
    template.addEventListener('click', function() {
        const name = this.getAttribute('data-name');
        const description = this.getAttribute('data-description');
        
        // If we're on the create room page and these fields exist
        const nameField = document.getElementById('room_name');
        const descField = document.getElementById('room_desc');
        
        if (nameField && descField) {
            nameField.value = name;
            descField.value = description;
        }
    });
});
</script>
</body>
</html>