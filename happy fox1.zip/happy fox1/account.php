<?php 
if(!session_id()){
	session_start();
}
require("config/db.php");
$title = "My account";
require("layout/head.php"); // $title = "page title"

if(checkUserSession($db) !== True){
	header("location: $_LOGIN_FILE");exit; //$_LOGIN_FILE --> /config/value.php
}

$user = searchUser_bSession($db, $_COOKIE["user_session"]);
$accountMenu = "active";
$userName = $user["firstName"] . " " . $user["lastName"];
$profilePicture = $user["profilePicture"] ?? "default-avatar.png";
$inLogin = true;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<style>
    .notification-badge {
        animation: pulse 2s infinite;
    }

    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.1); }
        100% { transform: scale(1); }
    }

    /* Custom scrollbar */
    .custom-scrollbar {
        scrollbar-width: thin;
        scrollbar-color: rgba(156, 163, 175, 0.5) transparent;
    }

    .custom-scrollbar::-webkit-scrollbar {
        width: 6px;
    }

    .custom-scrollbar::-webkit-scrollbar-track {
        background: transparent;
    }

    .custom-scrollbar::-webkit-scrollbar-thumb {
        background-color: rgba(156, 163, 175, 0.5);
        border-radius: 3px;
    }

    /* Form focus effects */
    .form-input:focus {
        box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.5);
        outline: none;
    }

    /* Toast notifications */
    .toast-notification {
        animation: slideIn 0.3s ease forwards;
    }

    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
</style>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-10">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="home.php" class="flex items-center">
                        <i class="fas fa-comments text-blue-600 text-2xl mr-2"></i>
                        <span class="text-xl font-bold text-gray-800">VN</span>
                    </a>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <button onclick="toggleNotifications()" class="text-gray-600 hover:text-gray-800">
                            <i class="fas fa-bell"></i>
                            <span class="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 text-xs flex items-center justify-center">2</span>
                        </button>
                    </div>
                    <div class="relative group">
                        <button class="flex items-center space-x-2">
                            <img src="<?php echo $profilePicture; ?>" 
                                 alt="Profile" 
                                 class="w-8 h-8 rounded-full">
                            <span class="text-gray-700"><?php echo htmlspecialchars($userName); ?></span>
                        </button>
                        <div class="absolute right-0 w-48 mt-2 bg-white rounded-md shadow-lg hidden group-hover:block">
                            <a href="account.php" class="block px-4 py-2 text-gray-700 bg-gray-100">
                                <i class="fas fa-user mr-2"></i> Account
                            </a>
                            <a href="create_room.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-plus mr-2"></i> Create Room
                            </a>
                            <a href="my_room.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-th-large mr-2"></i> My Rooms
                            </a>
                            <?php if(isset($isAdmin) && $isAdmin): ?>
                            <a href="secret_admin.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-cogs mr-2"></i> Admin Area
                            </a>
                            <?php endif; ?>
                            <a href="<?= $_LOGOUT_FILE ?? 'logout.php' ?>" class="block px-4 py-2 text-red-600 hover:bg-gray-100">
                                <i class="fas fa-sign-out-alt mr-2"></i> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="flex min-h-screen pt-16">
        <!-- Sidebar -->
        <div class="w-64 bg-white shadow-lg fixed h-full">
            <div class="p-4">
                <div class="flex items-center mb-6">
                    <img src="<?php echo $profilePicture; ?>" alt="Profile" class="w-10 h-10 rounded-full mr-3">
                    <div>
                        <h3 class="font-medium text-gray-800"><?php echo htmlspecialchars($userName); ?></h3>
                        <span class="text-xs text-gray-500">Member</span>
                    </div>
                </div>
                <h2 class="text-xl font-semibold text-gray-800 mb-4">Menu</h2>
                <ul class="space-y-2">
                    <li>
                        <a href="<?= $_HOME_FILE ?? 'home.php' ?>" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-home"></i>
                            <span>Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="account.php" class="flex items-center space-x-2 p-2 rounded-lg bg-blue-50 text-blue-600">
                            <i class="fas fa-user"></i>
                            <span>Account</span>
                        </a>
                    </li>
                    <li>
                        <a href="create_room.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-plus"></i>
                            <span>Create Room</span>
                        </a>
                    </li>
                    <li>
                        <a href="my_room.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-th-large"></i>
                            <span>My Room</span>
                        </a>
                    </li>
                    <?php if(isset($isAdmin) && $isAdmin): ?>
                    <li>
                        <a href="secret_admin.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-cogs"></i>
                            <span>Admin Area</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li>
                        <a href="<?= $_LOGOUT_FILE ?? 'logout.php' ?>" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-red-50 text-red-600">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="flex-1 ml-64 p-8">
            <!-- Page Header -->
            <div class="mb-6">
                <h1 class="text-2xl font-bold text-gray-800">My Account</h1>
                <div class="text-sm breadcrumbs">
                    <ul class="flex space-x-2 text-gray-500">
                        <li class="text-blue-600">Account</li>
                    </ul>
                </div>
            </div>

            <!-- Profile Picture Section -->
            <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
                <h2 class="text-lg font-semibold mb-4">Change Profile Picture</h2>
                
                <form id="change_picture" class="space-y-4">
                    <div class="flex flex-col md:flex-row items-start md:items-center space-y-2 md:space-y-0 md:space-x-4">
                        <label for="profile_picture" class="w-full md:w-auto text-gray-700 font-medium">Image URL</label>
                        <div class="flex-1 w-full">
                            <input type="text" id="profile_picture" name="profile_picture" value="<?= $profilePicture ?>" 
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200 form-input">
                        </div>
                    </div>
                    
                    <div class="flex items-center justify-between mt-4">
                        <p class="text-sm text-gray-500">You will be banned if using sensitive image/picture.</p>
                        <button id="cppbtn" type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200">
                            Change
                        </button>
                    </div>
                </form>
            </div>

            <!-- Change Name Section -->
            <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
                <h2 class="text-lg font-semibold mb-4">Change Name</h2>
                
                <form id="change_name" class="space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="firstName" class="block text-gray-700 font-medium mb-2">First Name</label>
                            <input type="text" id="firstName" name="firstName" value="<?= $user["firstName"]; ?>" 
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200 form-input">
                        </div>
                        <div>
                            <label for="lastName" class="block text-gray-700 font-medium mb-2">Last Name</label>
                            <input type="text" id="lastName" name="lastName" value="<?= $user["lastName"]; ?>" 
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200 form-input">
                        </div>
                    </div>
                    
                    <div class="flex justify-end mt-4">
                        <button id="cgnbtn" type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200">
                            Change
                        </button>
                    </div>
                </form>
            </div>

            <!-- Change Password Section -->
            <div class="bg-white rounded-lg shadow-sm p-6">
                <h2 class="text-lg font-semibold mb-4">Change Password</h2>
                
                <form id="change_password" class="space-y-4">
                    <div>
                        <label for="cr_password" class="block text-gray-700 font-medium mb-2">Current Password</label>
                        <input type="password" id="cr_password" name="cr_password" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200 form-input">
                    </div>
                    
                    <div>
                        <label for="nw_password" class="block text-gray-700 font-medium mb-2">New Password</label>
                        <input type="password" id="nw_password" name="nw_password" 
                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200 form-input">
                    </div>
                    
                    <div class="flex justify-end mt-4">
                        <button id="cgpbtn" type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200">
                            Change
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Notification Modal -->
    <div id="notificationModal" class="fixed right-0 mt-16 mr-4 w-80 bg-white rounded-lg shadow-xl hidden z-50">
        <div class="p-4 border-b">
            <h3 class="text-lg font-semibold">Notifications</h3>
        </div>
        <div class="max-h-96 overflow-y-auto">
            <div class="p-4 border-b hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                            <i class="fas fa-comment text-blue-600"></i>
                        </div>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium">New message in Study Group</p>
                        <p class="text-sm text-gray-500">John posted a new message</p>
                        <p class="text-xs text-gray-400 mt-1">2 hours ago</p>
                    </div>
                </div>
            </div>
            <div class="p-4 border-b hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                            <i class="fas fa-user-plus text-green-600"></i>
                        </div>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium">Profile update complete</p>
                        <p class="text-sm text-gray-500">Your profile has been updated successfully</p>
                        <p class="text-xs text-gray-400 mt-1">5 hours ago</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="p-4 border-t">
            <a href="notifications.php" class="text-sm text-blue-600 hover:text-blue-800">View all notifications</a>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery-3.1.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins/toastr/toastr.min.js"></script>
    <script src="assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="assets/js/inspinia.js"></script>
    <script src="assets/js/plugins/pace/pace.min.js"></script>

    <script>
    function toggleNotifications() {
        const modal = document.getElementById('notificationModal');
        modal.classList.toggle('hidden');
    }

    // Close notification modal when clicking outside
    window.onclick = function(event) {
        const notificationModal = document.getElementById('notificationModal');
        
        if (!event.target.closest('#notificationModal') && 
            !event.target.closest('button[onclick="toggleNotifications()"]')) {
            notificationModal.classList.add('hidden');
        }
    }
    
    // Keep the original Ajax form handling
    $("#change_picture").on('submit',(function(e) {
        e.preventDefault();
        $.ajax({
            url: "ajax/request/account/change_picture.php",
            type: "POST",
            data: new FormData(this),
            dataType: 'json',
            contentType: false,
            cache: false,
            processData: false,
            beforeSend: function () {
                $('#cppbtn').text('Processing...').prop('disabled', true)
            },
            success: function(r) {
                if(r.success){
                    toastr.success(r.message)
                } else {
                    toastr.error(r.message)
                }
            },
            error: function(){
                toastr.error("An error occurred. Please try again.")
            },
            complete: function(){
                $('#cppbtn').text('Change').prop('disabled', false)
            }
        });
    }));

    $("#change_password").on('submit',(function(e) {
        e.preventDefault();
        $.ajax({
            url: "ajax/request/account/change_password.php",
            type: "POST",
            data: new FormData(this),
            dataType: 'json',
            contentType: false,
            cache: false,
            processData: false,
            beforeSend: function () {
                $('#cgpbtn').text('Processing...').prop('disabled', true)
            },
            success: function(r) {
                if(r.success){
                    toastr.success(r.message)
                } else {
                    toastr.error(r.message)
                }
            },
            error: function(){
                toastr.error("An error occurred. Please try again.")
            },
            complete: function(){
                $('#cgpbtn').text('Change').prop('disabled', false)
            }
        });
    }));

    $("#change_name").on('submit',(function(e) {
        e.preventDefault();
        $.ajax({
            url: "ajax/request/account/change_name.php",
            type: "POST",
            data: new FormData(this),
            dataType: 'json',
            contentType: false,
            cache: false,
            processData: false,
            beforeSend: function () {
                $('#cgnbtn').text('Processing...').prop('disabled', true)
            },
            success: function(r) {
                if(r.success){
                    toastr.success(r.message)
                } else {
                    toastr.error(r.message)
                }
            },
            error: function(){
                toastr.error("An error occurred. Please try again.")
            },
            complete: function(){
                $('#cgnbtn').text('Change').prop('disabled', false)
            }
        });
    }));
    </script>
</body>
</html>