<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session
if (!session_id()) {
    session_start();
}

// Database connection
require("config/db.php");

// Check user authentication
if (!isset($_COOKIE["user_session"])) {
    header("Location: login.php");
    exit;
}

// Fetch user data
$user = searchUser_bSession($db, $_COOKIE["user_session"]);
if (!$user) {
    header("Location: login.php");
    exit;
}

$userId = $user["id"];

// Check if resource ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    // Redirect to resources page if no ID provided
    header("Location: resources.php?error=no_resource_specified");
    exit;
}

$resourceId = intval($_GET['id']);

// Fetch resource details
$stmt = $db->prepare("SELECT r.*, u.firstName, u.lastName 
                     FROM resources r
                     LEFT JOIN user u ON r.user_id = u.id
                     WHERE r.id = ?");
$stmt->bind_param("i", $resourceId);
$stmt->execute();
$resource = $stmt->get_result()->fetch_assoc();

// Check if resource exists
if (!$resource) {
    header("Location: resources.php?error=resource_not_found");
    exit;
}

// Check if user has permission to download this resource
// Case 1: It's the user's own resource
$isOwner = ($resource['user_id'] == $userId);

// Case 2: It's a free resource
$isFree = !$resource['is_premium'];

// Case 3: User has purchased this premium resource
$hasPurchased = false;
if ($resource['is_premium']) {
    $purchase_check = $db->prepare("SELECT id FROM resource_purchases 
                                   WHERE user_id = ? AND resource_id = ? AND status = 'completed'");
    $purchase_check->bind_param("ii", $userId, $resourceId);
    $purchase_check->execute();
    $hasPurchased = ($purchase_check->get_result()->num_rows > 0);
}

// Determine if download is allowed
$canDownload = $isOwner || $isFree || $hasPurchased;

if (!$canDownload) {
    // Redirect to resource page if user doesn't have permission
    header("Location: view_resource.php?id={$resourceId}&error=premium_purchase_required");
    exit;
}

// Get file path
$filePath = $resource['file_path'];

// Check if file exists
if (!file_exists($filePath)) {
    header("Location: resources.php?error=file_not_found");
    exit;
}

// Check for directory traversal attempts
$realPath = realpath($filePath);
$uploadsDirectory = realpath('uploads');

if (strpos($realPath, $uploadsDirectory) !== 0) {
    header("Location: resources.php?error=invalid_file_path");
    exit;
}

// Update download count (only if it's not the owner downloading)
if (!$isOwner) {
    $update_downloads = $db->prepare("UPDATE resources SET download_count = download_count + 1 WHERE id = ?");
    $update_downloads->bind_param("i", $resourceId);
    $update_downloads->execute();

    // Log the download
    $log_download = $db->prepare("INSERT INTO download_logs (user_id, resource_id, downloaded_at) VALUES (?, ?, NOW())");
    $log_download->bind_param("ii", $userId, $resourceId);
    $log_download->execute();
}

// Get file information
$fileName = basename($filePath);
$fileSize = filesize($filePath);
$fileType = mime_content_type($filePath);

// Set appropriate headers for file download
header("Pragma: public");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Cache-Control: private", false);
header("Content-Type: {$fileType}");
header("Content-Disposition: attachment; filename=\"{$fileName}\"");
header("Content-Transfer-Encoding: binary");
header("Content-Length: {$fileSize}");

// Clear output buffer
ob_clean();
flush();

// Read and output file
readfile($filePath);
exit;
?>