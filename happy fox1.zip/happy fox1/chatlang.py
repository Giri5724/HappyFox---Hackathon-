#!/usr/bin/python3
import telebot
import mysql.connector
import json
import requests
import logging
from io import BytesIO
from telebot import types

# Configure basic logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='bot.log',
    filemode='a'
)

# Configuration
upload_file = None
BASE_API_URL = "http://127.0.0.1:7860"
FLOW_ID = "5baed0c2-60bd-42bc-9fbb-117ac78f1498"
ENDPOINT = "madhuchat"  # You can set a specific endpoint name in the flow settings

# Bot token
API_TOKEN = '8026491455:AAHqd2hUV77gfAO0BAVOwtGq1KM9ll6PuNI'
bot = telebot.TeleBot(API_TOKEN)

# Database configuration
DB_CONFIG = {
    'user': 'root',
    'password': '',
    'host': '127.0.0.1',
    'database': 'vn-room-chat',
    'raise_on_warnings': True
}

def get_db_connection():
    """Establish and return a database connection."""
    try:
        return mysql.connector.connect(**DB_CONFIG)
    except Exception as e:
        logging.error(f"Database connection error: {e}")
        return None

def create_main_menu_buttons():
    """Create buttons for the main menu."""
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("🎨 Show Timetables", callback_data='show_timetables'),
        types.InlineKeyboardButton("🧑‍🦽 Get Books", callback_data='get_books'),
        types.InlineKeyboardButton("🗺 Route Map", callback_data='route_map'),
        types.InlineKeyboardButton("❓ Ask a Question", callback_data='ask_question'),
        types.InlineKeyboardButton("📚 FAQ Categories", callback_data='faq_categories')
    )
    return markup

@bot.message_handler(commands=['start'])
def welcome_start(message):
    """Send a welcome message when the user starts the bot."""
    user_name = message.from_user.first_name
    response = f"Welcome to DosthoMate 🧑‍🤝‍🧑 Specially for REC, {user_name}! 👋\n\n" \
            f"• 🕒 Show Timetables\n" \
            f"• 📚 Get Books\n" \
            f"• 🗺 Route Map\n" \
            f"• ❓ Ask a Question\n" \
            f"• 📚 FAQ Categories"
    
    # Create normal menu buttons
    markup = create_main_menu_buttons()
    
    # Add a test button that doesn't use any complex handlers
    markup.add(types.InlineKeyboardButton("🔴 TEST BUTTON", callback_data='simple_test'))
    
    logging.info(f"User {message.from_user.id} started the bot")
    bot.send_message(message.chat.id, response, reply_markup=markup)

@bot.message_handler(commands=['test'])
def test_connection(message):
    """Test if the bot is responding properly."""
    bot.reply_to(message, "Bot is connected and working! ✅")
    
    # Also test inline buttons
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("Simple Test Button", callback_data="simple_button_test"))
    bot.send_message(message.chat.id, "Please click the button below to test callback:", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    """Handle all button callbacks."""
    try:
        # Log the callback data
        print(f"Received callback: {call.data} from user {call.from_user.id}")
        logging.info(f"Received callback: {call.data} from user {call.from_user.id}")
        
        # Special test button with minimal code path
        if call.data == 'simple_test' or call.data == 'simple_button_test':
            bot.answer_callback_query(call.id, "Test button works!")
            bot.send_message(call.message.chat.id, "This is a test message! Button clicks are working!")
            return
            
        # Always acknowledge the callback query first
        bot.answer_callback_query(call.id)
        
        # Main menu
        if call.data == 'main_menu':
            bot.edit_message_text(
                "What would you like to do? 🤔",
                call.message.chat.id,
                call.message.message_id,
                reply_markup=create_main_menu_buttons()
            )
            
        # Show timetables
        elif call.data == 'show_timetables':
            handle_show_timetables(call.message)
            
        # Get books
        elif call.data == 'get_books':
            handle_get_books(call.message)
            
        # Route map
        elif call.data == 'route_map':
            handle_route_map(call.message)
            
        # Ask question
        elif call.data == 'ask_question':
            handle_ask_question(call.message)
            
        # FAQ categories
        elif call.data == 'faq_categories':
            handle_faq_categories(call.message)
        
        # Map selection
        elif call.data.startswith('map_'):
            map_type = call.data.split('_')[1]
            handle_show_map(call.message, map_type)
            
        elif call.data.startswith('book_'):
            book_id = call.data.split('_')[1]
            handle_download_book(call.message, book_id)
            
        else:
            logging.warning(f"Unhandled callback data: {call.data}")
            
    except Exception as e:
        logging.error(f"Error in callback handler: {e}")
        try:
            bot.send_message(
                call.message.chat.id,
                "Sorry, there was an error processing your request. Please try again."
            )
        except:
            pass

def handle_show_timetables(message):
    """Handle showing timetables."""
    try:
        # First, send a confirmation message
        bot.send_message(message.chat.id, "Fetching timetables... Please wait.")
        
        conn = get_db_connection()
        if not conn:
            bot.send_message(message.chat.id, "Database connection error. Please try again later.")
            return
            
        cursor = conn.cursor()
        cursor.execute("SELECT timetable_image FROM timetables WHERE id = 1")
        result = cursor.fetchone()
        
        if result and result[0]:
            image_data = result[0]
            image_stream = BytesIO(image_data)
            
            # Create back button
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton("🔙 Back to Main Menu", callback_data='main_menu'))
            
            bot.send_photo(
                message.chat.id,
                image_stream,
                caption="Here's the timetable:",
                reply_markup=markup
            )
        else:
            # Create back button
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton("🔙 Back to Main Menu", callback_data='main_menu'))
            
            bot.send_message(
                message.chat.id,
                "No timetable found. Please check back later.",
                reply_markup=markup
            )
    except Exception as e:
        logging.error(f"Error in show_timetables: {e}")
        
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔙 Back to Main Menu", callback_data='main_menu'))
        
        bot.send_message(
            message.chat.id,
            f"Error retrieving timetable: {str(e)}. Please try again later.",
            reply_markup=markup
        )
    finally:
        if 'cursor' in locals() and cursor:
            cursor.close()
        if 'conn' in locals() and conn:
            conn.close()

def handle_get_books(message):
    """Handle getting books."""
    try:
        # Send initial feedback
        bot.send_message(message.chat.id, "Fetching available books... Please wait.")
        
        conn = get_db_connection()
        if not conn:
            bot.send_message(message.chat.id, "Database connection error. Please try again later.")
            return
            
        cursor = conn.cursor()
        cursor.execute("SELECT id, title, author FROM books LIMIT 10")
        books = cursor.fetchall()
        
        if books and len(books) > 0:
            markup = types.InlineKeyboardMarkup()
            
            for book_id, title, author in books:
                book_title = title or "Untitled"
                markup.add(types.InlineKeyboardButton(
                    f"{book_title} - Computer Networks", 
                    callback_data=f"book_{book_id}"
                ))
                
            markup.add(types.InlineKeyboardButton("🔙 Back to Main Menu", callback_data='main_menu'))
            
            bot.send_message(
                message.chat.id,
                "Select a book to download:",
                reply_markup=markup
            )
        else:
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton("🔙 Back to Main Menu", callback_data='main_menu'))
            
            bot.send_message(
                message.chat.id,
                "No books found. Please check back later.",
                reply_markup=markup
            )
    except Exception as e:
        logging.error(f"Error in get_books: {e}")
        
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔙 Back to Main Menu", callback_data='main_menu'))
        
        bot.send_message(
            message.chat.id,
            f"Error retrieving books: {str(e)}. Please try again later.",
            reply_markup=markup
        )
    finally:
        if 'cursor' in locals() and cursor:
            cursor.close()
        if 'conn' in locals() and conn:
            conn.close()

def handle_download_book(message, book_id):
    """Handle book download."""
    try:
        # Send initial feedback
        bot.send_message(message.chat.id, "Preparing book for download... Please wait.")
        
        conn = get_db_connection()
        if not conn:
            bot.send_message(message.chat.id, "Database connection error. Please try again later.")
            return
            
        cursor = conn.cursor()
        cursor.execute("SELECT title, author, pdf_data FROM books WHERE id = %s", (book_id,))
        book = cursor.fetchone()
        
        if book and book[2]:  # Check if pdf_data exists
            title = book[0] or "Untitled"
            author = book[1] or "Unknown"
            pdf_data = book[2]
            
            # Create file object from binary data
            pdf_stream = BytesIO(pdf_data)
            pdf_stream.seek(0)
            
            # Send document
            caption = f"📚 {title}" + (f" by {author}" if author != "Unknown" else "")
            
            # Create back buttons for after download
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton("📚 More Books", callback_data='get_books'))
            markup.add(types.InlineKeyboardButton("🏠 Main Menu", callback_data='main_menu'))
            
            # Send file
            bot.send_document(
                message.chat.id,
                pdf_stream,
                caption=caption,
                visible_file_name=f"{title}.pdf"
            )
            
            # Follow up with options
            bot.send_message(
                message.chat.id,
                "Here's your book! Need anything else?",
                reply_markup=markup
            )
        else:
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton("🔙 Back to Books", callback_data='get_books'))
            
            bot.send_message(
                message.chat.id,
                "Sorry, this book is not available for download.",
                reply_markup=markup
            )
    except Exception as e:
        logging.error(f"Error downloading book: {e}")
        
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔙 Back to Books", callback_data='get_books'))
        
        bot.send_message(
            message.chat.id,
            f"Error downloading the book: {str(e)}. Please try again later.",
            reply_markup=markup
        )
    finally:
        if 'cursor' in locals() and cursor:
            cursor.close()
        if 'conn' in locals() and conn:
            conn.close()

def handle_route_map(message):
    """Handle route map selection."""
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🏫 College Map", callback_data='map_college'))
    markup.add(types.InlineKeyboardButton("🚌 Transport Map", callback_data='map_transport'))
    markup.add(types.InlineKeyboardButton("🔙 Back to Main Menu", callback_data='main_menu'))
    
    bot.send_message(
        message.chat.id,
        "Select a map to view:",
        reply_markup=markup
    )

def handle_show_map(message, map_type):
    """Handle showing a specific map."""
    try:
        # Send initial feedback
        bot.send_message(message.chat.id, "Fetching map... Please wait.")
        
        conn = get_db_connection()
        if not conn:
            bot.send_message(message.chat.id, "Database connection error. Please try again later.")
            return
            
        cursor = conn.cursor()
        cursor.execute("SELECT map_image FROM map WHERE type = %s", (map_type,))
        result = cursor.fetchone()
        
        if result and result[0]:
            image_data = result[0]
            image_stream = BytesIO(image_data)
            
            # Caption based on map type
            caption = "College Campus Map 🏫" if map_type == "college" else "Transport Routes Map 🚌"
            
            # Create back buttons
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton("🔙 Back to Maps", callback_data='route_map'))
            markup.add(types.InlineKeyboardButton("🏠 Main Menu", callback_data='main_menu'))
            
            bot.send_photo(
                message.chat.id,
                image_stream,
                caption=caption,
                reply_markup=markup
            )
        else:
            markup = types.InlineKeyboardMarkup()
            markup.add(types.InlineKeyboardButton("🔙 Back to Maps", callback_data='route_map'))
            
            bot.send_message(
                message.chat.id,
                f"No {map_type} map found. Please check back later.",
                reply_markup=markup
            )
    except Exception as e:
        logging.error(f"Error in show_map: {e}")
        
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔙 Back to Maps", callback_data='route_map'))
        
        bot.send_message(
            message.chat.id,
            f"Error retrieving map: {str(e)}. Please try again later.",
            reply_markup=markup
        )
    finally:
        if 'cursor' in locals() and cursor:
            cursor.close()
        if 'conn' in locals() and conn:
            conn.close()

def handle_ask_question(message):
    """Handle ask question request."""
    msg = bot.send_message(
        message.chat.id,
        "Please type your question. Our AI Agent is ready to answer you!!! 🤖\n\n"
        "Type /cancel to go back to the main menu."
    )
    bot.register_next_step_handler(msg, process_question)

@bot.message_handler(commands=['cancel'])
def cancel_handler(message):
    """Handle cancel command."""
    markup = create_main_menu_buttons()
    bot.send_message(
        message.chat.id,
        "Operation cancelled. Back to main menu.",
        reply_markup=markup
    )

def process_question(message):
    """Process a question using Langflow API."""
    # Check if user wants to cancel
    if message.text.strip().lower() == '/cancel':
        return cancel_handler(message)
        
    try:
        # Send "typing" indication
        bot.send_chat_action(message.chat.id, 'typing')
        
        # Inform user that their question is being processed
        notification = bot.send_message(
            message.chat.id, 
            "Processing your question... This may take a moment."
        )
        
        # Call Langflow API
        api_response = call_langflow_api(message.text)
        
        # Try to delete the notification message to avoid clutter
        try:
            bot.delete_message(message.chat.id, notification.message_id)
        except:
            pass
        
        if "outputs" in api_response and api_response["outputs"]:
            try:
                # Extract the response text from API output
                output_message = api_response["outputs"][0]["outputs"][0]["results"]["message"]["text"]
                response_text = output_message
            except (KeyError, IndexError) as e:
                logging.error(f"Error parsing API response: {e}")
                logging.error(f"API response structure: {api_response}")
                response_text = "Sorry, I couldn't understand the API response. Please try again."
        else:
            error_msg = api_response.get("error", "Unknown error")
            logging.error(f"API error: {error_msg}")
            response_text = "Sorry, I couldn't process your question. Please try again later."
        
        # Create response buttons
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("Ask Another Question ❓", callback_data='ask_question'))
        markup.add(types.InlineKeyboardButton("Main Menu 🏠", callback_data='main_menu'))
        
        # Send response (split if too long)
        if len(response_text) > 4000:
            # Split long messages
            parts = [response_text[i:i+4000] for i in range(0, len(response_text), 4000)]
            for i, part in enumerate(parts):
                if i == len(parts) - 1:  # Last part
                    bot.send_message(message.chat.id, part, reply_markup=markup)
                else:
                    bot.send_message(message.chat.id, part)
        else:
            bot.send_message(message.chat.id, response_text, reply_markup=markup)
            
    except Exception as e:
        logging.error(f"Error processing question: {e}")
        
        # Create back button
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔙 Back to Main Menu", callback_data='main_menu'))
        
        bot.send_message(
            message.chat.id,
            f"Sorry, there was an error processing your question: {str(e)}. Please try again later.",
            reply_markup=markup
        )

def call_langflow_api(question):
    """Call the Langflow API with the user's question."""
    try:
        api_url = f"{BASE_API_URL}/api/v1/run/{ENDPOINT}"
        
        payload = {
            "input_value": question,
            "output_type": "chat",
            "input_type": "chat",
            "tweaks": {
                "ChatInput-PqvUA": {},
                "Prompt-ZndDl": {},
                "ChatOutput-9Q8Jj": {},
                "GoogleGenerativeAIModel-UPDmG": {}
            }
        }
        
        logging.info(f"Calling API with question: {question[:50]}...")
        
        # Make API request with timeout
        response = requests.post(api_url, json=payload, timeout=30)
        
        # Log basic response info
        logging.info(f"API response status: {response.status_code}")
        
        if response.status_code == 200:
            try:
                return response.json()
            except json.JSONDecodeError as e:
                logging.error(f"JSON decode error: {e}")
                return {"error": "Invalid JSON response"}
        else:
            logging.error(f"API error: {response.status_code}, {response.text[:100]}...")
            return {"error": f"API error: {response.status_code}"}
    except requests.exceptions.Timeout:
        logging.error("API request timed out")
        return {"error": "API request timed out"}
    except requests.exceptions.ConnectionError:
        logging.error("Connection error to API")
        return {"error": "Could not connect to API"}
    except Exception as e:
        logging.error(f"Error calling Langflow API: {e}")
        return {"error": str(e)}

def handle_faq_categories(message):
    """Handle FAQ categories."""
    # Create back button
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🔙 Back to Main Menu", callback_data='main_menu'))
    
    bot.send_message(
        message.chat.id,
        "FAQ categories feature is coming soon!",
        reply_markup=markup
    )

@bot.message_handler(func=lambda message: True)
def handle_all_messages(message):
    """Handle all other messages."""
    bot.send_message(
        message.chat.id,
        "I'm not sure what you're asking. Please use the menu below:",
        reply_markup=create_main_menu_buttons()
    )

if __name__ == "__main__":
    print("Bot is running...")
    logging.info("Bot started")
    
    # Get bot info to verify connection
    try:
        me = bot.get_me()
        print(f"Bot connected successfully: @{me.username}")
    except Exception as e:
        print(f"Failed to connect to Telegram: {e}")
        logging.error(f"Failed to connect to Telegram: {e}")
        exit(1)
        
    # Test Telegram API connection
    try:
        response = requests.get(f"https://api.telegram.org/bot{API_TOKEN}/getMe")
        print("Telegram API connection test:", response.status_code)
        print(response.json())
    except Exception as e:
        print("Failed to connect to Telegram API:", e)
        
    try:
        # IMPORTANT: Explicitly list callback_query in allowed_updates
        bot.infinity_polling(timeout=10, 
                           long_polling_timeout=5,
                           allowed_updates=["message", "callback_query"])
    except Exception as e:
        logging.error(f"Bot crashed: {e}")
        print(f"Bot crashed: {e}")