import asyncio
import aiohttp
import time
from concurrent.futures import ThreadPoolExecutor

# 🔹 Replace with your bot token & chat ID
BOT_TOKEN = "8026491455:AAHqd2hUV77gfAO0BAVOwtGq1KM9ll6PuNI"  # Replace with your Telegram Bot Token
CHAT_ID = 6531492259  # Replace with your actual Chat ID

# 🔹 Simulation Settings
NUM_USERS = 5  # Number of simulated users
MESSAGES_PER_USER = 10  # Number of messages per user
DELAY_BETWEEN_MESSAGES = 0.1  # Delay (in seconds) between messages
CONCURRENT_REQUESTS = 5  # Number of concurrent requests

# Track response times
response_times = []
errors = 0
successful_requests = 0

async def send_message(session, user_id, message_num):
    """Sends a message to the Telegram bot and tracks response time."""
    global errors, successful_requests
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": CHAT_ID,
        "text": f"User {user_id} - Message {message_num}"
    }

    start_time = time.time()
    try:
        async with session.post(url, json=payload) as response:
            response_json = await response.json()
            if response.status == 200 and response_json.get("ok"):
                elapsed_time = time.time() - start_time
                response_times.append(elapsed_time)
                successful_requests += 1
                print(f"✅ User {user_id} - Message {message_num} sent! Response Time: {elapsed_time:.2f}s")
            else:
                print(f"❌ Failed to send message {message_num}: {response_json}")
                errors += 1
    except Exception as e:
        print(f"❌ Error sending message {message_num}: {e}")
        errors += 1

async def run_traffic_test():
    """Runs the traffic test with multiple users."""
    async with aiohttp.ClientSession() as session:
        tasks = []
        for user in range(1, NUM_USERS + 1):
            for msg in range(1, MESSAGES_PER_USER + 1):
                tasks.append(asyncio.ensure_future(send_message(session, user, msg)))
                if len(tasks) >= CONCURRENT_REQUESTS:
                    await asyncio.gather(*tasks)
                    tasks = []
                    await asyncio.sleep(DELAY_BETWEEN_MESSAGES)

        if tasks:
            await asyncio.gather(*tasks)

def generate_report(start_time, end_time):
    """Generates a performance report after the test."""
    total_time = end_time - start_time
    total_messages = NUM_USERS * MESSAGES_PER_USER

    print("\n📊 Final Traffic Test Report")
    print("=" * 40)
    print(f"🕒 Total Execution Time: {total_time:.2f} seconds")
    print(f"📨 Total Messages Attempted: {total_messages}")
    print(f"✅ Successful Messages: {successful_requests}")
    print(f"❌ Failed Messages: {errors}")
    print(f"📈 Success Rate: {((successful_requests / total_messages) * 100):.2f}%")

    if response_times:
        print(f"📊 Average Response Time: {sum(response_times) / len(response_times):.2f} seconds")
        print(f"🚀 Fastest Response Time: {min(response_times):.2f} seconds")
        print(f"🐢 Slowest Response Time: {max(response_times):.2f} seconds")
    else:
        print("⚠️ No responses received. Check if the bot is running properly.")

    print("=" * 40)

if __name__ == "__main__":
    print("\n🚀 Starting Traffic Test...\n")
    start_time = time.time()
    asyncio.run(run_traffic_test())
    end_time = time.time()
    generate_report(start_time, end_time)