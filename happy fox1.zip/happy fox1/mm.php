<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session
if (!session_id()) {
    session_start();
}

// Database connection
require("config/db.php");

// Check user authentication
if (!isset($_COOKIE["user_session"])) {
    header("Location: login.php");
    exit;
}

// Fetch user data
$user = searchUser_bSession($db, $_COOKIE["user_session"]);
if (!$user) {
    header("Location: login.php");
    exit;
}

// Enhanced Resource Fetching Function
function fetchResources($db, $filters = [], $page = 1, $perPage = 9) {
    // Base query with comprehensive joins
    $baseQuery = "SELECT 
        r.*, 
        u.firstName, 
        u.lastName, 
        u.profilePicture,
        COALESCE(r.uploaded_at, r.created_at, NOW()) as display_date,
        (SELECT COUNT(*) FROM resource_likes WHERE resource_id = r.id) as like_count,
        COALESCE(r.download_count, 0) as download_count"; // Fallback download count

    // Complete query
    $baseQuery .= " FROM resources r
    LEFT JOIN user u ON r.user_id = u.id";

    // Build conditions
    $conditions = [];
    $params = [];
    $paramTypes = "";

    // Dynamic filtering
    $filterFields = [
        'category' => 'r.category',
        'file_type' => 'r.file_type',
        'target_year' => 'r.target_year',
        'is_premium' => 'r.is_premium'
    ];

    foreach ($filterFields as $key => $field) {
        if (!empty($filters[$key])) {
            $conditions[] = "$field = ?";
            $params[] = $filters[$key];
            $paramTypes .= "s";
        }
    }

    // Search condition
    if (!empty($filters['search'])) {
        $conditions[] = "(r.title LIKE ? OR r.description LIKE ?)";
        $searchTerm = "%{$filters['search']}%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $paramTypes .= "ss";
    }

    // Construct WHERE clause
    $whereClause = $conditions ? " WHERE " . implode(" AND ", $conditions) : "";

    // Sorting options
    $sortOptions = [
        'newest' => "display_date DESC",
        'oldest' => "display_date ASC",
        'popular' => "download_count DESC",
        'title_asc' => "r.title ASC",
        'title_desc' => "r.title DESC"
    ];
    $orderBy = $sortOptions[$filters['sort'] ?? 'newest'] ?? $sortOptions['newest'];

    // Pagination
    $offset = ($page - 1) * $perPage;

    // Total count query
    $countQuery = "SELECT COUNT(*) as total FROM resources r $whereClause";
    $countStmt = $db->prepare($countQuery);
    if ($params) {
        $countStmt->bind_param($paramTypes, ...$params);
    }
    $countStmt->execute();
    $totalResult = $countStmt->get_result()->fetch_assoc();
    $totalResources = $totalResult['total'];
    $totalPages = max(1, ceil($totalResources / $perPage));

    // Resources query with pagination
    $query = "$baseQuery $whereClause ORDER BY $orderBy LIMIT ? OFFSET ?";
    $paramTypes .= "ii";
    $params[] = $perPage;
    $params[] = $offset;

    $stmt = $db->prepare($query);
    $stmt->bind_param($paramTypes, ...$params);
    $stmt->execute();
    $resources = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    return [
        'resources' => $resources,
        'total_pages' => $totalPages,
        'total_resources' => $totalResources,
        'current_page' => $page
    ];
}

// Resource Upload Handling
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_resource'])) {
    // Ensure uploads directory exists
    $upload_dir = 'uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    // Initialize error tracking
    $errors = [];

    // Validate required fields
    $requiredFields = [
        'title' => 'Resource title',
        'description' => 'Description',
        'category' => 'Category',
        'target_year' => 'Target Year'
    ];

    foreach ($requiredFields as $field => $label) {
        $value = trim($_POST[$field] ?? '');
        if (empty($value)) {
            $errors[] = "$label is required.";
        }
    }

    // Validate category and target year
    $valid_categories = ['Lecture Notes', 'Assignments', 'Quizzes', 'Exams', 'Projects', 'Textbooks', 'Research Papers', 'Study Guides', 'Other'];
    $valid_years = ['Freshman', 'Sophomore', 'Junior', 'Senior', 'Graduate', 'All Levels'];

    if (!in_array($_POST['category'], $valid_categories)) {
        $errors[] = "Invalid category selected.";
    }

    if (!in_array($_POST['target_year'], $valid_years)) {
        $errors[] = "Invalid target year selected.";
    }

    // File upload handling
    $file_uploaded = false;
    $file_path = '';
    $file_type = '';
    
    if (isset($_FILES['resource_file']) && $_FILES['resource_file']['error'] === UPLOAD_ERR_OK) {
        // Generate unique filename
        $file_name = uniqid() . '_' . basename($_FILES['resource_file']['name']);
        $file_path = $upload_dir . $file_name;
        $file_type = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        // List of allowed file types
        $allowed_types = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'jpg', 'jpeg', 'png', 'gif', 'zip', 'rar', 'mp4', 'avi', 'mov', 'mp3', 'wav'];
        
        // Validate file type
        if (!in_array($file_type, $allowed_types)) {
            $errors[] = "Invalid file type. Allowed types: " . implode(', ', $allowed_types);
        }

        // Validate file size (50MB max)
        $max_file_size = 50 * 1024 * 1024; // 50MB
        if ($_FILES['resource_file']['size'] > $max_file_size) {
            $errors[] = "File is too large. Maximum file size is 50MB.";
        }

        // If no errors, move the uploaded file
        if (empty($errors)) {
            if (move_uploaded_file($_FILES['resource_file']['tmp_name'], $file_path)) {
                $file_uploaded = true;
            } else {
                $errors[] = "Failed to move uploaded file.";
            }
        }
    } else {
        $errors[] = "File upload failed. Please check file and try again.";
    }

    // Handle premium resource
    $is_premium = isset($_POST['is_premium']) ? 1 : 0;
    $price = $is_premium ? (float)$_POST['price'] : null;

    // If premium is checked, validate price
    if ($is_premium && ($price === null || $price <= 0)) {
        $errors[] = "Please specify a valid price for premium resources.";
    }

    // If no errors, insert resource into database
    if (empty($errors)) {
        try {
            // Prepare SQL statement with explicit columns
            $stmt = $db->prepare("INSERT INTO resources (
                user_id, title, description, category, target_year, 
                file_path, file_type, is_premium, price, 
                uploaded_at, created_at, download_count
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW(), 0)");

            // Bind parameters
            $stmt->bind_param(
                "issssssid", 
                $userId,           // User ID from session/cookie 
                $_POST['title'],   // Resource title
                $_POST['description'], // Resource description
                $_POST['category'], // Resource category
                $_POST['target_year'], // Target year/level
                $file_path,        // File path on server
                $file_type,        // File extension
                $is_premium,       // Premium status (0 or 1)
                $price             // Price (if premium)
            );

            // Execute statement
            if ($stmt->execute()) {
                // Redirect with success message
                header("Location: resources.php?success=1");
                exit();
            } else {
                $errors[] = "Failed to save resource. Database error.";
            }
        } catch (Exception $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }

    // If we get here, there were errors
    if (!empty($errors)) {
        // Prepare error message to display
        $error_message = implode("<br>", $errors);
    }
}
$userName = $user["firstName"] . " " . $user["lastName"];
$profilePicture = $user["profilePicture"] ?? "default-avatar.png";
$userId = $user["id"];

// Set up initial search query value
$search_query = $_GET['search'] ?? '';
$category_filter = $_GET['category'] ?? '';
$file_type_filter = $_GET['file_type'] ?? '';
$year_filter = $_GET['year'] ?? '';
$order_by = $_GET['sort'] ?? 'newest';

// Prepare filters
$filters = [
    'category' => $category_filter,
    'file_type' => $file_type_filter,
    'target_year' => $year_filter,
    'search' => $search_query,
    'sort' => $order_by,
    'is_premium' => $_GET['is_premium'] ?? ''
];

// Pagination
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 9;

// Debug: Print out filters and user details
error_log("User ID: $userId");
error_log("Filters: " . print_r($filters, true));

// Fetch resources using new function
$resourceData = fetchResources($db, $filters, $page, $per_page);
$resources = $resourceData['resources'];
$total_pages = $resourceData['total_pages'];
$total_resources = $resourceData['total_resources'];

// Add debug logging for resources
error_log("Total Resources: $total_resources");
error_log("Resources Found: " . count($resources));

// Fetch filter options
$categories = $db->query("SELECT DISTINCT category FROM resources ORDER BY category")->fetch_all(MYSQLI_ASSOC);
$file_types = $db->query("SELECT DISTINCT file_type FROM resources ORDER BY file_type")->fetch_all(MYSQLI_ASSOC);

// Define target years for dropdown
$target_years = ['Freshman', 'Sophomore', 'Junior', 'Senior', 'Graduate', 'All Levels'];

// Success Message after Upload
$show_success = isset($_GET['success']) && $_GET['success'] == 1;

// File Icons & Colors
function getFileIcon($fileType) {
    return match(strtolower($fileType)) {
        'pdf' => 'fa-file-pdf', 'doc', 'docx' => 'fa-file-word',
        'xls', 'xlsx' => 'fa-file-excel', 'ppt', 'pptx' => 'fa-file-powerpoint',
        'jpg', 'jpeg', 'png', 'gif' => 'fa-file-image', 'zip', 'rar' => 'fa-file-archive',
        'mp4', 'avi', 'mov' => 'fa-file-video', 'mp3', 'wav' => 'fa-file-audio',
        default => 'fa-file',
    };
}

function getFileColor($fileType) {
    return match(strtolower($fileType)) {
        'pdf' => 'red', 'doc', 'docx' => 'blue', 'xls', 'xlsx' => 'green',
        'ppt', 'pptx' => 'orange', 'jpg', 'jpeg', 'png', 'gif' => 'purple',
        'zip', 'rar' => 'teal', 'mp4', 'avi', 'mov' => 'pink', 'mp3', 'wav' => 'indigo',
        default => 'gray',
    };
}

// Handle Likes
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_like' && isset($_POST['resource_id'])) {
    $resource_id = intval($_POST['resource_id']);
    
    // Check existing like
    $check_like = $db->prepare("SELECT id FROM resource_likes WHERE user_id = ? AND resource_id = ?");
    $check_like->bind_param("ii", $userId, $resource_id);
    $check_like->execute();
    $result = $check_like->get_result();

    if ($result->num_rows > 0) {
        $unlike = $db->prepare("DELETE FROM resource_likes WHERE user_id = ? AND resource_id = ?");
        $unlike->bind_param("ii", $userId, $resource_id);
        $unlike->execute();
        $liked = false;
    } else {
        $like = $db->prepare("INSERT INTO resource_likes (user_id, resource_id) VALUES (?, ?)");
        $like->bind_param("ii", $userId, $resource_id);
        $like->execute();
        $liked = true;
    }

    // Get updated like count
    $count_likes = $db->prepare("SELECT COUNT(*) as count FROM resource_likes WHERE resource_id = ?");
    $count_likes->bind_param("i", $resource_id);
    $count_likes->execute();
    $like_count = $count_likes->get_result()->fetch_assoc()['count'];

    echo json_encode([
        'success' => true, 
        'liked' => $liked, 
        'likeCount' => $like_count
    ]);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resource Sharing Platform</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Razorpay SDK -->
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
</head>
<style>
    /* Base text size increase */
    html {
        font-size: 17px;
    }
    
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    h1 {
        font-size: 2.5rem !important;
    }
    
    h2 {
        font-size: 2rem !important;
    }
    
    h3 {
        font-size: 1.75rem !important;
    }
    
    h4 {
        font-size: 1.5rem !important;
    }
    
    p, label, input, select, button {
        font-size: 1.1rem !important;
    }
    
    .form-input {
        font-size: 1.1rem !important;
    }
    
    .notification-badge {
        animation: pulse 2s infinite;
    }

    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.1); }
        100% { transform: scale(1); }
    }

    /* Custom scrollbar */
    .custom-scrollbar {
        scrollbar-width: thin;
        scrollbar-color: rgba(156, 163, 175, 0.5) transparent;
    }

    .custom-scrollbar::-webkit-scrollbar {
        width: 6px;
    }

    .custom-scrollbar::-webkit-scrollbar-track {
        background: transparent;
    }

    .custom-scrollbar::-webkit-scrollbar-thumb {
        background-color: rgba(156, 163, 175, 0.5);
        border-radius: 3px;
    }

    /* Resource card hover effects */
    .resource-card {
        transition: all 0.3s ease;
    }

    .resource-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    }

    /* Form focus effects */
    .form-input:focus, .form-select:focus, .form-textarea:focus {
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.5);
        outline: none;
    }

    /* File upload button */
    .file-upload-btn {
        position: relative;
        overflow: hidden;
        display: inline-block;
    }

    .file-upload-btn input[type=file] {
        position: absolute;
        top: 0;
        right: 0;
        min-width: 100%;
        min-height: 100%;
        font-size: 100px;
        text-align: right;
        filter: alpha(opacity=0);
        opacity: 0;
        outline: none;
        cursor: inherit;
        display: block;
    }

    /* Premium badge */
    .premium-badge {
        position: absolute;
        top: -10px;
        right: -10px;
        background: linear-gradient(135deg, #ff9d00, #e3780c);
        color: white;
        border-radius: 50%;
        width: 55px;
        height: 55px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        z-index: 10;
    }

    /* Floating action button */
    .floating-btn {
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 65px;
        height: 65px;
        border-radius: 50%;
        background-color: #4F46E5;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.25);
        z-index: 20;
        transition: all 0.3s;
    }

    .floating-btn:hover {
        transform: scale(1.1);
        box-shadow: 0 6px 15px rgba(0,0,0,0.3);
    }

    /* Modal animation */
    .modal {
        transition: opacity 0.3s ease-out;
    }

    /* Toast notifications */
    .toast-notification {
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 16px 24px;
        border-radius: 8px;
        background-color: #4F46E5;
        color: white;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 50;
        transform: translateX(100%);
        opacity: 0;
        animation: slideIn 0.5s forwards;
    }

    @keyframes slideIn {
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    /* Category and file type badge */
    .category-badge, .file-badge {
        display: inline-block;
        padding: 0.375rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.875rem;
        font-weight: 500;
        text-transform: uppercase;
    }

    /* Pagination styles */
    .pagination-item {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 2.5rem;
        height: 2.5rem;
        padding: 0 0.75rem;
        margin: 0 0.25rem;
        border-radius: 0.375rem;
        font-weight: 500;
        transition: all 0.2s;
    }

    .pagination-item:hover:not(.active, .disabled) {
        background-color: #E5E7EB;
    }

    .pagination-item.active {
        background-color: #4F46E5;
        color: white;
    }

    .pagination-item.disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }
</style>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-10">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="home.php" class="flex items-center">
                        <i class="fas fa-book-open text-indigo-600 text-3xl mr-2"></i>
                        <span class="text-2xl font-bold text-gray-800">ResourceHub</span>
                    </a>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <button onclick="toggleNotifications()" class="text-gray-600 hover:text-gray-800">
                            <i class="fas fa-bell text-xl"></i>
                            <span class="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-5 h-5 text-xs flex items-center justify-center">3</span>
                        </button>
                    </div>
                    <div class="relative group">
                        <button class="flex items-center space-x-2">
                            <img src="<?php echo $profilePicture; ?>" 
                                 alt="Profile" 
                                 class="w-10 h-10 rounded-full border-2 border-indigo-200">
                            <span class="text-gray-700 text-lg"><?php echo htmlspecialchars($userName); ?></span>
                        </button>
                        <div class="absolute right-0 w-56 mt-2 bg-white rounded-md shadow-lg hidden group-hover:block">
                            <a href="account.php" class="block px-4 py-3 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-user mr-2"></i> Account
                            </a>
                            <a href="my_resources.php" class="block px-4 py-3 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-file mr-2"></i> My Resources
                            </a>
                            <a href="downloads.php" class="block px-4 py-3 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-download mr-2"></i> Downloads
                            </a>
                            <?php if(isset($isAdmin) && $isAdmin): ?>
                            <a href="admin.php" class="block px-4 py-3 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-cogs mr-2"></i> Admin Panel
                            </a>
                            <?php endif; ?>
                            <a href="<?= $_LOGOUT_FILE ?? 'logout.php' ?>" class="block px-4 py-3 text-red-600 hover:bg-gray-100">
                                <i class="fas fa-sign-out-alt mr-2"></i> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="min-h-screen pt-20 pb-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Page Header -->
            <div class="mb-8 text-center">
                <h1 class="text-4xl font-bold text-gray-800">Resource Sharing Platform</h1>
                <p class="mt-2 text-xl text-gray-600">Discover, share, and learn with high-quality educational resources</p>
            </div>

            <!-- Success Notification -->
            <?php if ($show_success): ?>
            <div id="successAlert" class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded-lg">
                <div class="flex items-center">
                    <div class="py-1">
                        <i class="fas fa-check-circle text-green-500 text-2xl mr-4"></i>
                    </div>
                    <div>
                        <p class="font-bold text-lg">Success!</p>
                        <p>Your resource has been uploaded successfully.</p>
                    </div>
                    <button onclick="document.getElementById('successAlert').style.display='none'" class="ml-auto">
                        <i class="fas fa-times text-green-500"></i>
                    </button>
                </div>
            </div>
            <?php endif; ?>

            <!-- Error Message (if any) -->
            <?php if (isset($error_message) && !empty($error_message)): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-lg">
                <div class="flex items-center">
                    <div class="py-1">
                        <i class="fas fa-exclamation-circle text-red-500 text-2xl mr-4"></i>
                    </div>
                    <div>
                        <p class="font-bold text-lg">Error!</p>
                        <p><?php echo $error_message; ?></p>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Search & Filter Bar -->
            <div class="bg-white rounded-xl shadow-sm p-6 mb-8">
                <form action="" method="GET" class="space-y-4">
                    <div class="flex flex-col lg:flex-row lg:items-center lg:space-x-4 space-y-4 lg:space-y-0">
                        <!-- Search Box -->
                        <div class="flex-grow">
                            <div class="relative">
                                <input type="text" name="search" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="Search resources..." 
                                       class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition duration-200">
                                <span class="absolute left-3 top-3.5 text-gray-400">
                                    <i class="fas fa-search"></i>
                                </span>
                            </div>
                        </div>
                        
                        <!-- Category Filter -->
                        <div class="lg:w-1/5">
                            <select name="category" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition duration-200">
                                <option value="">All Categories</option>
                                <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo htmlspecialchars($cat['category']); ?>" <?php echo $category_filter == $cat['category'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['category']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- File Type Filter -->
                        <div class="lg:w-1/5">
                            <select name="file_type" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition duration-200">
                                <option value="">All File Types</option>
                                <?php foreach ($file_types as $type): ?>
                                <option value="<?php echo htmlspecialchars($type['file_type']); ?>" <?php echo $file_type_filter == $type['file_type'] ? 'selected' : ''; ?>>
                                    <?php echo strtoupper(htmlspecialchars($type['file_type'])); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Year Level Filter -->
                        <div class="lg:w-1/5">
                            <select name="year" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition duration-200">
                                <option value="">All Years</option>
                                <?php foreach ($target_years as $year): ?>
                                <option value="<?php echo htmlspecialchars($year); ?>" <?php echo $year_filter == $year ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($year); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
                        <!-- Sort Options -->
                        <div class="flex flex-wrap items-center space-x-2">
                            <span class="text-gray-600">Sort by:</span>
                            <div class="flex space-x-1">
                                <a href="?<?php 
                                    echo http_build_query(array_merge($_GET, ['sort' => 'newest'])); 
                                ?>" class="px-3 py-1.5 rounded-md <?php echo ($order_by == 'newest' || !$order_by) ? 'bg-indigo-100 text-indigo-700' : 'bg-gray-100 text-gray-700'; ?>">
                                    Newest
                                </a>
                                <a href="?<?php 
                                    echo http_build_query(array_merge($_GET, ['sort' => 'oldest'])); 
                                ?>" class="px-3 py-1.5 rounded-md <?php echo $order_by == 'oldest' ? 'bg-indigo-100 text-indigo-700' : 'bg-gray-100 text-gray-700'; ?>">
                                    Oldest
                                </a>
                                <a href="?<?php 
                                    echo http_build_query(array_merge($_GET, ['sort' => 'popular'])); 
                                ?>" class="px-3 py-1.5 rounded-md <?php echo $order_by == 'popular' ? 'bg-indigo-100 text-indigo-700' : 'bg-gray-100 text-gray-700'; ?>">
                                    Most Popular
                                </a>
                                <a href="?<?php 
                                    echo http_build_query(array_merge($_GET, ['sort' => 'title_asc'])); 
                                ?>" class="px-3 py-1.5 rounded-md <?php echo $order_by == 'title_asc' ? 'bg-indigo-100 text-indigo-700' : 'bg-gray-100 text-gray-700'; ?>">
                                    Title A-Z
                                </a>
                                <a href="?<?php 
                                    echo http_build_query(array_merge($_GET, ['sort' => 'title_desc'])); 
                                ?>" class="px-3 py-1.5 rounded-md <?php echo $order_by == 'title_desc' ? 'bg-indigo-100 text-indigo-700' : 'bg-gray-100 text-gray-700'; ?>">
                                    Title Z-A
                                </a>
                            </div>
                        </div>
                        
                        <!-- Premium Filter -->
                        <div class="flex items-center space-x-3">
                            <label class="flex items-center">
                                <input type="checkbox" name="is_premium" value="1" class="w-5 h-5 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                                    <?php echo isset($_GET['is_premium']) && $_GET['is_premium'] == '1' ? 'checked' : ''; ?>>
                                <span class="ml-2 text-gray-700">Premium Only</span>
                            </label>
                            <button type="submit" class="px-6 py-2.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition duration-200">
                                <i class="fas fa-filter mr-2"></i>Apply Filters
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Resources Count -->
            <div class="text-gray-600 mb-4">
                Showing <?php echo count($resources); ?> of <?php echo $total_resources; ?> resources
            </div>

            <!-- Resources Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                <?php if (empty($resources)): ?>
                <div class="col-span-3 text-center py-12">
                    <i class="fas fa-search text-gray-400 text-5xl mb-4"></i>
                    <h3 class="text-2xl font-semibold text-gray-600 mb-2">No resources found</h3>
                    <p class="text-gray-500">Try adjusting your search or filter criteria</p>
                </div>
                <?php else: ?>
                <?php foreach ($resources as $resource): ?>
                <div class="resource-card bg-white rounded-xl shadow-sm overflow-hidden relative">
                    <?php if ($resource['is_premium']): ?>
                    <div class="premium-badge">
                        <i class="fas fa-crown"></i>
                    </div>
                    <?php endif; ?>
                    
                    <div class="p-6">
                        <div class="flex items-start justify-between mb-4">
                            <div>
                                <h3 class="text-xl font-semibold text-gray-800 mb-1">
                                    <?php echo htmlspecialchars($resource['title']); ?>
                                </h3>
                                <div class="flex items-center text-gray-500 text-sm">
                                    <span class="mr-3">
                                        <i class="far fa-calendar-alt mr-1"></i>
                                        <?php echo date('M d, Y', strtotime($resource['display_date'])); ?>
                                    </span>
                                    <span>
                                        <i class="far fa-eye mr-1"></i>
                                        <?php echo number_format($resource['download_count']); ?> downloads
                                    </span>
                                </div>
                            </div>
                            <div class="flex flex-col items-center">
                                <span class="text-3xl" style="color: <?php echo getFileColor($resource['file_type']); ?>">
                                    <i class="fas <?php echo getFileIcon($resource['file_type']); ?>"></i>
                                </span>
                                <span class="text-xs font-medium mt-1">
                                    <?php echo strtoupper(htmlspecialchars($resource['file_type'])); ?>
                                </span>
                            </div>
                        </div>
                        
                        <p class="text-gray-600 mb-4 line-clamp-2">
                            <?php echo htmlspecialchars($resource['description']); ?>
                        </p>
                        
                        <div class="flex flex-wrap gap-2 mb-4">
                            <span class="category-badge bg-blue-100 text-blue-800">
                                <?php echo htmlspecialchars($resource['category']); ?>
                            </span>
                            <span class="category-badge bg-purple-100 text-purple-800">
                                <?php echo htmlspecialchars($resource['target_year']); ?>
                            </span>
                        </div>
                        
                        <div class="flex items-center justify-between">
                            <div class="flex items-center">
                                <img src="<?php echo $resource['profilePicture'] ?? 'default-avatar.png'; ?>" 
                                     alt="Author" class="w-8 h-8 rounded-full mr-2">
                                <span class="text-sm text-gray-700">
                                    <?php echo htmlspecialchars($resource['firstName'] . ' ' . $resource['lastName']); ?>
                                </span>
                            </div>
                            
                            <div class="flex items-center space-x-3">
                                <button class="like-button text-gray-500 hover:text-red-500 transition-colors" 
                                        data-resource-id="<?php echo $resource['id']; ?>">
                                    <i class="<?php 
                                        // Check if user has liked this resource
                                        $like_check = $db->prepare("SELECT id FROM resource_likes WHERE user_id = ? AND resource_id = ?");
                                        $like_check->bind_param("ii", $userId, $resource['id']);
                                        $like_check->execute();
                                        echo $like_check->get_result()->num_rows > 0 ? 'fas' : 'far'; 
                                    ?> fa-heart"></i>
                                    <span class="like-count"><?php echo $resource['like_count']; ?></span>
                                </button>
                                
                                <a href="view_resource.php?id=<?php echo $resource['id']; ?>" 
                                   class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition duration-200">
                                    <?php if ($resource['is_premium']): ?>
                                        <i class="fas fa-lock mr-1"></i> $<?php echo number_format($resource['price'], 2); ?>
                                    <?php else: ?>
                                        <i class="fas fa-download mr-1"></i> Download
                                    <?php endif; ?>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <div class="flex justify-center mt-8">
                <div class="inline-flex">
                    <?php if ($page > 1): ?>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" 
                       class="pagination-item text-gray-700 hover:bg-gray-100">
                        <i class="fas fa-chevron-left"></i>
                    </a>
                    <?php else: ?>
                    <span class="pagination-item text-gray-400 disabled">
                        <i class="fas fa-chevron-left"></i>
                    </span>
                    <?php endif; ?>
                    
                    <?php
                    // Calculate range of pages to show
                    $start_page = max(1, $page - 2);
                    $end_page = min($total_pages, $start_page + 4);
                    if ($end_page - $start_page < 4) {
                        $start_page = max(1, $end_page - 4);
                    }
                    
                    // First page link
                    if ($start_page > 1): ?>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => 1])); ?>" 
                       class="pagination-item text-gray-700 hover:bg-gray-100">1</a>
                    <?php if ($start_page > 2): ?>
                    <span class="pagination-item text-gray-500">...</span>
                    <?php endif; ?>
                    <?php endif; ?>
                    
                    <?php for($i = $start_page; $i <= $end_page; $i++): ?>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" 
                       class="pagination-item <?php echo $i == $page ? 'active' : 'text-gray-700 hover:bg-gray-100'; ?>">
                        <?php echo $i; ?>
                    </a>
                    <?php endfor; ?>
                    
                    <?php if ($end_page < $total_pages): ?>
                    <?php if ($end_page < $total_pages - 1): ?>
                    <span class="pagination-item text-gray-500">...</span>
                    <?php endif; ?>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $total_pages])); ?>" 
                       class="pagination-item text-gray-700 hover:bg-gray-100"><?php echo $total_pages; ?></a>
                    <?php endif; ?>
                    
                    <?php if ($page < $total_pages): ?>
                    <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" 
                       class="pagination-item text-gray-700 hover:bg-gray-100">
                        <i class="fas fa-chevron-right"></i>
                    </a>
                    <?php else: ?>
                    <span class="pagination-item text-gray-400 disabled">
                        <i class="fas fa-chevron-right"></i>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Upload Resource Button -->
    <button id="uploadBtn" class="floating-btn">
        <i class="fas fa-plus"></i>
    </button>

    <!-- Upload Modal -->
    <div id="uploadModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden">
        <div class="bg-white rounded-lg w-full max-w-3xl max-h-screen overflow-y-auto">
            <div class="p-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold text-gray-800">Upload New Resource</h2>
                    <button id="closeModalBtn" class="text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                </div>
                
                <form action="" method="POST" enctype="multipart/form-data" class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="title" class="block text-gray-700 font-medium mb-2">Resource Title*</label>
                            <input type="text" id="title" name="title" required 
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500">
                        </div>
                        
                        <div>
                            <label for="category" class="block text-gray-700 font-medium mb-2">Category*</label>
                            <select id="category" name="category" required 
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500">
                                <option value="">Select Category</option>
                                <option value="Lecture Notes">Lecture Notes</option>
                                <option value="Assignments">Assignments</option>
                                <option value="Quizzes">Quizzes</option>
                                <option value="Exams">Exams</option>
                                <option value="Projects">Projects</option>
                                <option value="Textbooks">Textbooks</option>
                                <option value="Research Papers">Research Papers</option>
                                <option value="Study Guides">Study Guides</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        
                        <div>
                            <label for="target_year" class="block text-gray-700 font-medium mb-2">Target Year/Level*</label>
                            <select id="target_year" name="target_year" required 
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500">
                                <option value="">Select Year</option>
                                <option value="Freshman">Freshman</option>
                                <option value="Sophomore">Sophomore</option>
                                <option value="Junior">Junior</option>
                                <option value="Senior">Senior</option>
                                <option value="Graduate">Graduate</option>
                                <option value="All Levels">All Levels</option>
                            </select>
                        </div>
                        
                        <div class="col-span-1 md:col-span-2">
                            <label for="description" class="block text-gray-700 font-medium mb-2">Description*</label>
                            <textarea id="description" name="description" rows="4" required 
                                      class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"></textarea>
                            <p class="text-sm text-gray-500 mt-1">Provide a detailed description of your resource (min. 30 characters)</p>
                        </div>
                        
                        <div class="col-span-1 md:col-span-2">
                            <label class="block text-gray-700 font-medium mb-2">Resource File*</label>
                            <div class="flex items-center justify-center w-full">
                                <label class="w-full flex flex-col items-center px-4 py-6 bg-white text-indigo-500 rounded-lg border-2 border-indigo-500 border-dashed cursor-pointer hover:bg-indigo-50 transition-colors">
                                    <i class="fas fa-cloud-upload-alt text-3xl"></i>
                                    <span class="mt-2 text-center">Click to upload or drag and drop</span>
                                    <span class="text-sm text-gray-500 mt-1">PDF, DOC, PPT, XLS, ZIP, and more (Max: 50MB)</span>
                                    <input type="file" name="resource_file" class="hidden" required>
                                </label>
                            </div>
                        </div>
                        
                        <div class="col-span-1 md:col-span-2">
                            <div class="flex items-start">
                                <div class="flex items-center h-6">
                                    <input id="is_premium" name="is_premium" type="checkbox" 
                                           class="w-5 h-5 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500">
                                </div>
                                <div class="ml-3">
                                    <label for="is_premium" class="text-gray-700 font-medium">Make this a premium resource</label>
                                    <p class="text-sm text-gray-500">Premium resources require payment to download</p>
                                </div>
                            </div>
                        </div>
                        
                        <div id="priceField" class="hidden">
                            <label for="price" class="block text-gray-700 font-medium mb-2">Price ($)*</label>
                            <input type="number" id="price" name="price" min="0.50" step="0.01" value="1.99" 
                                   class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500">
                            <p class="text-sm text-gray-500 mt-1">Set a price between $0.50 and $50.00</p>
                        </div>
                    </div>
                    
                    <div class="pt-4 border-t border-gray-200">
                        <button type="submit" name="upload_resource" 
                                class="w-full md:w-auto px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition duration-200">
                            <i class="fas fa-upload mr-2"></i>Upload Resource
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Notifications Panel -->
    <div id="notificationsPanel" class="fixed right-0 top-16 w-80 bg-white shadow-lg rounded-bl-lg z-20 transform translate-x-full transition-transform duration-300 ease-in-out">
        <div class="p-4 border-b border-gray-200">
            <h3 class="text-lg font-semibold text-gray-800">Notifications</h3>
        </div>
        <div class="custom-scrollbar max-h-96 overflow-y-auto">
            <div class="p-4 border-b border-gray-100 hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="bg-blue-100 rounded-full p-2 mr-3">
                        <i class="fas fa-download text-blue-500"></i>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-gray-800">Your resource "Calculus Study Guide" has been downloaded 10 times!</p>
                        <p class="text-xs text-gray-500 mt-1">2 hours ago</p>
                    </div>
                </div>
            </div>
            <div class="p-4 border-b border-gray-100 hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="bg-green-100 rounded-full p-2 mr-3">
                        <i class="fas fa-dollar-sign text-green-500"></i>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-gray-800">You earned $2.99 from a premium resource purchase!</p>
                        <p class="text-xs text-gray-500 mt-1">1 day ago</p>
                    </div>
                </div>
            </div>
            <div class="p-4 border-b border-gray-100 hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="bg-purple-100 rounded-full p-2 mr-3">
                        <i class="fas fa-heart text-purple-500"></i>
                    </div>
                    <div>
                        <p class="text-sm font-medium text-gray-800">Sara Johnson liked your "Physics Notes" resource</p>
                        <p class="text-xs text-gray-500 mt-1">3 days ago</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="p-4 border-t border-gray-200 text-center">
            <a href="notifications.php" class="text-indigo-600 hover:text-indigo-800 text-sm font-medium">
                View All Notifications
            </a>
        </div>
    </div>

    <!-- JavaScript for interactions -->
    <script>
        // Upload Modal
        const uploadBtn = document.getElementById('uploadBtn');
        const uploadModal = document.getElementById('uploadModal');
        const closeModalBtn = document.getElementById('closeModalBtn');
        
        uploadBtn.addEventListener('click', () => {
            uploadModal.classList.remove('hidden');
            document.body.classList.add('overflow-hidden');
        });
        
        closeModalBtn.addEventListener('click', () => {
            uploadModal.classList.add('hidden');
            document.body.classList.remove('overflow-hidden');
        });
        
        // Close modal when clicking outside
        uploadModal.addEventListener('click', (e) => {
            if (e.target === uploadModal) {
                uploadModal.classList.add('hidden');
                document.body.classList.remove('overflow-hidden');
            }
        });
        
        // Premium checkbox toggle price field
        const isPremiumCheckbox = document.getElementById('is_premium');
        const priceField = document.getElementById('priceField');
        
        isPremiumCheckbox.addEventListener('change', () => {
            priceField.classList.toggle('hidden', !isPremiumCheckbox.checked);
            if (isPremiumCheckbox.checked) {
                document.getElementById('price').setAttribute('required', 'required');
            } else {
                document.getElementById('price').removeAttribute('required');
            }
        });
        
        // File upload preview
        const fileInput = document.querySelector('input[type=file]');
        fileInput.addEventListener('change', (e) => {
            const fileName = e.target.files[0]?.name;
            if (fileName) {
                const fileLabel = fileInput.previousElementSibling;
                fileLabel.querySelector('span:nth-child(2)').textContent = fileName;
            }
        });
        
        // Like button functionality
        document.querySelectorAll('.like-button').forEach(button => {
            button.addEventListener('click', async (e) => {
                const resourceId = button.dataset.resourceId;
                
                try {
                    const response = await fetch('resources.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `action=toggle_like&resource_id=${resourceId}`
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        // Update UI
                        const heartIcon = button.querySelector('i');
                        heartIcon.classList.toggle('far', !data.liked);
                        heartIcon.classList.toggle('fas', data.liked);
                        button.querySelector('.like-count').textContent = data.likeCount;
                        
                        // Animate heart
                        heartIcon.classList.add('animate-pulse');
                        setTimeout(() => {
                            heartIcon.classList.remove('animate-pulse');
                        }, 500);
                    }
                } catch (error) {
                    console.error('Error:', error);
                }
            });
        });
        
        // Notifications Panel Toggle
        function toggleNotifications() {
            const panel = document.getElementById('notificationsPanel');
            panel.classList.toggle('translate-x-full');
        }
        
        // Auto-hide success message after 5 seconds
        const successAlert = document.getElementById('successAlert');
        if (successAlert) {
            setTimeout(() => {
                successAlert.style.opacity = '0';
                setTimeout(() => {
                    successAlert.style.display = 'none';
                }, 500);
            }, 5000);
        }

        // Description character counter
        const descriptionField = document.getElementById('description');
        if (descriptionField) {
            descriptionField.addEventListener('input', function() {
                const charCount = this.value.length;
                if (charCount < 30) {
                    this.classList.add('border-red-300');
                    this.classList.remove('border-gray-300');
                } else {
                    this.classList.remove('border-red-300');
                    this.classList.add('border-gray-300');
                }
            });
        }
    </script>
</body>
</html>