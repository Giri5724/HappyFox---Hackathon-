<?php
// Enable error reporting for debugging (you can remove this in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session if not already started
if(!session_id()){
    session_start();
}

// Include database connection
require("config/db.php");

// Set page title
$title = "Chat Room";
require("layout/head.php");

// Check if user is logged in
if(checkUserSession($db) !== TRUE){
    header("location: $_LOGIN_FILE");
    exit;
}

// Check if room_id is provided
if(!empty($_GET["room_id"])){
    $room_id = $_GET["room_id"];
    $user = searchUser_bSession($db, $_COOKIE["user_session"]);
    
    // Check if room exists
    $query = mysqli_query($db, "SELECT * FROM chat_room WHERE room_id=$room_id");
    if(mysqli_num_rows($query) > 0){
        $room_data = mysqli_fetch_array($query);
        
        // Check if user is member or owner
        $isMember = false;
        $isOwner = false;
        
        $mem_query = mysqli_query($db, "SELECT * FROM room_member WHERE user_id={$user["id"]} AND room_id=$room_id");
        
        if($user["id"] == $room_data["owner"]){
            $isOwner = true;
            $isMember = true;
        } elseif(mysqli_num_rows($mem_query) > 0){
            $isMember = true;
        }
    } else {
        // Room doesn't exist, redirect to home
        echo "<script>alert('Room does not exist!'); window.location.href='" . $_HOME_FILE . "';</script>";
        exit;
    }
} else {
    // No room_id provided, redirect to home
    echo "<script>alert('No room ID provided!'); window.location.href='" . $_HOME_FILE . "';</script>";
    exit;
}

// Set user data for menu
$userName = $user["firstName"] . " " . $user["lastName"];
$profilePicture = $user["profilePicture"] ?? "default-avatar.png";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($room_data["room_name"]); ?> - Chat Room</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .chat-message {
            margin-bottom: 10px;
        }
        .message-content {
            padding: 10px;
            border-radius: 10px;
            max-width: 75%;
            display: inline-block;
        }
        .left .message-content {
            background-color: #f0f0f0;
        }
        .right .message-content {
            background-color: #dcf8c6;
            float: right;
        }
        .message-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }
        .chat-discussion {
            height: 60vh;
            overflow-y: auto;
            padding: 20px;
        }
        .custom-scrollbar {
            scrollbar-width: thin;
            scrollbar-color: rgba(156, 163, 175, 0.5) transparent;
        }
        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background-color: rgba(156, 163, 175, 0.5);
            border-radius: 3px;
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-10">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="<?php echo $_HOME_FILE; ?>" class="flex items-center">
                        <i class="fas fa-comments text-blue-600 text-2xl mr-2"></i>
                        <span class="text-xl font-bold text-gray-800">VN</span>
                    </a>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <button onclick="toggleNotifications()" class="text-gray-600 hover:text-gray-800">
                            <i class="fas fa-bell"></i>
                            <span class="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 text-xs flex items-center justify-center">2</span>
                        </button>
                    </div>
                    <div class="relative group">
                        <button class="flex items-center space-x-2">
                            <img src="<?php echo $profilePicture; ?>" 
                                 alt="Profile" 
                                 class="w-8 h-8 rounded-full">
                            <span class="text-gray-700"><?php echo htmlspecialchars($userName); ?></span>
                        </button>
                        <div class="absolute right-0 w-48 mt-2 bg-white rounded-md shadow-lg hidden group-hover:block">
                            <a href="account.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-user mr-2"></i> Account
                            </a>
                            <a href="create_room.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-plus mr-2"></i> Create Room
                            </a>
                            <a href="my_room.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-th-large mr-2"></i> My Rooms
                            </a>
                            <?php if(isset($isAdmin) && $isAdmin): ?>
                            <a href="secret_admin.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-cogs mr-2"></i> Admin Area
                            </a>
                            <?php endif; ?>
                            <a href="<?php echo $_LOGOUT_FILE ?? 'logout.php'; ?>" class="block px-4 py-2 text-red-600 hover:bg-gray-100">
                                <i class="fas fa-sign-out-alt mr-2"></i> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="flex min-h-screen pt-16">
        <!-- Sidebar -->
        <div class="w-64 bg-white shadow-lg fixed h-full">
            <div class="p-4">
                <div class="flex items-center mb-6">
                    <img src="<?php echo $profilePicture; ?>" alt="Profile" class="w-10 h-10 rounded-full mr-3">
                    <div>
                        <h3 class="font-medium text-gray-800"><?php echo htmlspecialchars($userName); ?></h3>
                        <span class="text-xs text-gray-500">Member</span>
                    </div>
                </div>
                <h2 class="text-xl font-semibold text-gray-800 mb-4">Menu</h2>
                <ul class="space-y-2">
                    <li>
                        <a href="<?php echo $_HOME_FILE ?? 'home.php'; ?>" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-home"></i>
                            <span>Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="account.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-user"></i>
                            <span>Account</span>
                        </a>
                    </li>
                    <li>
                        <a href="create_room.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-plus"></i>
                            <span>Create Room</span>
                        </a>
                    </li>
                    <li>
                        <a href="my_room.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-th-large"></i>
                            <span>My Room</span>
                        </a>
                    </li>
                    <?php if(isset($isAdmin) && $isAdmin): ?>
                    <li>
                        <a href="secret_admin.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-cogs"></i>
                            <span>Admin Area</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li>
                        <a href="<?php echo $_LOGOUT_FILE ?? 'logout.php'; ?>" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-red-50 text-red-600">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="flex-1 ml-64 p-8">
            <!-- Page Header -->
            <div class="mb-6">
                <h1 class="text-2xl font-bold text-gray-800"><?php echo htmlspecialchars($room_data["room_name"] ?: "Chat Room"); ?></h1>
                <div class="text-sm breadcrumbs">
                    <ul class="flex space-x-2 text-gray-500">
                        <li><a href="<?php echo $_HOME_FILE; ?>" class="text-gray-500 hover:text-blue-600">Home</a></li>
                        <li><a href="my_room.php" class="text-gray-500 hover:text-blue-600">My Rooms</a></li>
                        <li class="text-blue-600"><?php echo htmlspecialchars($room_data["room_name"] ?: "Chat Room"); ?></li>
                    </ul>
                </div>
            </div>

            <!-- Room Info -->
            <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
                <div class="flex justify-between items-center mb-2">
                    <h2 class="text-lg font-semibold">Room Information</h2>
                    <?php if($isOwner): ?>
                        <div class="flex space-x-2">
                            <a href="request.php?room_id=<?php echo $room_id; ?>" class="px-3 py-1 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 text-sm">
                                <i class="fas fa-user-plus mr-1"></i> Requests
                            </a>
                            <a href="member.php?room_id=<?php echo $room_id; ?>" class="px-3 py-1 bg-green-100 text-green-700 rounded-md hover:bg-green-200 text-sm">
                                <i class="fas fa-users mr-1"></i> Members
                            </a>
                            <a href="room_options.php?room_id=<?php echo $room_id; ?>" class="px-3 py-1 bg-purple-100 text-purple-700 rounded-md hover:bg-purple-200 text-sm">
                                <i class="fas fa-cog mr-1"></i> Options
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
                <p class="text-gray-600 mb-2">
                    <span class="font-medium">Room ID:</span> <?php echo $room_id; ?>
                </p>
                <p class="text-gray-600">
                    <span class="font-medium">Description:</span> 
                    <?php echo !empty($room_data["room_description"]) ? htmlspecialchars($room_data["room_description"]) : "No description provided"; ?>
                </p>
            </div>

            <?php if($isMember): ?>
            <!-- Chat Area -->
            <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                <!-- Chat Messages -->
                <div class="chat-discussion custom-scrollbar" id="chat-messages">
                    <!-- Messages will be loaded here via JavaScript -->
                </div>
                
                <!-- Message Input -->
                <div class="border-t p-4">
                    <form id="send-message" class="flex">
                        <textarea 
                            id="txt-message" 
                            name="txt-message" 
                            class="flex-1 border rounded-l-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500" 
                            placeholder="Type your message here..." 
                            rows="2"
                            style="resize: none;"
                        ></textarea>
                        <button 
                            type="submit" 
                            class="bg-blue-600 text-white px-4 rounded-r-lg hover:bg-blue-700 transition duration-200"
                        >
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </form>
                </div>
            </div>
            <?php else: ?>
            <!-- Request to Join -->
            <div class="bg-white rounded-lg shadow-sm p-6">
                <div class="text-center py-8">
                    <div class="w-16 h-16 bg-yellow-100 rounded-full mx-auto flex items-center justify-center mb-4">
                        <i class="fas fa-user-plus text-yellow-600 text-2xl"></i>
                    </div>
                    <h3 class="text-gray-700 font-medium mb-2">You're not a member of this room</h3>
                    <p class="text-gray-500 mb-4">Join this room to participate in the conversation</p>
                    
                    <?php 
                    $query = mysqli_query($db, "SELECT * FROM request_join WHERE user_id={$user["id"]} AND room_id=$room_id");
                    if(mysqli_num_rows($query) == 0): 
                    ?>
                        <button id="request_join" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200">
                            Request to Join
                        </button>
                    <?php else: ?>
                        <button disabled class="px-4 py-2 bg-gray-400 text-white rounded-lg cursor-not-allowed">
                            Request Pending
                        </button>
                        <p class="text-sm text-gray-500 mt-2">Your request is waiting for approval from the room owner.</p>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Notification Modal -->
    <div id="notificationModal" class="fixed right-0 mt-16 mr-4 w-80 bg-white rounded-lg shadow-xl hidden z-50">
        <div class="p-4 border-b">
            <h3 class="text-lg font-semibold">Notifications</h3>
        </div>
        <div class="max-h-96 overflow-y-auto">
            <div class="p-4 border-b hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                            <i class="fas fa-comment text-blue-600"></i>
                        </div>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium">New message in Study Group</p>
                        <p class="text-sm text-gray-500">John posted a new message</p>
                        <p class="text-xs text-gray-400 mt-1">2 hours ago</p>
                    </div>
                </div>
            </div>
            <div class="p-4 border-b hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                            <i class="fas fa-user-plus text-green-600"></i>
                        </div>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium">New member joined</p>
                        <p class="text-sm text-gray-500">Sarah joined your Math Help room</p>
                        <p class="text-xs text-gray-400 mt-1">5 hours ago</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="p-4 border-t">
            <a href="notifications.php" class="text-sm text-blue-600 hover:text-blue-800">View all notifications</a>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery-3.1.1.min.js"></script>
    <script>
        var logChat = "";
        
        // Toggle notifications panel
        function toggleNotifications() {
            const modal = document.getElementById('notificationModal');
            modal.classList.toggle('hidden');
        }
        
        // Close notification modal when clicking outside
        window.onclick = function(event) {
            const notificationModal = document.getElementById('notificationModal');
            
            if (!event.target.closest('#notificationModal') && 
                !event.target.closest('button[onclick="toggleNotifications()"]')) {
                notificationModal.classList.add('hidden');
            }
        }
        
        <?php if($isMember): ?>
        // Initialize chat functionality
        $(document).ready(function() {
            // Function to fetch messages
            function fetchMessages() {
                $.ajax({
                    url: 'ajax/message/fetch_message.php?room_id=<?php echo $room_id; ?>',
                    dataType: 'json',
                    cache: false,
                    success: function(response) {
                        if(JSON.stringify(response) != logChat) {
                            if(response.error) {
                                alert(response.message);
                                location.reload();
                                return;
                            }
                            
                            var chatHtml = "";
                            
                            response.forEach(function(message) {
                                if(message.owner) {
                                    // Current user's messages (right side)
                                    chatHtml += `
                                        <div class="chat-message right flex mb-4">
                                            <div class="flex-1"></div>
                                            <div class="max-w-md">
                                                <div class="flex justify-end items-center mb-1">
                                                    <span class="text-xs text-gray-500 mr-2">${message.time_ago}</span>
                                                    <span class="font-medium text-sm">${message.sender}</span>
                                                    <img src="${message.profilePicture}" class="w-6 h-6 rounded-full ml-2" alt="Avatar">
                                                </div>
                                                <div class="message-content bg-blue-100 text-gray-800">
                                                    ${message.message}
                                                </div>
                                            </div>
                                        </div>
                                    `;
                                } else {
                                    // Other users' messages (left side)
                                    chatHtml += `
                                        <div class="chat-message left flex mb-4">
                                            <div class="max-w-md">
                                                <div class="flex items-center mb-1">
                                                    <img src="${message.profilePicture}" class="w-6 h-6 rounded-full mr-2" alt="Avatar">
                                                    <span class="font-medium text-sm">${message.sender}</span>
                                                    <span class="text-xs text-gray-500 ml-2">${message.time_ago}</span>
                                                </div>
                                                <div class="message-content bg-gray-100 text-gray-800">
                                                    ${message.message}
                                                </div>
                                            </div>
                                            <div class="flex-1"></div>
                                        </div>
                                    `;
                                }
                            });
                            
                            $('#chat-messages').html(chatHtml);
                            
                            // Auto-scroll to bottom of chat
                            var chatContainer = document.getElementById('chat-messages');
                            chatContainer.scrollTop = chatContainer.scrollHeight;
                            
                            // Update the log to prevent unnecessary DOM updates
                            logChat = JSON.stringify(response);
                        }
                    }
                });
            }
            
            // Initial fetch and setup interval
            fetchMessages();
            setInterval(fetchMessages, 2000);
            
            // Handle message sending
            $('#send-message').on('submit', function(e) {
                e.preventDefault();
                
                if ($('#txt-message').val().trim() === '') {
                    return;
                }
                
                $.ajax({
                    url: 'ajax/message/send.php?room_id=<?php echo $room_id; ?>',
                    type: 'POST',
                    data: new FormData(this),
                    contentType: false,
                    cache: false,
                    processData: false,
                    beforeSend: function() {
                        $('#txt-message').prop('disabled', true);
                    },
                    complete: function() {
                        $('#txt-message').prop('disabled', false).val('').focus();
                    }
                });
            });
            
            // Handle enter key in textarea
            $('#txt-message').keypress(function(e) {
                if (e.which === 13 && !e.shiftKey) {
                    e.preventDefault();
                    $('#send-message').submit();
                }
            });
        });
        <?php else: ?>
        // Handle join request
        $(document).ready(function() {
            $('#request_join').on('click', function() {
                $.ajax({
                    url: 'ajax/request/join_room.php',
                    type: 'POST',
                    data: {
                        room_id: <?php echo $room_id; ?>
                    },
                    dataType: 'json',
                    beforeSend: function() {
                        $('#request_join').text('Requesting...').prop('disabled', true);
                    },
                    success: function(response) {
                        if(response.success) {
                            $('#request_join').text('Request Pending').addClass('bg-gray-400').removeClass('bg-blue-600 hover:bg-blue-700');
                            // Add message below button
                            $('<p class="text-sm text-gray-500 mt-2">Your request is waiting for approval from the room owner.</p>').insertAfter('#request_join');
                        } else {
                            $('#request_join').text('Request to Join').prop('disabled', false);
                            alert('Error: ' + response.message);
                        }
                    },
                    error: function() {
                        $('#request_join').text('Request to Join').prop('disabled', false);
                        alert('An error occurred. Please try again.');
                    }
                });
            });
        });
        <?php endif; ?>
    </script>
</body>
</html>