<?php 
if(!session_id()){
    session_start();
}
require("config/db.php");
$title = "Home";
require("layout/head.php"); // $title = "page title"
if(checkUserSession($db) !== True){
    header("location: $_LOGIN_FILE");exit; //$_LOGIN_FILE --> /config/value.php
}
$user = searchUser_bSession($db, $_COOKIE["user_session"]);
$homeChatMenu = "active";
$userName = $user["firstName"] . " " . $user["lastName"];
$profilePicture = $user["profilePicture"] ?? "default-avatar.png";
$inLogin = true;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<style>
    .notification-badge {
        animation: pulse 2s infinite;
    }

    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.1); }
        100% { transform: scale(1); }
    }

    /* Custom scrollbar */
    .custom-scrollbar {
        scrollbar-width: thin;
        scrollbar-color: rgba(156, 163, 175, 0.5) transparent;
    }

    .custom-scrollbar::-webkit-scrollbar {
        width: 6px;
    }

    .custom-scrollbar::-webkit-scrollbar-track {
        background: transparent;
    }

    .custom-scrollbar::-webkit-scrollbar-thumb {
        background-color: rgba(156, 163, 175, 0.5);
        border-radius: 3px;
    }

    /* Card hover effects */
    .resource-card {
        transition: all 0.3s ease;
    }

    .resource-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    }

    /* Form focus effects */
    .form-input:focus {
        box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.5);
        outline: none;
    }

    /* Toast notifications */
    .toast-notification {
        animation: slideIn 0.3s ease forwards;
    }

    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    /* Modal animations */
    .modal {
        animation: fadeIn 0.3s ease forwards;
    }

    .modal-content {
        animation: slideUp 0.3s ease forwards;
    }

    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    @keyframes slideUp {
        from {
            transform: translateY(20px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }
</style>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-10">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="home.php" class="flex items-center">
                        <i class="fas fa-comments text-blue-600 text-2xl mr-2"></i>
                        <span class="text-xl font-bold text-gray-800">VN</span>
                    </a>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <button onclick="toggleNotifications()" class="text-gray-600 hover:text-gray-800">
                            <i class="fas fa-bell"></i>
                            <span class="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 text-xs flex items-center justify-center">2</span>
                        </button>
                    </div>
                    <div class="relative group">
                        <button class="flex items-center space-x-2">
                            <img src="<?php echo $profilePicture; ?>" 
                                 alt="Profile" 
                                 class="w-8 h-8 rounded-full">
                            <span class="text-gray-700"><?php echo htmlspecialchars($userName); ?></span>
                        </button>
                        <div class="absolute right-0 w-48 mt-2 bg-white rounded-md shadow-lg hidden group-hover:block">
                            <a href="account.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-user mr-2"></i> Account
                            </a>
                            <a href="create_room.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-plus mr-2"></i> Create Room
                            </a>
                            <a href="my_room.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-th-large mr-2"></i> My Rooms
                            </a>
                            <?php if(isset($isAdmin) && $isAdmin): ?>
                            <a href="secret_admin.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-cogs mr-2"></i> Admin Area
                            </a>
                            <?php endif; ?>
                            <a href="<?= $_LOGOUT_FILE ?? 'logout.php' ?>" class="block px-4 py-2 text-red-600 hover:bg-gray-100">
                                <i class="fas fa-sign-out-alt mr-2"></i> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="flex min-h-screen pt-16">
        <!-- Sidebar -->
        <div class="w-64 bg-white shadow-lg fixed h-full">
            <div class="p-4">
                <div class="flex items-center mb-6">
                    <img src="<?php echo $profilePicture; ?>" alt="Profile" class="w-10 h-10 rounded-full mr-3">
                    <div>
                        <h3 class="font-medium text-gray-800"><?php echo htmlspecialchars($userName); ?></h3>
                        <span class="text-xs text-gray-500">Member</span>
                    </div>
                </div>
                <h2 class="text-xl font-semibold text-gray-800 mb-4">Menu</h2>
                <ul class="space-y-2">
                    <li>
                        <a href="<?= $_HOME_FILE ?? 'home.php' ?>" class="flex items-center space-x-2 p-2 rounded-lg bg-blue-50 text-blue-600">
                            <i class="fas fa-home"></i>
                            <span>Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="account.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-user"></i>
                            <span>Account</span>
                        </a>
                    </li>
                    <li>
                        <a href="create_room.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-plus"></i>
                            <span>Create Room</span>
                        </a>
                    </li>
                    <li>
                        <a href="my_room.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-th-large"></i>
                            <span>My Room</span>
                        </a>
                    </li>
                    <?php if(isset($isAdmin) && $isAdmin): ?>
                    <li>
                        <a href="secret_admin.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-cogs"></i>
                            <span>Admin Area</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li>
                        <a href="<?= $_LOGOUT_FILE ?? 'logout.php' ?>" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-red-50 text-red-600">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="flex-1 ml-64 p-8">
            <!-- Page Header -->
            <div class="mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Home</h1>
                <div class="text-sm breadcrumbs">
                    <ul class="flex space-x-2 text-gray-500">
                        <li class="text-blue-600">Home</li>
                    </ul>
                </div>
            </div>

            <!-- Main Content Card -->
            <div class="bg-white rounded-lg shadow-sm p-6">
                <h2 class="text-lg font-semibold mb-4">Join a Room</h2>
                
                <form method="GET" action="<?= $_CHAT_FILE ?>" class="space-y-4">
                    <div class="flex flex-col md:flex-row items-start md:items-center space-y-2 md:space-y-0 md:space-x-4">
                        <label for="room_id" class="w-full md:w-auto text-gray-700 font-medium">Room ID</label>
                        <div class="flex-1 w-full">
                            <input type="text" id="room_id" name="room_id" placeholder="Enter room ID" 
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200 form-input">
                        </div>
                        <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200">
                            Join Room
                        </button>
                    </div>
                </form>

                <?php if(!empty($_SESSION["error_log"])): ?>
                <div class="mt-4 p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg">
                    <?php echo $_SESSION["error_log"]; ?>
                    <?php unset($_SESSION["error_log"]); ?>
                </div>
                <?php endif; ?>

                <!-- Popular Rooms Section -->
                <div class="mt-8">
                    <h3 class="text-lg font-semibold mb-4">Popular Rooms</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <!-- Room Card 1 -->
                        <div class="p-4 border rounded-lg hover:shadow-md transition duration-200 resource-card">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                                    <i class="fas fa-users text-blue-600"></i>
                                </div>
                                <div>
                                    <h4 class="font-medium">General Discussion</h4>
                                    <p class="text-sm text-gray-500">42 members online</p>
                                </div>
                            </div>
                            <div class="mt-3 flex justify-end">
                                <a href="<?= $_CHAT_FILE ?>?room_id=general" class="px-3 py-1 bg-blue-100 text-blue-600 rounded-lg text-sm hover:bg-blue-200">
                                    Join
                                </a>
                            </div>
                        </div>

                        <!-- Room Card 2 -->
                        <div class="p-4 border rounded-lg hover:shadow-md transition duration-200 resource-card">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                                    <i class="fas fa-book text-green-600"></i>
                                </div>
                                <div>
                                    <h4 class="font-medium">Study Group</h4>
                                    <p class="text-sm text-gray-500">18 members online</p>
                                </div>
                            </div>
                            <div class="mt-3 flex justify-end">
                                <a href="<?= $_CHAT_FILE ?>?room_id=study" class="px-3 py-1 bg-blue-100 text-blue-600 rounded-lg text-sm hover:bg-blue-200">
                                    Join
                                </a>
                            </div>
                        </div>

                        <!-- Room Card 3 -->
                        <div class="p-4 border rounded-lg hover:shadow-md transition duration-200 resource-card">
                            <div class="flex items-center space-x-3">
                                <div class="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                                    <i class="fas fa-gamepad text-purple-600"></i>
                                </div>
                                <div>
                                    <h4 class="font-medium">Gaming</h4>
                                    <p class="text-sm text-gray-500">27 members online</p>
                                </div>
                            </div>
                            <div class="mt-3 flex justify-end">
                                <a href="<?= $_CHAT_FILE ?>?room_id=gaming" class="px-3 py-1 bg-blue-100 text-blue-600 rounded-lg text-sm hover:bg-blue-200">
                                    Join
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recent Rooms -->
                <div class="mt-8">
                    <h3 class="text-lg font-semibold mb-4">Your Recent Rooms</h3>
                    <div class="border rounded-lg overflow-hidden">
                        <div class="bg-gray-50 px-4 py-3 border-b">
                            <div class="grid grid-cols-12 text-sm font-medium text-gray-500">
                                <div class="col-span-5">Room Name</div>
                                <div class="col-span-3 text-center">Members</div>
                                <div class="col-span-2 text-center">Status</div>
                                <div class="col-span-2 text-right">Action</div>
                            </div>
                        </div>
                        <div class="divide-y">
                            <!-- Recent Room Item 1 -->
                            <div class="px-4 py-3 hover:bg-gray-50">
                                <div class="grid grid-cols-12 items-center">
                                    <div class="col-span-5 flex items-center">
                                        <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                                            <i class="fas fa-comments text-blue-600 text-sm"></i>
                                        </div>
                                        <span class="font-medium">Math Help</span>
                                    </div>
                                    <div class="col-span-3 text-center">24</div>
                                    <div class="col-span-2 text-center">
                                        <span class="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">Active</span>
                                    </div>
                                    <div class="col-span-2 text-right">
                                        <a href="<?= $_CHAT_FILE ?>?room_id=math" class="text-blue-600 hover:text-blue-800 text-sm">
                                            Rejoin
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Recent Room Item 2 -->
                            <div class="px-4 py-3 hover:bg-gray-50">
                                <div class="grid grid-cols-12 items-center">
                                    <div class="col-span-5 flex items-center">
                                        <div class="w-8 h-8 rounded-full bg-yellow-100 flex items-center justify-center mr-3">
                                            <i class="fas fa-film text-yellow-600 text-sm"></i>
                                        </div>
                                        <span class="font-medium">Movie Fans</span>
                                    </div>
                                    <div class="col-span-3 text-center">31</div>
                                    <div class="col-span-2 text-center">
                                        <span class="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">Active</span>
                                    </div>
                                    <div class="col-span-2 text-right">
                                        <a href="<?= $_CHAT_FILE ?>?room_id=movies" class="text-blue-600 hover:text-blue-800 text-sm">
                                            Rejoin
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Notification Modal -->
    <div id="notificationModal" class="fixed right-0 mt-16 mr-4 w-80 bg-white rounded-lg shadow-xl hidden z-50">
        <div class="p-4 border-b">
            <h3 class="text-lg font-semibold">Notifications</h3>
        </div>
        <div class="max-h-96 overflow-y-auto">
            <div class="p-4 border-b hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                            <i class="fas fa-comment text-blue-600"></i>
                        </div>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium">New message in Study Group</p>
                        <p class="text-sm text-gray-500">John posted a new message</p>
                        <p class="text-xs text-gray-400 mt-1">2 hours ago</p>
                    </div>
                </div>
            </div>
            <div class="p-4 border-b hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                            <i class="fas fa-user-plus text-green-600"></i>
                        </div>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium">Room invitation</p>
                        <p class="text-sm text-gray-500">You've been invited to join Science Club</p>
                        <p class="text-xs text-gray-400 mt-1">5 hours ago</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="p-4 border-t">
            <a href="notifications.php" class="text-sm text-blue-600 hover:text-blue-800">View all notifications</a>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-white py-6 mt-auto border-t">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="text-gray-500 text-sm mb-4 md:mb-0">
                    &copy; <?php echo date('Y'); ?> VN Chat. All rights reserved.
                </div>
                <div class="flex space-x-4">
                    <a href="#" class="text-gray-400 hover:text-gray-600">
                        <i class="fab fa-facebook"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-gray-600">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-gray-600">
                        <i class="fab fa-instagram"></i>
                    </a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="assets/js/jquery-3.1.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="assets/js/inspinia.js"></script>
    <script src="assets/js/plugins/pace/pace.min.js"></script>

    <script>
        function toggleNotifications() {
            const modal = document.getElementById('notificationModal');
            modal.classList.toggle('hidden');
        }

        // Close notification modal when clicking outside
        window.onclick = function(event) {
            const notificationModal = document.getElementById('notificationModal');
            
            if (!event.target.closest('#notificationModal') && 
                !event.target.closest('button[onclick="toggleNotifications()"]')) {
                notificationModal.classList.add('hidden');
            }
        }
    </script>
</body>
</html>