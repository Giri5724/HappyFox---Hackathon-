<?php 
if(!session_id()){
	session_start();
}
require("config/db.php");
$title = "Create room";
require("layout/head.php"); // $title = "page title"

if(checkUserSession($db) !== True){
	header("location: $_HOME_FILE");exit;
}

$user = searchUser_bSession($db, $_COOKIE["user_session"]);
$createRoomMenu = "active";
$userName = $user["firstName"] . " " . $user["lastName"];
$profilePicture = $user["profilePicture"] ?? "default-avatar.png";
$inLogin = true;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Room</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<style>
    .notification-badge {
        animation: pulse 2s infinite;
    }

    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.1); }
        100% { transform: scale(1); }
    }

    .form-input:focus {
        box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.5);
        outline: none;
    }

    .toast-notification {
        animation: slideIn 0.3s ease forwards;
    }

    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
</style>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-10">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="home.php" class="flex items-center">
                        <i class="fas fa-comments text-blue-600 text-2xl mr-2"></i>
                        <span class="text-xl font-bold text-gray-800">VN</span>
                    </a>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <button onclick="toggleNotifications()" class="text-gray-600 hover:text-gray-800">
                            <i class="fas fa-bell"></i>
                            <span class="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 text-xs flex items-center justify-center">2</span>
                        </button>
                    </div>
                    <div class="relative group">
                        <button class="flex items-center space-x-2">
                            <img src="<?php echo $profilePicture; ?>" 
                                 alt="Profile" 
                                 class="w-8 h-8 rounded-full">
                            <span class="text-gray-700"><?php echo htmlspecialchars($userName); ?></span>
                        </button>
                        <div class="absolute right-0 w-48 mt-2 bg-white rounded-md shadow-lg hidden group-hover:block">
                            <a href="account.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-user mr-2"></i> Account
                            </a>
                            <a href="create_room.php" class="block px-4 py-2 text-gray-700 bg-gray-100">
                                <i class="fas fa-plus mr-2"></i> Create Room
                            </a>
                            <a href="my_room.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-th-large mr-2"></i> My Rooms
                            </a>
                            <?php if(isset($isAdmin) && $isAdmin): ?>
                            <a href="secret_admin.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-cogs mr-2"></i> Admin Area
                            </a>
                            <?php endif; ?>
                            <a href="<?= $_LOGOUT_FILE ?? 'logout.php' ?>" class="block px-4 py-2 text-red-600 hover:bg-gray-100">
                                <i class="fas fa-sign-out-alt mr-2"></i> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="flex min-h-screen pt-16">
        <!-- Sidebar -->
        <div class="w-64 bg-white shadow-lg fixed h-full">
            <div class="p-4">
                <div class="flex items-center mb-6">
                    <img src="<?php echo $profilePicture; ?>" alt="Profile" class="w-10 h-10 rounded-full mr-3">
                    <div>
                        <h3 class="font-medium text-gray-800"><?php echo htmlspecialchars($userName); ?></h3>
                        <span class="text-xs text-gray-500">Member</span>
                    </div>
                </div>
                <h2 class="text-xl font-semibold text-gray-800 mb-4">Menu</h2>
                <ul class="space-y-2">
                    <li>
                        <a href="<?= $_HOME_FILE ?? 'home.php' ?>" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-home"></i>
                            <span>Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="account.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-user"></i>
                            <span>Account</span>
                        </a>
                    </li>
                    <li>
                        <a href="create_room.php" class="flex items-center space-x-2 p-2 rounded-lg bg-blue-50 text-blue-600">
                            <i class="fas fa-plus"></i>
                            <span>Create Room</span>
                        </a>
                    </li>
                    <li>
                        <a href="my_room.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-th-large"></i>
                            <span>My Room</span>
                        </a>
                    </li>
                    <?php if(isset($isAdmin) && $isAdmin): ?>
                    <li>
                        <a href="secret_admin.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-cogs"></i>
                            <span>Admin Area</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li>
                        <a href="<?= $_LOGOUT_FILE ?? 'logout.php' ?>" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-red-50 text-red-600">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="flex-1 ml-64 p-8">
            <!-- Page Header -->
            <div class="mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Create Room</h1>
                <div class="text-sm breadcrumbs">
                    <ul class="flex space-x-2 text-gray-500">
                        <li class="text-blue-600">Create Room</li>
                    </ul>
                </div>
            </div>

            <!-- Create Room Form -->
            <div class="bg-white rounded-lg shadow-sm p-6">
                <h2 class="text-lg font-semibold mb-6">Create a New Chat Room</h2>
                
                <form id="create_form" class="space-y-6">
                    <div class="space-y-4">
                        <div>
                            <label for="room_name" class="block text-gray-700 font-medium mb-2">Room Name</label>
                            <input type="text" id="room_name" name="room_name" placeholder="Enter room name" 
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200 form-input">
                            <p class="mt-1 text-sm text-gray-500">Choose a memorable name for your chat room</p>
                        </div>
                        
                        <div>
                            <label for="room_desc" class="block text-gray-700 font-medium mb-2">Room Description</label>
                            <input type="text" id="room_desc" name="room_desc" placeholder="Enter room description" 
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition duration-200 form-input">
                            <p class="mt-1 text-sm text-gray-500">Briefly describe what your room is about</p>
                        </div>
                    </div>
                    
                    <div class="pt-4">
                        <button id="create_button" type="submit" class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200 flex items-center">
                            <i class="fas fa-plus mr-2"></i>
                            Create Room
                        </button>
                    </div>
                </form>
            </div>

            <!-- Room Templates -->
            <div class="mt-8">
                <h2 class="text-lg font-semibold mb-4">Quick Start Templates</h2>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Template 1 -->
                    <div class="bg-white rounded-lg shadow-sm p-4 border border-gray-200 hover:border-blue-300 cursor-pointer transition duration-200">
                        <div class="flex items-center mb-3">
                            <div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                                <i class="fas fa-users text-blue-600"></i>
                            </div>
                            <h3 class="ml-3 font-medium">General Discussion</h3>
                        </div>
                        <p class="text-sm text-gray-600 mb-3">A room for general conversation and casual chat.</p>
                        <button class="w-full py-2 text-blue-600 border border-blue-200 rounded-lg hover:bg-blue-50 transition duration-200 text-sm">
                            Use Template
                        </button>
                    </div>

                    <!-- Template 2 -->
                    <div class="bg-white rounded-lg shadow-sm p-4 border border-gray-200 hover:border-blue-300 cursor-pointer transition duration-200">
                        <div class="flex items-center mb-3">
                            <div class="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                                <i class="fas fa-book text-green-600"></i>
                            </div>
                            <h3 class="ml-3 font-medium">Study Group</h3>
                        </div>
                        <p class="text-sm text-gray-600 mb-3">Perfect for collaborative learning and study sessions.</p>
                        <button class="w-full py-2 text-blue-600 border border-blue-200 rounded-lg hover:bg-blue-50 transition duration-200 text-sm">
                            Use Template
                        </button>
                    </div>

                    <!-- Template 3 -->
                    <div class="bg-white rounded-lg shadow-sm p-4 border border-gray-200 hover:border-blue-300 cursor-pointer transition duration-200">
                        <div class="flex items-center mb-3">
                            <div class="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                                <i class="fas fa-gamepad text-purple-600"></i>
                            </div>
                            <h3 class="ml-3 font-medium">Gaming</h3>
                        </div>
                        <p class="text-sm text-gray-600 mb-3">Connect with other gamers and organize gaming sessions.</p>
                        <button class="w-full py-2 text-blue-600 border border-blue-200 rounded-lg hover:bg-blue-50 transition duration-200 text-sm">
                            Use Template
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Notification Modal -->
    <div id="notificationModal" class="fixed right-0 mt-16 mr-4 w-80 bg-white rounded-lg shadow-xl hidden z-50">
        <div class="p-4 border-b">
            <h3 class="text-lg font-semibold">Notifications</h3>
        </div>
        <div class="max-h-96 overflow-y-auto">
            <div class="p-4 border-b hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                            <i class="fas fa-comment text-blue-600"></i>
                        </div>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium">New message in Study Group</p>
                        <p class="text-sm text-gray-500">John posted a new message</p>
                        <p class="text-xs text-gray-400 mt-1">2 hours ago</p>
                    </div>
                </div>
            </div>
            <div class="p-4 border-b hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                            <i class="fas fa-check-circle text-green-600"></i>
                        </div>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium">Room created successfully</p>
                        <p class="text-sm text-gray-500">Your new room "Math Help" is now active</p>
                        <p class="text-xs text-gray-400 mt-1">5 hours ago</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="p-4 border-t">
            <a href="notifications.php" class="text-sm text-blue-600 hover:text-blue-800">View all notifications</a>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery-3.1.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="assets/js/plugins/toastr/toastr.min.js"></script>
    <script src="assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="assets/js/inspinia.js"></script>
    <script src="assets/js/plugins/pace/pace.min.js"></script>

    <script>
    function toggleNotifications() {
        const modal = document.getElementById('notificationModal');
        modal.classList.toggle('hidden');
    }

    // Close notification modal when clicking outside
    window.onclick = function(event) {
        const notificationModal = document.getElementById('notificationModal');
        
        if (!event.target.closest('#notificationModal') && 
            !event.target.closest('button[onclick="toggleNotifications()"]')) {
            notificationModal.classList.add('hidden');
        }
    }
    
    // Populate form with template data when clicked
    document.querySelectorAll('.grid .bg-white').forEach(template => {
        template.addEventListener('click', function() {
            const title = this.querySelector('h3').textContent;
            const description = this.querySelector('p').textContent;
            
            document.getElementById('room_name').value = title;
            document.getElementById('room_desc').value = description;
        });
    });
    
    // Keep the original Ajax form handling
    $("#create_form").on('submit',(function(e) {
        e.preventDefault();
        $.ajax({
            url: "ajax/request/create_room.php",
            type: "POST",
            data: new FormData(this),
            dataType: 'json',
            contentType: false,
            cache: false,
            processData: false,
            beforeSend: function () {
                $('#create_button').html('<i class="fas fa-spinner fa-spin mr-2"></i> Processing...').prop('disabled', true);
            },
            success: function(r) {
                if(r.success){
                    $("#room_name").val(null);
                    $("#room_desc").val(null);
                    toastr.success(r.message);
                } else {
                    toastr.error(r.message);
                }
            },
            error: function(){
                toastr.error("An error occurred. Please try again.");
            },
            complete: function(){
                $('#create_button').html('<i class="fas fa-plus mr-2"></i> Create Room').prop('disabled', false);
            }
        });
    }));
    </script>
</body>
</html>