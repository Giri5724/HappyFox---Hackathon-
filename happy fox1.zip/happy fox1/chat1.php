<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DosthoMate - Resource Sharing Platform</title>
    <style>
        :root {
            --primary-color: #0077B6;
            --secondary-color: #90E0EF;
            --text-color: #333;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: var(--secondary-color);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        .app-container {
            background-color: white;
            width: 100%;
            max-width: 480px;
            min-height: 600px;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
        }

        .header {
            background-color: var(--primary-color);
            color: white;
            padding: 15px;
            text-align: center;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
        }
        .clock {
            background-color: rgba(255,255,255,0.2);
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9rem;
        }

        .chat-container {
            flex-grow: 1;
            overflow-y: auto;
            padding: 15px;
            display: flex;
            flex-direction: column;
        }

        .message {
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 10px;
            max-width: 80%;
            align-self: flex-start;
            word-wrap: break-word;
        }

        .bot-message {
            background-color: #f0f7ff;
        }

        .user-message {
            background-color: var(--secondary-color);
            align-self: flex-end;
        }

        .input-container {
            display: flex;
            padding: 15px;
            background-color: #f8f9fa;
            border-bottom-left-radius: 15px;
            border-bottom-right-radius: 15px;
        }

        .input-container input {
            flex-grow: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 20px;
            margin-right: 10px;
        }

        .input-container button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
        }

        .button-group {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 10px;
        }

        .chat-button {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
            margin: 5px 0;
        }

        .resource-upload-form {
            display: flex;
            flex-direction: column;
            gap: 10px;
            background-color: #f0f7ff;
            padding: 15px;
            border-radius: 10px;
        }

        .resource-upload-form input,
        .resource-upload-form textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .resource-list {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .resource-item {
            background-color: #f0f7ff;
            padding: 15px;
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .timetable-upload-form {
            display: flex;
            flex-direction: column;
            gap: 10px;
            background-color: #f0f7ff;
            padding: 15px;
            border-radius: 10px;
        }

        .timetable-upload-form input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
         /* Voice Icon Styles */
    .voice-icon {
        position: absolute;
        right: 60px; /* Positioned next to reminder icon */
        top: 50%;
        transform: translateY(-50%);
        cursor: pointer;
        font-size: 24px;
        color: white;
        transition: color 0.3s ease;
    }

    .voice-icon:hover {
        color: #FFD700; /* Golden color on hover */
    }

    .voice-icon.active {
        color: #00FF00; /* Green when active */
        animation: pulse 1s infinite;
    }

    @keyframes pulse {
        0%, 100% { transform: translateY(-50%) scale(1); }
        50% { transform: translateY(-50%) scale(1.1); }
    }

    .header {
        position: relative; /* For absolute positioning of icons */
    }
        
    </style>
</head>
<body>
<div class="app-container">
        <div class="header">
            <h1>DosthoMate</h1>
           
            <div id="clock" class="clock">00:00:00 AM</div>
            
        </div>
        <div class="chat-container" id="chatContainer"></div>
        <div class="input-container">
            <input type="text" id="userInput" placeholder="Type your message...">
            <button onclick="sendMessage()">Send</button>
        </div>
    </div>

    <script>
        // Configuration
        BASE_API_URL = "http://127.0.0.1:7860"
FLOW_ID = "16bff7f5-0abf-474a-9677-d38d11079a38"
ENDPOINT = "gchat"
        // Reminder Functionality
const reminders = [];

function addReminder(time, message) {
    reminders.push({ time, message });
}

function checkReminders(currentTime) {
    reminders.forEach((reminder, index) => {
        if (currentTime === reminder.time) {
            addMessage(reminder.message, 'bot');
            // Optionally remove the reminder after it's triggered
            reminders.splice(index, 1);
        }
    });
}

// Real-time Clock Function
function updateClock() {
    const clockElement = document.getElementById('clock');
    const now = new Date();
    
    let hours = now.getHours();
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const seconds = now.getSeconds().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    
    // Convert to 12-hour format
    hours = hours % 12;
    hours = hours ? hours : 12; // Handle midnight (0 hours)
    hours = hours.toString().padStart(2, '0');
    
    const currentTimeString = `${hours}:${minutes}:${seconds} ${ampm}`;
    clockElement.textContent = currentTimeString;

    // Check for 5-minute reminders
    if (minutes % 5 === 0 && seconds === '00') {
        addReminder(currentTimeString, `Reminder: It's ${currentTimeString}. Stay productive!`);
    }

    // Check reminders
    checkReminders(currentTimeString);
}
        

       // Timetable Functions
       function startTimetableManagement() {
            addMessage('Timetable Management');
            addMessage('What would you like to do?');
            
            showButtons([
                { 
                    text: 'Upload Image', 
                    action: showTimetableImageUploadForm 
                }
            ]);
        }

        function showTimetableImageUploadForm() {
            addMessage('Upload Timetable Image');
            
            const chatContainer = document.getElementById('chatContainer');
            const uploadForm = document.createElement('form');
            uploadForm.className = 'timetable-upload-form';
            uploadForm.innerHTML = `
                <input type="text" id="timetableImageTitle" placeholder="Image Title" required>
                <input type="file" id="timetableImageFile" accept="image/*" required>
                <button type="button" class="chat-button" onclick="uploadTimetableImage()">Upload Image</button>
            `;
            
            addMessage('Please fill in the image details:');
            chatContainer.appendChild(uploadForm);
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }

        function uploadTimetableImage() {
            const title = document.getElementById('timetableImageTitle').value;
            const fileInput = document.getElementById('timetableImageFile');
            
            if (!title || !fileInput.files.length) {
                addMessage('Please fill in all required fields.');
                return;
            }
             // Simulate successful upload
    addMessage('Timetable image uploaded successfully!');
    
    // Clear form
    document.getElementById('timetableImageTitle').value = '';
    fileInput.value = '';
}

        // Real-time Clock Function
        function updateClock() {
            const clockElement = document.getElementById('clock');
            const now = new Date();
            
            let hours = now.getHours();
            const minutes = now.getMinutes().toString().padStart(2, '0');
            const seconds = now.getSeconds().toString().padStart(2, '0');
            const ampm = hours >= 12 ? 'PM' : 'AM';
            
            // Convert to 12-hour format
            hours = hours % 12;
            hours = hours ? hours : 12; // Handle midnight (0 hours)
            hours = hours.toString().padStart(2, '0');
            
            clockElement.textContent = `${hours}:${minutes}:${seconds} ${ampm}`;
        }

      
function startClock() {
    // Initial call to display clock immediately
    updateClock();
    
    // Update clock every second
    setInterval(updateClock, 1000);
}

// Real-time Clock Function with Reminder Mechanism
function updateClock() {
    const clockElement = document.getElementById('clock');
    const now = new Date();
    
    let hours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    
    // Convert to 12-hour format
    const displayHours = hours % 12;
    const formattedHours = (displayHours ? displayHours : 12).toString().padStart(2, '0');
    const formattedMinutes = minutes.toString().padStart(2, '0');
    const formattedSeconds = seconds.toString().padStart(2, '0');
    
    const currentTimeString = `${formattedHours}:${formattedMinutes}:${formattedSeconds} ${ampm}`;
    clockElement.textContent = currentTimeString;

    // Check for 5-minute reminders
    if (minutes % 5 === 0 && seconds === 0) {
        const reminderMessages = [
            `🕰️ Reminder: It's ${currentTimeString}. Time to stay focused!`,
            `⏰ Quick check-in at ${currentTimeString}. How's your progress?`,
            `📅 Periodic reminder: ${currentTimeString}. Keep up the great work!`,
            `🚀 Midpoint check: ${currentTimeString}. You're doing amazing!`,
            `💡 Productivity boost: ${currentTimeString}. Stay motivated!`
        ];

        // Select a random reminder message
        const randomMessage = reminderMessages[Math.floor(Math.random() * reminderMessages.length)];
        
        // Add the reminder message
        addMessage(randomMessage, 'bot');
    }
}

        // Chat Utility Functions
        function addMessage(message, type = 'bot') {
            const chatContainer = document.getElementById('chatContainer');
            const messageElement = document.createElement('div');
            messageElement.classList.add('message', `${type}-message`);
            messageElement.textContent = message;
            chatContainer.appendChild(messageElement);
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }

        function showButtons(buttons) {
            const chatContainer = document.getElementById('chatContainer');
            const buttonGroup = document.createElement('div');
            buttonGroup.className = 'button-group';
            
            buttons.forEach(button => {
                const btn = document.createElement('button');
                btn.className = 'chat-button';
                btn.textContent = button.text;
                btn.onclick = button.action;
                buttonGroup.appendChild(btn);
            });
            
            chatContainer.appendChild(buttonGroup);
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }

        // Resource Sharing Functions
        function startResourceSharing() {
            addMessage('Resource Sharing');
            addMessage('Would you like to upload resources?');
            
            showButtons([
                { 
                    text: 'Yes', 
                    action: showResourceUploadForm 
                },
                { 
                    text: 'No', 
                    action: () => addMessage('Alright, maybe next time!') 
                }
            ]);
        }

        function showResourceUploadForm() {
            addMessage('Upload Resource');
            
            const chatContainer = document.getElementById('chatContainer');
            const uploadForm = document.createElement('form');
            uploadForm.className = 'resource-upload-form';
            uploadForm.innerHTML = `
                <input type="text" id="resourceTitle" placeholder="Resource Title" required>
                <textarea id="resourceDescription" placeholder="Description"></textarea>
                <input type="file" id="resourceFile" required>
                <button type="button" class="chat-button" onclick="uploadResource()">Upload Resource</button>
            `;
            
            addMessage('Please fill in the details:');
            chatContainer.appendChild(uploadForm);
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }

        function uploadResource() {
            const title = document.getElementById('resourceTitle').value;
            const description = document.getElementById('resourceDescription').value;
            const fileInput = document.getElementById('resourceFile');
            
            if (!title || !fileInput.files.length) {
                addMessage('Please fill in all required fields.');
                return;
            }
             // Simulate successful upload
    addMessage('Resource uploaded successfully!');
    
    // Clear form
    document.getElementById('resourceTitle').value = '';
    document.getElementById('resourceDescription').value = '';
    fileInput.value = '';
}


        // Get Resource Functions
        function startGetResource() {
            addMessage('Get Resource');
            addMessage('Please select a subject:');
            
            // Predefined subjects
            const subjects = [
                {
                    name: 'Computer Networks',
                    description: 'Resources related to computer networking concepts',
                    resources: [
                        { 
                            title: 'CN Basics Handbook', 
                            description: 'Fundamental concepts of Computer Networks' 
                        },
                        { 
                            title: 'Advanced Networking Guide', 
                            description: 'In-depth networking protocols and architectures' 
                        }
                    ]
                },
                {
                    name: 'Web Development',
                    description: 'Resources for web development technologies',
                    resources: [
                        { 
                            title: 'HTML & CSS Fundamentals', 
                            description: 'Basic web design and styling' 
                        },
                        { 
                            title: 'JavaScript Advanced Techniques', 
                            description: 'Advanced JavaScript programming' 
                        }
                    ]
                }
            ];
            
            showButtons(
                subjects.map(subject => ({
                    text: subject.name, 
                    action: () => showSubjectResources(subject)
                }))
            );
        }

        function showSubjectResources(subject) {
            addMessage(`Resources for ${subject.name}`);
            addMessage(subject.description);
            
            const chatContainer = document.getElementById('chatContainer');
            const resourceList = document.createElement('div');
            resourceList.className = 'resource-list';
            
            subject.resources.forEach(resource => {
                const resourceItem = document.createElement('div');
                resourceItem.className = 'resource-item';
                resourceItem.innerHTML = `
                    <strong>${resource.title}</strong>
                    <p>${resource.description}</p>
                    <button class="chat-button" onclick="simulateResourceDownload('${subject.name}', '${resource.title}')">
                        Download
                    </button>
                `;
                resourceList.appendChild(resourceItem);
            });
            
            chatContainer.appendChild(resourceList);
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }

        function simulateResourceDownload(subject, resourceTitle) {
            addMessage(`Downloading ${resourceTitle} from ${subject}`);
            
            // Simulate download process
            setTimeout(() => {
                addMessage(`Resource ${resourceTitle} downloaded successfully!`);
            }, 1500);
        }

        // Message Handling
        function sendMessage() {
            const userInput = document.getElementById('userInput');
            const message = userInput.value.trim();
            
            if (message) {
                // Add user message
                addMessage(message, 'user');
                userInput.value = '';
                // Send message to Langflow
                fetch(LANGFLOW_URL, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        "input_value": message,
                        "output_type": "chat",
                        "input_type": "chat",
                        "tweaks": {
                            "ChatInput-PqvUA": new Object(),
                            "Prompt-ZndDl": new Object(),
                            "ChatOutput-9Q8Jj": new Object(),
                            "GoogleGenerativeAIModel-UPDmG": new Object()
                        }
                    })
                })
                .then(response => response.json())
                .then(result => {
                    const replyMessage = result['outputs'][0]['outputs'][0]['results']['message']['text'];
                    addMessage(replyMessage);
                })
                .catch(error => {
                    console.error('Error:', error);
                    addMessage("Sorry, I couldn't process your message. Please try again.");
                });
            }
        }

        // Event Listeners
        document.getElementById('userInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });
        

        // Initial Chat Setup
        function initializeChat() {
            // Start the real-time clock
            startClock();


            addMessage('Welcome to DosthoMate! How can I assist you today?');
            
            // Add main action buttons
             showButtons([
            { text: 'Timetable Management', action: startTimetableManagement },
            { text: 'Resource Sharing', action: startResourceSharing },
            { text: 'Get Resource', action: startGetResource }
        ]);
    }

    // Initialize chat on load
    window.onload = initializeChat;
</script>
</body> </html>