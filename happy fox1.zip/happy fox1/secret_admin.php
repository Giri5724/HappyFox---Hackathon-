<?php
// Error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session if not already started
if(!session_id()){
    session_start();
}

// Check if required files exist
if (!file_exists("config/db.php")) {
    die("Error: Required file config/db.php not found");
}

require("config/db.php");

// Set default values for potentially undefined constants
if (!isset($_LOGIN_FILE)) $_LOGIN_FILE = "login.php";
if (!isset($_HOME_FILE)) $_HOME_FILE = "home.php";
if (!isset($_CHAT_FILE)) $_CHAT_FILE = "chat.php";
if (!isset($_LOGOUT_FILE)) $_LOGOUT_FILE = "logout.php";

$title = "Admin Dashboard";

// Check if head.php exists
if (!file_exists("layout/head.php")) {
    // If not, continue without it
    echo "<!DOCTYPE html><html><head><title>{$title}</title></head><body>";
    echo "<div style='color:red;'>Warning: layout/head.php not found</div>";
} else {
    require("layout/head.php");
}

// Check session function exists
if (!function_exists('checkUserSession')) {
    function checkUserSession($db) {
        return isset($_COOKIE["user_session"]);
    }
}

// Check search user function exists
if (!function_exists('searchUser_bSession')) {
    function searchUser_bSession($db, $session) {
        $query = mysqli_query($db, "SELECT * FROM user WHERE session = '" . mysqli_real_escape_string($db, $session) . "'");
        return mysqli_fetch_assoc($query);
    }
}

// Check error function exists
if (!function_exists('error')) {
    function error($message, $redirect) {
        echo "<div style='color:red;'>{$message}</div>";
        echo "<script>setTimeout(function(){ window.location.href = '{$redirect}'; }, 3000);</script>";
        exit;
    }
}

// Validate database connection
if (!isset($db) || !$db) {
    die("Error: Database connection failed");
}

// Validate user session
if(checkUserSession($db) !== True){
    header("location: $_LOGIN_FILE");
    exit;
}

// Check if user exists in database
$user = searchUser_bSession($db, $_COOKIE["user_session"] ?? '');
if (!$user) {
    error("Invalid session. Please login again.", $_LOGIN_FILE);
    exit;
}

// Check admin privilege
if(!isset($user["admin"]) || $user["admin"] != 1){
    error("You are not admin.", $_HOME_FILE);
    exit;
}

// Get statistics for dashboard - with your exact table names and structure
try {
    // Get total users
    $total_users = mysqli_fetch_array(mysqli_query($db, "SELECT COUNT(*) as count FROM user"))['count'] ?? 0;
    
    // Get total rooms - using chat_room table
    $total_rooms = mysqli_fetch_array(mysqli_query($db, "SELECT COUNT(*) as count FROM chat_room"))['count'] ?? 0;
    
    // Get total messages - using messages table
    $total_messages = mysqli_fetch_array(mysqli_query($db, "SELECT COUNT(*) as count FROM messages"))['count'] ?? 0;
    
    // Get banned users
    $banned_users = mysqli_fetch_array(mysqli_query($db, "SELECT COUNT(*) as count FROM ban_list"))['count'] ?? 0;

    // Get active users who sent messages in the last 7 days - using sent_time from messages table
    $active_users = mysqli_fetch_array(mysqli_query($db, "SELECT COUNT(DISTINCT user_id) as count FROM messages WHERE sent_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)"))['count'] ?? 0;
} catch (Exception $e) {
    echo "<div style='color:red;'>Error fetching statistics: " . $e->getMessage() . "</div>";
    $total_users = $total_rooms = $total_messages = $banned_users = $active_users = 0;
}

// Get room activity data for bar chart - using your exact table and column names
$room_names = [];
$message_counts = [];
try {
    $room_activity_query = mysqli_query($db, "SELECT r.room_name, COUNT(m.id) as message_count 
                                        FROM chat_room r 
                                        LEFT JOIN messages m ON r.room_id = m.room_id 
                                        GROUP BY r.room_id 
                                        ORDER BY message_count DESC 
                                        LIMIT 5");
    
    if ($room_activity_query) {
        while($row = mysqli_fetch_assoc($room_activity_query)) {
            $room_names[] = $row['room_name'];
            $message_counts[] = $row['message_count'];
        }
    }
} catch (Exception $e) {
    echo "<div style='color:red;'>Error fetching room activity: " . $e->getMessage() . "</div>";
}

// Get user registration data for line chart (last 6 months)
// Try to find the registration date column
$reg_months = [];
$reg_counts = [];
try {
    // Check for possible registration date columns
    $date_cols = ['registerDate', 'created_at', 'registration_date', 'created_date', 'date', 'join_date'];
    $date_col = '';
    
    foreach ($date_cols as $col) {
        $query = mysqli_query($db, "SHOW COLUMNS FROM user LIKE '{$col}'");
        if ($query && mysqli_num_rows($query) > 0) {
            $date_col = $col;
            break;
        }
    }
    
    if ($date_col) {
        $user_reg_query = mysqli_query($db, "SELECT 
                                        DATE_FORMAT({$date_col}, '%Y-%m') as month,
                                        COUNT(*) as count 
                                        FROM user 
                                        WHERE {$date_col} >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
                                        GROUP BY DATE_FORMAT({$date_col}, '%Y-%m')
                                        ORDER BY month ASC");
        
        if ($user_reg_query) {
            while($row = mysqli_fetch_assoc($user_reg_query)) {
                $reg_months[] = date("M Y", strtotime($row['month'] . "-01"));
                $reg_counts[] = $row['count'];
            }
        }
    }
    
    // If we didn't find any data, use dummy data
    if (empty($reg_months)) {
        $reg_months = ['Jan 2025', 'Feb 2025', 'Mar 2025', 'Apr 2025', 'May 2025', 'Jun 2025'];
        $reg_counts = [5, 8, 12, 10, 15, 20];
    }
} catch (Exception $e) {
    echo "<div style='color:red;'>Error fetching registration data: " . $e->getMessage() . "</div>";
    // Use dummy data if there's an error
    $reg_months = ['Jan 2025', 'Feb 2025', 'Mar 2025', 'Apr 2025', 'May 2025', 'Jun 2025'];
    $reg_counts = [5, 8, 12, 10, 15, 20];
}

$userName = $user["firstName"] . " " . $user["lastName"];
$profilePicture = $user["profilePicture"] ?? "default-avatar.png";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .notification-badge {
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        .custom-scrollbar {
            scrollbar-width: thin;
            scrollbar-color: rgba(156, 163, 175, 0.5) transparent;
        }

        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
        }

        .custom-scrollbar::-webkit-scrollbar-track {
            background: transparent;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb {
            background-color: rgba(156, 163, 175, 0.5);
            border-radius: 3px;
        }

        .room-card, .user-card {
            transition: all 0.3s ease;
        }

        .room-card:hover, .user-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        .toast-notification {
            animation: slideIn 0.3s ease forwards;
        }

        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .pagination-item {
            transition: all 0.2s ease;
        }

        .pagination-item:hover:not(.disabled) {
            background-color: #EFF6FF;
        }

        .stat-card {
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        /* Admin badge */
        .admin-badge {
            background-color: #FEF3C7;
            color: #D97706;
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-10">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="<?= $_HOME_FILE ?>" class="flex items-center">
                        <i class="fas fa-comments text-blue-600 text-2xl mr-2"></i>
                        <span class="text-xl font-bold text-gray-800">VN</span>
                    </a>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <button onclick="toggleNotifications()" class="text-gray-600 hover:text-gray-800">
                            <i class="fas fa-bell"></i>
                            <span class="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 text-xs flex items-center justify-center">2</span>
                        </button>
                    </div>
                    <div class="relative group">
                        <button class="flex items-center space-x-2">
                            <img src="<?php echo $profilePicture; ?>" 
                                 alt="Profile" 
                                 class="w-8 h-8 rounded-full" onerror="this.src='default-avatar.png'">
                            <span class="text-gray-700"><?php echo htmlspecialchars($userName); ?></span>
                            <span class="px-2 py-1 text-xs rounded-full admin-badge">Admin</span>
                        </button>
                        <div class="absolute right-0 w-48 mt-2 bg-white rounded-md shadow-lg hidden group-hover:block">
                            <a href="account.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-user mr-2"></i> Account
                            </a>
                            <a href="create_room.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-plus mr-2"></i> Create Room
                            </a>
                            <a href="my_room.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-th-large mr-2"></i> My Rooms
                            </a>
                            <a href="secret_admin.php" class="block px-4 py-2 text-gray-700 bg-gray-100">
                                <i class="fas fa-cogs mr-2"></i> Admin Area
                            </a>
                            <a href="<?= $_LOGOUT_FILE ?>" class="block px-4 py-2 text-red-600 hover:bg-gray-100">
                                <i class="fas fa-sign-out-alt mr-2"></i> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="flex min-h-screen pt-16">
        <!-- Sidebar -->
        <div class="w-64 bg-white shadow-lg fixed h-full">
            <div class="p-4">
                <div class="flex items-center mb-6">
                    <img src="<?php echo $profilePicture; ?>" alt="Profile" class="w-10 h-10 rounded-full mr-3" onerror="this.src='default-avatar.png'">
                    <div>
                        <h3 class="font-medium text-gray-800"><?php echo htmlspecialchars($userName); ?></h3>
                        <span class="text-xs px-2 py-1 rounded-full admin-badge">Administrator</span>
                    </div>
                </div>
                <h2 class="text-xl font-semibold text-gray-800 mb-4">Admin Menu</h2>
                <ul class="space-y-2">
                    <li>
                        <a href="<?= $_HOME_FILE ?>" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-home"></i>
                            <span>Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="secret_admin.php" class="flex items-center space-x-2 p-2 rounded-lg bg-blue-50 text-blue-600">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li>
                        <a href="secret_admin.php?section=users" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-users"></i>
                            <span>User Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="secret_admin.php?section=rooms" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-door-open"></i>
                            <span>Room Management</span>
                        </a>
                    </li>
                    <li>
                        <a href="secret_admin.php?section=reports" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-flag"></i>
                            <span>Reports</span>
                        </a>
                    </li>
                    <li>
                        <a href="account.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-user-cog"></i>
                            <span>Admin Settings</span>
                        </a>
                    </li>
                    <li>
                        <a href="<?= $_LOGOUT_FILE ?>" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-red-50 text-red-600">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="flex-1 ml-64 p-8">
            <!-- Page Header -->
            <div class="mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Admin Dashboard</h1>
                <div class="text-sm breadcrumbs">
                    <ul class="flex space-x-2 text-gray-500">
                        <li><a href="<?= $_HOME_FILE ?>" class="text-gray-500 hover:text-blue-600">Home</a></li>
                        <li class="text-blue-600">Admin Area</li>
                    </ul>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="bg-white rounded-lg shadow-sm p-6 stat-card border-l-4 border-blue-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-lg font-semibold text-gray-700">Total Users</h3>
                            <p class="text-3xl font-bold text-gray-800 mt-2"><?php echo $total_users; ?></p>
                        </div>
                        <div class="bg-blue-100 p-3 rounded-full">
                            <i class="fas fa-users text-blue-600 text-xl"></i>
                        </div>
                    </div>
                    <p class="text-sm text-gray-500 mt-4">Active: <?php echo $active_users; ?> (<?php echo $total_users > 0 ? round(($active_users/$total_users)*100) : 0; ?>%)</p>
                </div>

                <div class="bg-white rounded-lg shadow-sm p-6 stat-card border-l-4 border-green-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-lg font-semibold text-gray-700">Total Rooms</h3>
                            <p class="text-3xl font-bold text-gray-800 mt-2"><?php echo $total_rooms; ?></p>
                        </div>
                        <div class="bg-green-100 p-3 rounded-full">
                            <i class="fas fa-comments text-green-600 text-xl"></i>
                        </div>
                    </div>
                    <p class="text-sm text-gray-500 mt-4">Average: <?php echo $total_rooms > 0 ? round($total_messages/$total_rooms, 1) : 0; ?> messages per room</p>
                </div>

                <div class="bg-white rounded-lg shadow-sm p-6 stat-card border-l-4 border-purple-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-lg font-semibold text-gray-700">Total Messages</h3>
                            <p class="text-3xl font-bold text-gray-800 mt-2"><?php echo $total_messages; ?></p>
                        </div>
                        <div class="bg-purple-100 p-3 rounded-full">
                            <i class="fas fa-comment-dots text-purple-600 text-xl"></i>
                        </div>
                    </div>
                    <p class="text-sm text-gray-500 mt-4">Average: <?php echo $total_users > 0 ? round($total_messages/$total_users, 1) : 0; ?> messages per user</p>
                </div>

                <div class="bg-white rounded-lg shadow-sm p-6 stat-card border-l-4 border-red-500">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-lg font-semibold text-gray-700">Banned Users</h3>
                            <p class="text-3xl font-bold text-gray-800 mt-2"><?php echo $banned_users; ?></p>
                        </div>
                        <div class="bg-red-100 p-3 rounded-full">
                            <i class="fas fa-ban text-red-600 text-xl"></i>
                        </div>
                    </div>
                    <p class="text-sm text-gray-500 mt-4">Ratio: <?php echo $total_users > 0 ? round(($banned_users/$total_users)*100, 1) : 0; ?>% of all users</p>
                </div>
            </div>

            <!-- Charts -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                <div class="bg-white rounded-lg shadow-sm p-6">
                    <h2 class="text-lg font-semibold text-gray-800 mb-4">User Registrations</h2>
                    <div class="h-80">
                        <canvas id="userRegistrationChart"></canvas>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-sm p-6">
                    <h2 class="text-lg font-semibold text-gray-800 mb-4">Top Active Rooms</h2>
                    <div class="h-80">
                        <canvas id="roomActivityChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Room Management Section -->
            <div id="room_management" class="bg-white rounded-lg shadow-sm p-6 mb-8">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-lg font-semibold">Room Management</h2>
                    <a href="create_room.php" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200 text-sm flex items-center">
                        <i class="fas fa-plus mr-2"></i> Create New Room
                    </a>
                </div>
                
                <div class="space-y-4">
                    <?php
                    // Initialize pagination variables with defaults
                    $_GET['room_page'] = $_GET['room_page'] ?? 1;
                    $room_pages = ($_GET['room_page'] >= 2) ? ($_GET['room_page'] - 1) * 5 : 0;
                    
                    try {
                        // Modified query to match your table structure
                        $query = mysqli_query($db, "SELECT r.*, u.firstName, u.lastName 
                                                    FROM chat_room r 
                                                    LEFT JOIN user u ON r.owner = u.id
                                                    ORDER BY r.room_id DESC 
                                                    LIMIT 5 OFFSET {$room_pages}");
                        
                        if (!$query) {
                            throw new Exception("Error executing room query: " . mysqli_error($db));
                        }
                        
                        if(mysqli_num_rows($query) < 1): ?>
                            <div class="text-center py-8">
                                <div class="w-16 h-16 bg-blue-100 rounded-full mx-auto flex items-center justify-center mb-4">
                                    <i class="fas fa-comment-slash text-blue-600 text-2xl"></i>
                                </div>
                                <h3 class="text-gray-500 font-medium mb-2">No Rooms Created Yet</h3>
                                <p class="text-gray-400 mb-4">There are no chat rooms in the system.</p>
                                <a href="create_room.php" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200 inline-flex items-center">
                                    <i class="fas fa-plus mr-2"></i> Create Room
                                </a>
                            </div>
                        <?php else: ?>
                            <?php while($room = mysqli_fetch_array($query)): 
                                // Get member count - using room_id from your tables
                                try {
                                    $member_count = mysqli_fetch_array(mysqli_query($db, "SELECT COUNT(*) as count FROM room_member WHERE room_id = {$room['room_id']}"))['count'] ?? 0;
                                } catch (Exception $e) {
                                    $member_count = 0;
                                }
                                
                                // Get message count - using room_id and messages table
                                try {
                                    $message_count = mysqli_fetch_array(mysqli_query($db, "SELECT COUNT(*) as count FROM messages WHERE room_id = {$room['room_id']}"))['count'] ?? 0;
                                } catch (Exception $e) {
                                    $message_count = 0;
                                }
                            ?>
                                <div class="border rounded-lg room-card overflow-hidden" id="room-<?= $room["room_id"] ?>">
                                    <div class="bg-gray-50 px-4 py-3 border-b flex justify-between items-center">
                                        <div class="flex items-center">
                                            <h3 class="font-medium text-gray-800"><?= htmlspecialchars($room["room_name"] ?? 'Unnamed Room') ?></h3>
                                            <span class="ml-2 px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-full">ID: <?= $room["room_id"] ?></span>
                                        </div>
                                        <div class="flex items-center">
                                            <span class="text-xs text-gray-500 mr-2">Owner: <?= htmlspecialchars(($room["firstName"] ?? '') . " " . ($room["lastName"] ?? 'Unknown')) ?></span>
                                            <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full"><?= $member_count ?> Members</span>
                                        </div>
                                    </div>
                                    <div class="p-4">
                                        <p class="text-gray-600 mb-4">
                                            <span class="font-medium">Description:</span> 
                                            <?= !empty($room["room_description"]) ? htmlspecialchars($room["room_description"]) : "No description provided"; ?>
                                        </p>
                                        <div class="flex justify-between items-center">
                                            <div class="text-sm text-gray-500">
                                                <span><i class="fas fa-comment-dots mr-1"></i> <?= $message_count ?> messages</span>
                                            </div>
                                            <div class="flex flex-wrap gap-2">
                                                <a href="<?= $_CHAT_FILE ?>?room_id=<?= $room["room_id"] ?>" class="px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition duration-200 text-sm flex items-center">
                                                    <i class="fas fa-sign-in-alt mr-2"></i> Enter Room
                                                </a>
                                                <button onclick="delete_room(<?= $room["room_id"] ?>)" class="px-3 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition duration-200 text-sm flex items-center">
                                                    <i class="fas fa-trash-alt mr-2"></i> Delete Room
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        
                            <?php
                            // Get total room count for pagination
                            try {
                                $query1 = mysqli_query($db, "SELECT COUNT(*) as count FROM chat_room");
                                $total_room_count = mysqli_fetch_array($query1)['count'] ?? 0;
                                
                                $n = $total_room_count / 5;							
                                if($total_room_count % 5 > 0)
                                    $n+=1;
                                $n = (int) $n;
                            } catch (Exception $e) {
                                echo "<div style='color:red;'>Error getting room count: " . $e->getMessage() . "</div>";
                                $n = 1;
                            }
                            ?>
                            
                            <!-- Pagination -->
                            <div class="flex justify-center mt-6">
                                <nav class="flex" aria-label="Pagination">
                                    <a href="secret_admin.php?room_page=1#room_management" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['room_page'] == 1) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                        <span class="sr-only">First</span>
                                        <i class="fas fa-angle-double-left"></i>
                                    </a>
                                    <a href="secret_admin.php?room_page=<?php echo ($_GET['room_page']-1 > 0) ? $_GET['room_page']-1 : 1; ?>#room_management" class="relative inline-flex items-center px-2 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['room_page'] == 1) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                        <span class="sr-only">Previous</span>
                                        <i class="fas fa-angle-left"></i>
                                    </a>
                                    
                                    <?php for($i = 1; $i <= $n; $i++): ?>
                                    <a href="secret_admin.php?room_page=<?php echo $i ?>#room_management" class="relative inline-flex items-center px-4 py-2 border border-gray-300 <?php echo ($_GET['room_page'] == $i) ? 'bg-blue-50 text-blue-600 border-blue-300' : 'bg-white text-gray-500'; ?> text-sm font-medium hover:bg-gray-50">
                                        <?php echo $i ?>
                                    </a>
                                    <?php endfor; ?>
                                    
                                    <a href="secret_admin.php?room_page=<?php echo ($_GET['room_page']+1 <= $n) ? $_GET['room_page']+1 : $_GET['room_page']; ?>#room_management" class="relative inline-flex items-center px-2 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['room_page'] >= $n) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                        <span class="sr-only">Next</span>
                                        <i class="fas fa-angle-right"></i>
                                    </a>
                                    <a href="secret_admin.php?room_page=<?php echo $n ?>#room_management" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['room_page'] >= $n) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                        <span class="sr-only">Last</span>
                                        <i class="fas fa-angle-double-right"></i>
                                    </a>
                                </nav>
                            </div>
                        <?php endif;
                    } catch (Exception $e) {
                        echo "<div class='p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg' role='alert'>
                            <div class='font-medium'>Error loading rooms:</div>
                            <div>" . htmlspecialchars($e->getMessage()) . "</div>
                        </div>";
                    }
                    ?>
                </div>
            </div>

            <!-- User Management Section -->
            <div id="user_management" class="bg-white rounded-lg shadow-sm p-6">
                <h2 class="text-lg font-semibold mb-6">User Management</h2>
                
                <div class="space-y-4">
                    <?php
                    // Initialize pagination variables with defaults
                    $_GET['user_page'] = $_GET['user_page'] ?? 1;
                    $user_pages = ($_GET['user_page'] >= 2) ? ($_GET['user_page'] - 1) * 5 : 0;
                    
                    try {
                        $query = mysqli_query($db, "SELECT * FROM user ORDER BY id DESC LIMIT 5 OFFSET {$user_pages}");
                        
                        if (!$query) {
                            throw new Exception("Error executing user query: " . mysqli_error($db));
                        }
                        
                        if(mysqli_num_rows($query) < 1): ?>
                            <div class="text-center py-8">
                                <div class="w-16 h-16 bg-purple-100 rounded-full mx-auto flex items-center justify-center mb-4">
                                    <i class="fas fa-user-slash text-purple-600 text-2xl"></i>
                                </div>
                                <h3 class="text-gray-500 font-medium mb-2">No Users Found</h3>
                                <p class="text-gray-400">There are no users in the system.</p>
                            </div>
                        <?php else: ?>
                            <?php while($_user = mysqli_fetch_array($query)):
                            try {
                                $ban_check = mysqli_query($db, "SELECT * FROM ban_list WHERE user_id = {$_user["id"]}");
                                $is_banned = $ban_check && mysqli_num_rows($ban_check) > 0;

                                // Get room count - using the correct owner column in chat_room
                                $owned_rooms = mysqli_fetch_array(mysqli_query($db, "SELECT COUNT(*) as count FROM chat_room WHERE owner = {$_user['id']}"))['count'] ?? 0;
                                
                                // Get message count - using user_id from messages table
                                $message_count = mysqli_fetch_array(mysqli_query($db, "SELECT COUNT(*) as count FROM messages WHERE user_id = {$_user['id']}"))['count'] ?? 0;
                            } catch (Exception $e) {
                                // Set defaults if queries fail
                                $is_banned = false;
                                $owned_rooms = 0;
                                $message_count = 0;
                            }
                            ?>
                                <div class="border rounded-lg user-card overflow-hidden" id="user-id-<?= $_user["id"] ?>">
                                    <div class="bg-gray-50 px-4 py-3 border-b flex justify-between items-center">
                                        <div class="flex items-center">
                                            <img src="<?= $_user["profilePicture"] ?? 'default-avatar.png' ?>" class="w-8 h-8 rounded-full mr-3" onerror="this.src='default-avatar.png'">
                                            <div>
                                                <h3 class="font-medium text-gray-800"><?= htmlspecialchars(($_user["firstName"] ?? '') . " " . ($_user["lastName"] ?? '')) ?></h3>
                                                <p class="text-xs text-gray-500">@<?= htmlspecialchars($_user["username"] ?? 'unknown') ?></p>
                                            </div>
                                        </div>
                                        <div class="flex items-center space-x-2">
                                            <?php if(isset($_user["admin"]) && $_user["admin"] == 1): ?>
                                            <span class="px-2 py-1 text-xs rounded-full admin-badge">Admin</span>
                                            <?php endif; ?>
                                            <?php if($is_banned): ?>
                                            <span class="px-2 py-1 text-xs bg-red-100 text-red-800 rounded-full">Banned</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="p-4">
                                        <div class="grid grid-cols-2 gap-4 mb-4">
                                            <div>
                                                <p class="text-sm text-gray-500">Email</p>
                                                <p class="font-medium"><?= htmlspecialchars($_user["email"] ?? 'No email') ?></p>
                                            </div>
                                            <div>
                                                <p class="text-sm text-gray-500">Registered</p>
                                                <p class="font-medium"><?= isset($_user["created_at"]) ? date("M d, Y", strtotime($_user["created_at"])) : 'Unknown' ?></p>
                                            </div>
                                            <div>
                                                <p class="text-sm text-gray-500">Rooms Owned</p>
                                                <p class="font-medium"><?= $owned_rooms ?></p>
                                            </div>
                                            <div>
                                                <p class="text-sm text-gray-500">Messages Sent</p>
                                                <p class="font-medium"><?= $message_count ?></p>
                                            </div>
                                        </div>
                                        <div class="flex justify-end space-x-2">
                                            <?php if(!$is_banned): ?>
                                            <button onclick="ban_user(<?= $_user['id'] ?>)" class="px-3 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition duration-200 text-sm flex items-center">
                                                <i class="fas fa-ban mr-2"></i> Ban User
                                            </button>
                                            <?php else: ?>
                                            <button onclick="unban_user(<?= $_user['id'] ?>)" class="px-3 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition duration-200 text-sm flex items-center">
                                                <i class="fas fa-user-check mr-2"></i> Unban User
                                            </button>
                                            <?php endif; ?>
                                            
                                            <?php if(!isset($_user["admin"]) || $_user["admin"] != 1): ?>
                                            <button onclick="make_admin(<?= $_user['id'] ?>)" class="px-3 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition duration-200 text-sm flex items-center">
                                                <i class="fas fa-user-shield mr-2"></i> Make Admin
                                            </button>
                                            <?php else: ?>
                                            <button onclick="remove_admin(<?= $_user['id'] ?>)" class="px-3 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 transition duration-200 text-sm flex items-center">
                                                <i class="fas fa-user-minus mr-2"></i> Remove Admin
                                            </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        
                            <?php
                            // Get total user count for pagination
                            try {
                                $query1 = mysqli_query($db, "SELECT COUNT(*) as count FROM user");
                                $total_user_count = mysqli_fetch_array($query1)['count'] ?? 0;
                                
                                $n = $total_user_count / 5;							
                                if($total_user_count % 5 > 0)
                                    $n+=1;
                                $n = (int) $n;
                            } catch (Exception $e) {
                                echo "<div style='color:red;'>Error getting user count: " . $e->getMessage() . "</div>";
                                $n = 1;
                            }
                            ?>
                            
                            <!-- Pagination -->
                            <div class="flex justify-center mt-6">
                                <nav class="flex" aria-label="Pagination">
                                    <a href="secret_admin.php?user_page=1#user_management" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['user_page'] == 1) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                        <span class="sr-only">First</span>
                                        <i class="fas fa-angle-double-left"></i>
                                    </a>
                                    <a href="secret_admin.php?user_page=<?php echo ($_GET['user_page']-1 > 0) ? $_GET['user_page']-1 : 1; ?>#user_management" class="relative inline-flex items-center px-2 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['user_page'] == 1) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                        <span class="sr-only">Previous</span>
                                        <i class="fas fa-angle-left"></i>
                                    </a>
                                    
                                    <?php for($i = 1; $i <= $n; $i++): ?>
                                    <a href="secret_admin.php?user_page=<?php echo $i ?>#user_management" class="relative inline-flex items-center px-4 py-2 border border-gray-300 <?php echo ($_GET['user_page'] == $i) ? 'bg-blue-50 text-blue-600 border-blue-300' : 'bg-white text-gray-500'; ?> text-sm font-medium hover:bg-gray-50">
                                        <?php echo $i ?>
                                    </a>
                                    <?php endfor; ?>
                                    
                                    <a href="secret_admin.php?user_page=<?php echo ($_GET['user_page']+1 <= $n) ? $_GET['user_page']+1 : $_GET['user_page']; ?>#user_management" class="relative inline-flex items-center px-2 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['user_page'] >= $n) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                        <span class="sr-only">Next</span>
                                        <i class="fas fa-angle-right"></i>
                                    </a>
                                    <a href="secret_admin.php?user_page=<?php echo $n ?>#user_management" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 <?php echo ($_GET['user_page'] >= $n) ? 'opacity-50 cursor-not-allowed' : ''; ?>">
                                        <span class="sr-only">Last</span>
                                        <i class="fas fa-angle-double-right"></i>
                                    </a>
                                </nav>
                            </div>
                        <?php endif;
                    } catch (Exception $e) {
                        echo "<div class='p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg' role='alert'>
                            <div class='font-medium'>Error loading users:</div>
                            <div>" . htmlspecialchars($e->getMessage()) . "</div>
                        </div>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Notification Panel (Initially Hidden) -->
    <div id="notificationPanel" class="fixed right-0 top-16 w-80 bg-white shadow-lg rounded-lg p-4 transform translate-x-full transition-transform duration-300 z-20">
        <div class="flex justify-between items-center mb-4">
            <h3 class="font-medium text-gray-800">Notifications</h3>
            <button onclick="toggleNotifications()" class="text-gray-500 hover:text-gray-700">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="max-h-96 overflow-y-auto custom-scrollbar">
            <div class="space-y-3">
                <div class="bg-blue-50 p-3 rounded-lg">
                    <div class="flex items-start">
                        <div class="bg-blue-100 p-2 rounded-full mr-3">
                            <i class="fas fa-comment-dots text-blue-600"></i>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-800">New Report</p>
                            <p class="text-xs text-gray-600">A message has been reported in Room #12</p>
                            <p class="text-xs text-gray-500 mt-1">Just now</p>
                        </div>
                    </div>
                </div>
                <div class="p-3 rounded-lg border">
                    <div class="flex items-start">
                        <div class="bg-green-100 p-2 rounded-full mr-3">
                            <i class="fas fa-user-plus text-green-600"></i>
                        </div>
                        <div>
                            <p class="text-sm font-medium text-gray-800">New User</p>
                            <p class="text-xs text-gray-600">John Smith has registered</p>
                            <p class="text-xs text-gray-500 mt-1">3 hours ago</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mt-4 text-center">
            <a href="#" class="text-sm text-blue-600 hover:text-blue-800">View all notifications</a>
        </div>
    </div>

    <!-- Toast Notification for actions -->
    <div id="toast" class="fixed bottom-4 right-4 bg-white rounded-lg shadow-lg p-4 mb-4 hidden toast-notification max-w-xs z-50">
        <div class="flex items-center">
            <div id="toastIcon" class="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center mr-4">
                <i id="toastIconClass" class="fas fa-check text-white"></i>
            </div>
            <div>
                <p id="toastTitle" class="font-medium text-gray-800"></p>
                <p id="toastMessage" class="text-sm text-gray-600"></p>
            </div>
        </div>
    </div>

    <!-- JavaScript -->
    <script>
        // Initialize Charts
        document.addEventListener('DOMContentLoaded', function() {
            try {
                // User Registration Chart
                const regCtx = document.getElementById('userRegistrationChart').getContext('2d');
                const userRegistrationChart = new Chart(regCtx, {
                    type: 'line',
                    data: {
                        labels: <?php echo json_encode($reg_months); ?>,
                        datasets: [{
                            label: 'New Users',
                            data: <?php echo json_encode($reg_counts); ?>,
                            backgroundColor: 'rgba(59, 130, 246, 0.2)',
                            borderColor: 'rgba(59, 130, 246, 1)',
                            borderWidth: 2,
                            pointBackgroundColor: 'rgba(59, 130, 246, 1)',
                            pointRadius: 4,
                            tension: 0.3
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: {
                                    drawBorder: false
                                },
                                ticks: {
                                    precision: 0
                                }
                            },
                            x: {
                                grid: {
                                    display: false
                                }
                            }
                        },
                        plugins: {
                            legend: {
                                display: false
                            }
                        }
                    }
                });

                // Room Activity Chart
                const roomCtx = document.getElementById('roomActivityChart').getContext('2d');
                const roomActivityChart = new Chart(roomCtx, {
                    type: 'bar',
                    data: {
                        labels: <?php echo json_encode($room_names); ?>,
                        datasets: [{
                            label: 'Messages',
                            data: <?php echo json_encode($message_counts); ?>,
                            backgroundColor: [
                                'rgba(59, 130, 246, 0.8)',
                                'rgba(16, 185, 129, 0.8)',
                                'rgba(139, 92, 246, 0.8)',
                                'rgba(239, 68, 68, 0.8)',
                                'rgba(245, 158, 11, 0.8)'
                            ],
                            borderRadius: 6
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: {
                                    drawBorder: false
                                },
                                ticks: {
                                    precision: 0
                                }
                            },
                            x: {
                                grid: {
                                    display: false
                                }
                            }
                        },
                        plugins: {
                            legend: {
                                display: false
                            }
                        }
                    }
                });
            } catch (e) {
                console.error("Error initializing charts:", e);
                // Add visible error message if charts fail to render
                document.querySelectorAll('.h-80').forEach(container => {
                    container.innerHTML = `<div class="flex items-center justify-center h-full">
                        <div class="text-red-500">
                            <i class="fas fa-exclamation-triangle text-3xl"></i>
                            <p class="mt-2">Error loading chart data</p>
                        </div>
                    </div>`;
                });
            }
        });

        // Notification Panel Toggle
        function toggleNotifications() {
            const panel = document.getElementById('notificationPanel');
            panel.classList.toggle('translate-x-full');
        }

        // Toast Notification
        function showToast(title, message, type = 'success') {
            const toast = document.getElementById('toast');
            const toastTitle = document.getElementById('toastTitle');
            const toastMessage = document.getElementById('toastMessage');
            const toastIcon = document.getElementById('toastIcon');
            const toastIconClass = document.getElementById('toastIconClass');
            
            toastTitle.textContent = title;
            toastMessage.textContent = message;
            
            // Set type styling
            if (type === 'success') {
                toastIcon.className = 'flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center mr-4 bg-green-500';
                toastIconClass.className = 'fas fa-check text-white';
            } else if (type === 'error') {
                toastIcon.className = 'flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center mr-4 bg-red-500';
                toastIconClass.className = 'fas fa-times text-white';
            } else if (type === 'warning') {
                toastIcon.className = 'flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center mr-4 bg-yellow-500';
                toastIconClass.className = 'fas fa-exclamation text-white';
            }
            
            // Show toast
            toast.classList.remove('hidden');
            
            // Hide after 3 seconds
            setTimeout(() => {
                toast.classList.add('hidden');
            }, 3000);
        }

        // Room Management Functions
        function delete_room(room_id) {
            if (confirm('Are you sure you want to delete this room? This action cannot be undone.')) {
                try {
                    // AJAX request to delete room
                    fetch('api/delete_room.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ room_id: room_id })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Remove room from DOM
                            const roomElement = document.getElementById('room-' + room_id);
                            if (roomElement) roomElement.remove();
                            showToast('Room Deleted', 'The room has been successfully deleted.', 'success');
                        } else {
                            showToast('Error', data.message || 'Failed to delete room', 'error');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        showToast('Error', 'Something went wrong. Please try again.', 'error');
                    });
                } catch (error) {
                    console.error('Error:', error);
                    showToast('Error', 'Something went wrong. Please try again.', 'error');
                }
            }
        }

        // User Management Functions
        function ban_user(user_id) {
            if (confirm('Are you sure you want to ban this user?')) {
                try {
                    // AJAX request to ban user
                    fetch('api/ban_user.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ user_id: user_id })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            showToast('User Banned', 'The user has been successfully banned.', 'success');
                            // Reload the page to reflect changes
                            setTimeout(() => location.reload(), 1000);
                        } else {
                            showToast('Error', data.message || 'Failed to ban user', 'error');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        showToast('Error', 'Something went wrong. Please try again.', 'error');
                    });
                } catch (error) {
                    console.error('Error:', error);
                    showToast('Error', 'Something went wrong. Please try again.', 'error');
                }
            }
        }

        function unban_user(user_id) {
            if (confirm('Are you sure you want to unban this user?')) {
                try {
                    // AJAX request to unban user
                    fetch('api/unban_user.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ user_id: user_id })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            showToast('User Unbanned', 'The user has been successfully unbanned.', 'success');
                            // Reload the page to reflect changes
                            setTimeout(() => location.reload(), 1000);
                        } else {
                            showToast('Error', data.message || 'Failed to unban user', 'error');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        showToast('Error', 'Something went wrong. Please try again.', 'error');
                    });
                } catch (error) {
                    console.error('Error:', error);
                    showToast('Error', 'Something went wrong. Please try again.', 'error');
                }
            }
        }

        function make_admin(user_id) {
            if (confirm('Are you sure you want to give admin privileges to this user?')) {
                try {
                    // AJAX request to make user admin
                    fetch('api/make_admin.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ user_id: user_id })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            showToast('Admin Added', 'The user is now an administrator.', 'success');
                            // Reload the page to reflect changes
                            setTimeout(() => location.reload(), 1000);
                        } else {
                            showToast('Error', data.message || 'Failed to make user admin', 'error');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        showToast('Error', 'Something went wrong. Please try again.', 'error');
                    });
                } catch (error) {
                    console.error('Error:', error);
                    showToast('Error', 'Something went wrong. Please try again.', 'error');
                }
            }
        }

        function remove_admin(user_id) {
            if (confirm('Are you sure you want to remove admin privileges from this user?')) {
                try {
                    // AJAX request to remove admin status
                    fetch('api/remove_admin.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ user_id: user_id })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            showToast('Admin Removed', 'The user is no longer an administrator.', 'success');
                            // Reload the page to reflect changes
                            setTimeout(() => location.reload(), 1000);
                        } else {
                            showToast('Error', data.message || 'Failed to remove admin status', 'error');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        showToast('Error', 'Something went wrong. Please try again.', 'error');
                    });
                } catch (error) {
                    console.error('Error:', error);
                    showToast('Error', 'Something went wrong. Please try again.', 'error');
                }
            }
        }
    </script>
</body>
</html>