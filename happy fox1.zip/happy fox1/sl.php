<?php
session_start();

// Allow CLI execution (Command Line Interface)
if (php_sapi_name() !== 'cli') {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(403); // Forbidden
        exit("Unauthorized access! Please log in.");
    }
}

// WebSocke 172.16.59.46
$host = "192.168.62.149"; // Listen on all interfaces
$port = 9090; // WebSocket Port

$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
socket_set_option($socket, SOL_SOCKET, SO_REUSEADDR, 1);
socket_bind($socket, $host, $port);
socket_listen($socket);

$clients = []; // Store connected clients

echo "✅ WebSocket Server started on ws://$host:$port\n";

// Function to send messages to all clients
function sendMessage($message, $exclude = null) {
    global $clients;
    foreach ($clients as $client) {
        if ($client !== $exclude) {
            @socket_write($client, $message, strlen($message));
        }
    }
}

// Main WebSocket Loop
while (true) {
    $read = $clients;
    $read[] = $socket;
    $write = null;
    $except = null;

    socket_select($read, $write, $except, 0);

    // Handle new client connections
    if (in_array($socket, $read)) {
        $newClient = socket_accept($socket);
        $clients[] = $newClient;

        // Perform WebSocket handshake
        $request = socket_read($newClient, 5000);
        if (preg_match("/Sec-WebSocket-Key: (.*)\r\n/", $request, $matches)) {
            $key = trim($matches[1]);
            $acceptKey = base64_encode(pack('H*', sha1($key . '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')));
            $upgradeResponse = "HTTP/1.1 101 Switching Protocols\r\n" .
                "Upgrade: websocket\r\n" .
                "Connection: Upgrade\r\n" .
                "Sec-WebSocket-Accept: $acceptKey\r\n\r\n";
            socket_write($newClient, $upgradeResponse, strlen($upgradeResponse));
        }

        echo "🔗 New client connected.\n";
    }

    // Read messages from clients
    foreach ($clients as $client) {
        $data = @socket_read($client, 1024);
        if ($data === false) {
            // Client disconnected
            unset($clients[array_search($client, $clients)]);
            socket_close($client);
            echo "❌ Client disconnected.\n";
            continue;
        }

        // Decode WebSocket Frame
        $message = trim($data);
        if (!empty($message)) {
            echo "📩 Received: $message\n";
            sendMessage($message, $client); // Broadcast to all clients
        }
    }
}

// Close the socket on exit
socket_close($socket);
?>
