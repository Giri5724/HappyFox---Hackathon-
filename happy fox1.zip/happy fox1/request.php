<?php 
if(!session_id()){
	session_start();
}
require("config/db.php");
$title = "Request Management";
require("layout/head.php"); // $title = "page title"

if(checkUserSession($db) !== TRUE){
	header("location: $_LOGIN_FILE");exit; //$_LOGIN_FILE --> /config/value.php
}

if(!empty($_GET["room_id"])){
	$room_id = $_GET["room_id"];
	
	$query = mysqli_query($db, "select * from chat_room where room_id=$room_id") or error("Room id doesn't exist", $_HOME_FILE); //$_HOME_FILE --> /config/value.php
	if(mysqli_num_rows($query) > 0){
		$room_data = mysqli_fetch_array($query) or error("Can't get room data");
	} else {
		error("Room id doesn't exist", $_HOME_FILE); //$_HOME_FILE --> /config/value.php
	}
}

$user = searchUser_bSession($db, $_COOKIE["user_session"]);
if($room_data["owner"] !== $user["id"]){
	error("You isn't owner this room", $_HOME_FILE);
}

$userName = $user["firstName"] . " " . $user["lastName"];
$profilePicture = $user["profilePicture"] ?? "default-avatar.png";
$inLogin = true;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?> - <?= htmlspecialchars($room_data["room_name"]) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<style>
    .notification-badge {
        animation: pulse 2s infinite;
    }

    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.1); }
        100% { transform: scale(1); }
    }

    .custom-scrollbar {
        scrollbar-width: thin;
        scrollbar-color: rgba(156, 163, 175, 0.5) transparent;
    }

    .custom-scrollbar::-webkit-scrollbar {
        width: 6px;
    }

    .custom-scrollbar::-webkit-scrollbar-track {
        background: transparent;
    }

    .custom-scrollbar::-webkit-scrollbar-thumb {
        background-color: rgba(156, 163, 175, 0.5);
        border-radius: 3px;
    }

    /* Request card hover effects */
    .request-card {
        transition: all 0.3s ease;
    }

    .request-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    }

    /* Toast notifications */
    .toast-notification {
        animation: slideIn 0.3s ease forwards;
    }

    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    /* Button hover animations */
    .btn-accept {
        transition: all 0.2s ease;
    }

    .btn-accept:hover {
        background-color: rgb(5, 150, 105);
    }

    .btn-reject {
        transition: all 0.2s ease;
    }

    .btn-reject:hover {
        background-color: rgb(220, 38, 38);
    }
</style>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-10">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="home.php" class="flex items-center">
                        <i class="fas fa-comments text-blue-600 text-2xl mr-2"></i>
                        <span class="text-xl font-bold text-gray-800">VN</span>
                    </a>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="relative">
                        <button onclick="toggleNotifications()" class="text-gray-600 hover:text-gray-800">
                            <i class="fas fa-bell"></i>
                            <span class="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 text-xs flex items-center justify-center">2</span>
                        </button>
                    </div>
                    <div class="relative group">
                        <button class="flex items-center space-x-2">
                            <img src="<?php echo $profilePicture; ?>" 
                                 alt="Profile" 
                                 class="w-8 h-8 rounded-full">
                            <span class="text-gray-700"><?php echo htmlspecialchars($userName); ?></span>
                        </button>
                        <div class="absolute right-0 w-48 mt-2 bg-white rounded-md shadow-lg hidden group-hover:block">
                            <a href="account.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-user mr-2"></i> Account
                            </a>
                            <a href="create_room.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-plus mr-2"></i> Create Room
                            </a>
                            <a href="my_room.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-th-large mr-2"></i> My Rooms
                            </a>
                            <?php if(isset($isAdmin) && $isAdmin): ?>
                            <a href="secret_admin.php" class="block px-4 py-2 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-cogs mr-2"></i> Admin Area
                            </a>
                            <?php endif; ?>
                            <a href="<?= $_LOGOUT_FILE ?? 'logout.php' ?>" class="block px-4 py-2 text-red-600 hover:bg-gray-100">
                                <i class="fas fa-sign-out-alt mr-2"></i> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="flex min-h-screen pt-16">
        <!-- Sidebar -->
        <div class="w-64 bg-white shadow-lg fixed h-full">
            <div class="p-4">
                <div class="flex items-center mb-6">
                    <img src="<?php echo $profilePicture; ?>" alt="Profile" class="w-10 h-10 rounded-full mr-3">
                    <div>
                        <h3 class="font-medium text-gray-800"><?php echo htmlspecialchars($userName); ?></h3>
                        <span class="text-xs text-gray-500">Room Owner</span>
                    </div>
                </div>
                <h2 class="text-xl font-semibold text-gray-800 mb-4">Menu</h2>
                <ul class="space-y-2">
                    <li>
                        <a href="<?= $_HOME_FILE ?? 'home.php' ?>" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-home"></i>
                            <span>Home</span>
                        </a>
                    </li>
                    <li>
                        <a href="account.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-user"></i>
                            <span>Account</span>
                        </a>
                    </li>
                    <li>
                        <a href="create_room.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-plus"></i>
                            <span>Create Room</span>
                        </a>
                    </li>
                    <li>
                        <a href="my_room.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-th-large"></i>
                            <span>My Room</span>
                        </a>
                    </li>
                    <?php if(isset($isAdmin) && $isAdmin): ?>
                    <li>
                        <a href="secret_admin.php" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50">
                            <i class="fas fa-cogs"></i>
                            <span>Admin Area</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <li>
                        <a href="<?= $_LOGOUT_FILE ?? 'logout.php' ?>" class="flex items-center space-x-2 p-2 rounded-lg hover:bg-red-50 text-red-600">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Main Content Area -->
        <div class="flex-1 ml-64 p-8">
            <!-- Page Header -->
            <div class="mb-6">
                <h1 class="text-2xl font-bold text-gray-800"><?= $title ?></h1>
                <div class="text-sm breadcrumbs">
                    <ul class="flex space-x-2 text-gray-500">
                        <li><a href="chat.php?room_id=<?= $room_data["room_id"] ?>" class="text-gray-500 hover:text-blue-600"><?= htmlspecialchars($room_data["room_name"]) ?></a></li>
                        <li class="text-blue-600"><?= $title ?></li>
                    </ul>
                </div>
            </div>

            <!-- Room Info -->
            <div class="bg-white rounded-lg shadow-sm p-6 mb-6">
                <div class="flex justify-between items-center">
                    <div>
                        <h2 class="text-lg font-semibold text-gray-800"><?= htmlspecialchars($room_data["room_name"]) ?></h2>
                        <p class="text-gray-500 mt-1">Room ID: <?= $room_id ?></p>
                    </div>
                    <div class="flex space-x-2">
                        <a href="chat.php?room_id=<?= $room_id ?>" class="px-3 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition duration-200 text-sm flex items-center">
                            <i class="fas fa-comments mr-2"></i> Return to Chat
                        </a>
                        <a href="member.php?room_id=<?= $room_id ?>" class="px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition duration-200 text-sm flex items-center">
                            <i class="fas fa-users mr-2"></i> Members
                        </a>
                        <a href="room_options.php?room_id=<?= $room_id ?>" class="px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition duration-200 text-sm flex items-center">
                            <i class="fas fa-cog mr-2"></i> Settings
                        </a>
                    </div>
                </div>
            </div>

            <!-- Join Requests Section -->
            <div class="bg-white rounded-lg shadow-sm p-6">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-lg font-semibold text-gray-800">Pending Join Requests</h2>
                    <div class="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full flex items-center">
                        <i class="fas fa-exclamation-circle mr-1"></i> Requires Action
                    </div>
                </div>
                
                <div class="space-y-4">
                    <?php
                    $query = mysqli_query($db, "select * from request_join where room_id={$room_data["room_id"]}") or error("Can't get request join", $_HOME_FILE);
                    
                    if(mysqli_num_rows($query) < 1): ?>
                        <div class="text-center py-8">
                            <div class="w-16 h-16 bg-blue-100 rounded-full mx-auto flex items-center justify-center mb-4">
                                <i class="fas fa-check-circle text-blue-600 text-2xl"></i>
                            </div>
                            <h3 class="text-gray-500 font-medium mb-2">No Pending Requests</h3>
                            <p class="text-gray-400">There are no pending join requests for this room at the moment.</p>
                        </div>
                    <?php else: ?>
                        <?php while($req = mysqli_fetch_array($query)):
                        $_user = searchUser_bId($db, $req["user_id"]);
                        if(!empty($_user)): ?>
                            <div class="border rounded-lg p-4 request-card" id="request-user-<?= $req["user_id"] ?>">
                                <div class="flex justify-between items-start">
                                    <div class="flex">
                                        <img src="<?= $_user["profilePicture"] ?? 'default-avatar.png' ?>" 
                                             alt="Profile" 
                                             class="w-12 h-12 rounded-full mr-4">
                                        <div>
                                            <h3 class="font-medium text-gray-800"><?= htmlspecialchars($_user["firstName"] . " " . $_user["lastName"]); ?></h3>
                                            <p class="text-sm text-gray-500">Requested to join <?= format_time_ago(strtotime($req["time"])) ?></p>
                                        </div>
                                    </div>
                                    <span class="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">Pending</span>
                                </div>
                                <div class="mt-4 flex space-x-3">
                                    <button onclick="approve_request(<?= $req["user_id"] ?>, <?= $req["room_id"] ?>)" 
                                            class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition duration-200 flex items-center btn-accept">
                                        <i class="fas fa-check mr-2"></i> Accept
                                    </button>
                                    <button onclick="reject_request(<?= $req["user_id"] ?>, <?= $req["room_id"] ?>)" 
                                            class="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition duration-200 flex items-center btn-reject">
                                        <i class="fas fa-times mr-2"></i> Reject
                                    </button>
                                </div>
                            </div>
                        <?php endif; endwhile; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Notification Modal -->
    <div id="notificationModal" class="fixed right-0 mt-16 mr-4 w-80 bg-white rounded-lg shadow-xl hidden z-50">
        <div class="p-4 border-b">
            <h3 class="text-lg font-semibold">Notifications</h3>
        </div>
        <div class="max-h-96 overflow-y-auto">
            <div class="p-4 border-b hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                            <i class="fas fa-user-plus text-blue-600"></i>
                        </div>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium">New join request</p>
                        <p class="text-sm text-gray-500">Sarah requested to join your Math Help room</p>
                        <p class="text-xs text-gray-400 mt-1">5 minutes ago</p>
                    </div>
                </div>
            </div>
            <div class="p-4 border-b hover:bg-gray-50">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                            <i class="fas fa-comment text-green-600"></i>
                        </div>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm font-medium">New message</p>
                        <p class="text-sm text-gray-500">John posted in your Study Group room</p>
                        <p class="text-xs text-gray-400 mt-1">2 hours ago</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="p-4 border-t">
            <a href="notifications.php" class="text-sm text-blue-600 hover:text-blue-800">View all notifications</a>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery-3.1.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="assets/js/plugins/toastr/toastr.min.js"></script>
    <script src="assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="assets/js/inspinia.js"></script>
    <script src="assets/js/plugins/pace/pace.min.js"></script>

    <script>
    function toggleNotifications() {
        const modal = document.getElementById('notificationModal');
        modal.classList.toggle('hidden');
    }

    // Close notification modal when clicking outside
    window.onclick = function(event) {
        const notificationModal = document.getElementById('notificationModal');
        
        if (!event.target.closest('#notificationModal') && 
            !event.target.closest('button[onclick="toggleNotifications()"]')) {
            notificationModal.classList.add('hidden');
        }
    }

    function approve_request(user_id, room_id){
        const button = event.currentTarget;
        const originalText = button.innerHTML;
        
        $.ajax({
            url: "ajax/request/request_action.php?do=approve",
            type: "POST",
            data: {
                user_id: user_id,
                room_id: room_id
            },
            dataType: 'json',
            beforeSend: function () {
                button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Processing...';
                button.disabled = true;
            },
            success: function(r) {
                if(r.success){
                    $("#request-user-" + user_id).fadeOut(300, function() {
                        $(this).remove();
                        
                        // Check if there are any remaining requests
                        if ($('.request-card').length === 0) {
                            // Show the "no requests" message
                            $('.space-y-4').html(`
                                <div class="text-center py-8">
                                    <div class="w-16 h-16 bg-blue-100 rounded-full mx-auto flex items-center justify-center mb-4">
                                        <i class="fas fa-check-circle text-blue-600 text-2xl"></i>
                                    </div>
                                    <h3 class="text-gray-500 font-medium mb-2">No Pending Requests</h3>
                                    <p class="text-gray-400">There are no pending join requests for this room at the moment.</p>
                                </div>
                            `);
                        }
                    });
                    toastr.success(r.message);
                } else {
                    button.innerHTML = originalText;
                    button.disabled = false;
                    toastr.error(r.message);
                }
            },
            error: function(){
                button.innerHTML = originalText;
                button.disabled = false;
                toastr.error("Unknown error occurred!");
            }
        });
    }

    function reject_request(user_id, room_id){
        const button = event.currentTarget;
        const originalText = button.innerHTML;
        
        $.ajax({
            url: "ajax/request/request_action.php?do=reject",
            type: "POST",
            data: {
                user_id: user_id,
                room_id: room_id
            },
            dataType: 'json',
            beforeSend: function () {
                button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Processing...';
                button.disabled = true;
            },
            success: function(r) {
                if(r.success){
                    $("#request-user-" + user_id).fadeOut(300, function() {
                        $(this).remove();
                        
                        // Check if there are any remaining requests
                        if ($('.request-card').length === 0) {
                            // Show the "no requests" message
                            $('.space-y-4').html(`
                                <div class="text-center py-8">
                                    <div class="w-16 h-16 bg-blue-100 rounded-full mx-auto flex items-center justify-center mb-4">
                                        <i class="fas fa-check-circle text-blue-600 text-2xl"></i>
                                    </div>
                                    <h3 class="text-gray-500 font-medium mb-2">No Pending Requests</h3>
                                    <p class="text-gray-400">There are no pending join requests for this room at the moment.</p>
                                </div>
                            `);
                        }
                    });
                    toastr.success(r.message);
                } else {
                    button.innerHTML = originalText;
                    button.disabled = false;
                    toastr.error(r.message);
                }
            },
            error: function(){
                button.innerHTML = originalText;
                button.disabled = false;
                toastr.error("Unknown error occurred!");
            }
        });
    }
    </script>
</body>
</html>