<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session
if (!session_id()) {
    session_start();
}

// Database connection
require("config/db.php");

// Check user authentication
if (!isset($_COOKIE["user_session"])) {
    header("Location: login.php");
    exit;
}

// Fetch user data
$user = searchUser_bSession($db, $_COOKIE["user_session"]);
if (!$user) {
    header("Location: login.php");
    exit;
}

$userId = $user["id"];
$userName = $user["firstName"] . " " . $user["lastName"];
$profilePicture = $user["profilePicture"] ?? "default-avatar.png";

// Check if resource ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: resources.php?error=no_resource_specified");
    exit;
}

$resourceId = intval($_GET['id']);

// Fetch resource details with user info, like count, and download count
$stmt = $db->prepare("SELECT 
    r.*, 
    u.firstName, 
    u.lastName, 
    u.profilePicture,
    (SELECT COUNT(*) FROM resource_likes WHERE resource_id = r.id) as like_count,
    COALESCE(r.download_count, 0) as download_count
    FROM resources r
    LEFT JOIN user u ON r.user_id = u.id
    WHERE r.id = ?");
$stmt->bind_param("i", $resourceId);
$stmt->execute();
$resource = $stmt->get_result()->fetch_assoc();

// Check if resource exists
if (!$resource) {
    header("Location: resources.php?error=resource_not_found");
    exit;
}

// Check if user has liked this resource
$like_check = $db->prepare("SELECT id FROM resource_likes WHERE user_id = ? AND resource_id = ?");
$like_check->bind_param("ii", $userId, $resourceId);
$like_check->execute();
$hasLiked = ($like_check->get_result()->num_rows > 0);

// Check if user has purchased this resource (if premium)
$hasPurchased = false;
if ($resource['is_premium']) {
    $purchase_check = $db->prepare("SELECT id FROM resource_purchases 
                                  WHERE user_id = ? AND resource_id = ? AND status = 'completed'");
    $purchase_check->bind_param("ii", $userId, $resourceId);
    $purchase_check->execute();
    $hasPurchased = ($purchase_check->get_result()->num_rows > 0);
}

// Determine if download is allowed
$isOwner = ($resource['user_id'] == $userId);
$canDownload = $isOwner || !$resource['is_premium'] || $hasPurchased;

// Function to get file icon based on file type
function getFileIcon($fileType) {
    return match(strtolower($fileType)) {
        'pdf' => 'fa-file-pdf', 'doc', 'docx' => 'fa-file-word',
        'xls', 'xlsx' => 'fa-file-excel', 'ppt', 'pptx' => 'fa-file-powerpoint',
        'jpg', 'jpeg', 'png', 'gif' => 'fa-file-image', 'zip', 'rar' => 'fa-file-archive',
        'mp4', 'avi', 'mov' => 'fa-file-video', 'mp3', 'wav' => 'fa-file-audio',
        default => 'fa-file',
    };
}

function getFileColor($fileType) {
    return match(strtolower($fileType)) {
        'pdf' => 'red', 'doc', 'docx' => 'blue', 'xls', 'xlsx' => 'green',
        'ppt', 'pptx' => 'orange', 'jpg', 'jpeg', 'png', 'gif' => 'purple',
        'zip', 'rar' => 'teal', 'mp4', 'avi', 'mov' => 'pink', 'mp3', 'wav' => 'indigo',
        default => 'gray',
    };
}

// Handle Likes
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_like') {
    // Check existing like
    $check_like = $db->prepare("SELECT id FROM resource_likes WHERE user_id = ? AND resource_id = ?");
    $check_like->bind_param("ii", $userId, $resourceId);
    $check_like->execute();
    $result = $check_like->get_result();

    if ($result->num_rows > 0) {
        $unlike = $db->prepare("DELETE FROM resource_likes WHERE user_id = ? AND resource_id = ?");
        $unlike->bind_param("ii", $userId, $resourceId);
        $unlike->execute();
        $hasLiked = false;
    } else {
        $like = $db->prepare("INSERT INTO resource_likes (user_id, resource_id) VALUES (?, ?)");
        $like->bind_param("ii", $userId, $resourceId);
        $like->execute();
        $hasLiked = true;
    }

    // Get updated like count
    $count_likes = $db->prepare("SELECT COUNT(*) as count FROM resource_likes WHERE resource_id = ?");
    $count_likes->bind_param("i", $resourceId);
    $count_likes->execute();
    $resource['like_count'] = $count_likes->get_result()->fetch_assoc()['count'];
}

// Display error message if set
$error_message = '';
if (isset($_GET['error'])) {
    switch ($_GET['error']) {
        case 'premium_purchase_required':
            $error_message = 'This is a premium resource. Please purchase to download.';
            break;
        case 'payment_failed':
            $error_message = 'Payment processing failed. Please try again.';
            break;
        default:
            $error_message = 'An error occurred. Please try again.';
    }
}

// Display success message if set
$success_message = '';
if (isset($_GET['success'])) {
    switch ($_GET['success']) {
        case 'payment_completed':
            $success_message = 'Payment successful! You can now download this resource.';
            $hasPurchased = true;
            $canDownload = true;
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($resource['title']); ?> | ResourceHub</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Razorpay SDK -->
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <style>
        /* Base text size increase */
        html {
            font-size: 17px;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        h1 {
            font-size: 2.5rem !important;
        }
        
        h2 {
            font-size: 2rem !important;
        }
        
        h3 {
            font-size: 1.75rem !important;
        }
        
        h4 {
            font-size: 1.5rem !important;
        }
        
        p, label, input, select, button {
            font-size: 1.1rem !important;
        }
        
        .form-input {
            font-size: 1.1rem !important;
        }
        
        /* Premium badge */
        .premium-badge {
            background: linear-gradient(135deg, #ff9d00, #e3780c);
            color: white;
            border-radius: 50%;
            width: 55px;
            height: 55px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        /* Category and file type badge */
        .category-badge, .file-badge {
            display: inline-block;
            padding: 0.375rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            font-weight: 500;
            text-transform: uppercase;
        }
        
        /* Animation for buttons */
        .btn-animation {
            transition: all 0.3s ease;
        }
        
        .btn-animation:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        /* Resource details card hover */
        .resource-details-card {
            transition: all 0.3s ease;
        }
        
        .resource-details-card:hover {
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
    </style>
</head>
<body class="bg-gray-100">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full z-10">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="home.php" class="flex items-center">
                        <i class="fas fa-book-open text-indigo-600 text-3xl mr-2"></i>
                        <span class="text-2xl font-bold text-gray-800">ResourceHub</span>
                    </a>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="resources.php" class="text-gray-600 hover:text-indigo-600">
                        <i class="fas fa-search mr-1"></i> Browse Resources
                    </a>
                    <div class="relative group">
                        <button class="flex items-center space-x-2">
                            <img src="<?php echo $profilePicture; ?>" 
                                 alt="Profile" 
                                 class="w-10 h-10 rounded-full border-2 border-indigo-200">
                            <span class="text-gray-700 text-lg"><?php echo htmlspecialchars($userName); ?></span>
                        </button>
                        <div class="absolute right-0 w-56 mt-2 bg-white rounded-md shadow-lg hidden group-hover:block">
                            <a href="account.php" class="block px-4 py-3 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-user mr-2"></i> Account
                            </a>
                            <a href="my_resources.php" class="block px-4 py-3 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-file mr-2"></i> My Resources
                            </a>
                            <a href="downloads.php" class="block px-4 py-3 text-gray-700 hover:bg-gray-100">
                                <i class="fas fa-download mr-2"></i> Downloads
                            </a>
                            <a href="logout.php" class="block px-4 py-3 text-red-600 hover:bg-gray-100">
                                <i class="fas fa-sign-out-alt mr-2"></i> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="min-h-screen pt-20 pb-12">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            
            <!-- Error Message (if any) -->
            <?php if (!empty($error_message)): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-lg">
                <div class="flex items-center">
                    <div class="py-1">
                        <i class="fas fa-exclamation-circle text-red-500 text-2xl mr-4"></i>
                    </div>
                    <div>
                        <p class="font-bold text-lg">Error!</p>
                        <p><?php echo $error_message; ?></p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Success Message (if any) -->
            <?php if (!empty($success_message)): ?>
            <div id="successAlert" class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded-lg">
                <div class="flex items-center">
                    <div class="py-1">
                        <i class="fas fa-check-circle text-green-500 text-2xl mr-4"></i>
                    </div>
                    <div>
                        <p class="font-bold text-lg">Success!</p>
                        <p><?php echo $success_message; ?></p>
                    </div>
                    <button onclick="document.getElementById('successAlert').style.display='none'" class="ml-auto">
                        <i class="fas fa-times text-green-500"></i>
                    </button>
                </div>
            </div>
            <?php endif; ?>

            <!-- Resource Details -->
            <div class="bg-white rounded-xl shadow-md overflow-hidden mb-8 resource-details-card">
                <div class="relative">
                    <?php if ($resource['is_premium']): ?>
                    <div class="absolute top-4 right-4 premium-badge">
                        <i class="fas fa-crown"></i>
                    </div>
                    <?php endif; ?>
                    
                    <div class="p-8">
                        <div class="flex items-start justify-between mb-6">
                            <div>
                                <h1 class="text-3xl font-bold text-gray-800 mb-2">
                                    <?php echo htmlspecialchars($resource['title']); ?>
                                </h1>
                                <div class="flex items-center text-gray-500 space-x-4 mb-4">
                                    <span>
                                        <i class="far fa-calendar-alt mr-1"></i>
                                        <?php echo date('M d, Y', strtotime($resource['uploaded_at'] ?? $resource['created_at'])); ?>
                                    </span>
                                    <span>
                                        <i class="far fa-eye mr-1"></i>
                                        <?php echo number_format($resource['download_count']); ?> downloads
                                    </span>
                                    <span class="flex items-center">
                                        <i class="<?php echo $hasLiked ? 'fas' : 'far'; ?> fa-heart mr-1 <?php echo $hasLiked ? 'text-red-500' : 'text-gray-500'; ?>"></i>
                                        <span id="likeCount"><?php echo $resource['like_count']; ?></span> likes
                                    </span>
                                </div>
                                
                                <div class="flex flex-wrap gap-3 mb-6">
                                    <span class="category-badge bg-blue-100 text-blue-800">
                                        <?php echo htmlspecialchars($resource['category']); ?>
                                    </span>
                                    <span class="category-badge bg-purple-100 text-purple-800">
                                        <?php echo htmlspecialchars($resource['target_year']); ?>
                                    </span>
                                    <span class="file-badge" style="background-color: <?php echo getFileColor($resource['file_type']); ?>20; color: <?php echo getFileColor($resource['file_type']); ?>;">
                                        <i class="fas <?php echo getFileIcon($resource['file_type']); ?> mr-1"></i>
                                        <?php echo strtoupper(htmlspecialchars($resource['file_type'])); ?>
                                    </span>
                                </div>
                            </div>
                            
                            <div class="flex flex-col items-center">
                                <span class="text-5xl mb-2" style="color: <?php echo getFileColor($resource['file_type']); ?>">
                                    <i class="fas <?php echo getFileIcon($resource['file_type']); ?>"></i>
                                </span>
                                <?php if ($resource['is_premium'] && !$isOwner && !$hasPurchased): ?>
                                <span class="text-2xl font-bold text-indigo-600 mt-2">
                                    $<?php echo number_format($resource['price'], 2); ?>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="bg-gray-50 p-6 rounded-lg mb-8">
                            <h3 class="text-xl font-semibold text-gray-800 mb-3">Description</h3>
                            <p class="text-gray-700 whitespace-pre-line">
                                <?php echo htmlspecialchars($resource['description']); ?>
                            </p>
                        </div>
                        
                        <div class="flex items-center justify-between border-t border-gray-200 pt-6">
                            <div class="flex items-center">
                                <img src="<?php echo $resource['profilePicture'] ?? 'default-avatar.png'; ?>" 
                                     alt="Author" class="w-12 h-12 rounded-full mr-3">
                                <div>
                                    <p class="font-medium text-gray-800">
                                        <?php echo htmlspecialchars($resource['firstName'] . ' ' . $resource['lastName']); ?>
                                    </p>
                                    <p class="text-sm text-gray-500">Resource Author</p>
                                </div>
                            </div>
                            
                            <div class="flex items-center space-x-3">
                                <button id="likeButton" class="px-4 py-2 border border-gray-300 rounded-lg <?php echo $hasLiked ? 'bg-red-50 border-red-300 text-red-700' : 'bg-white text-gray-700'; ?> hover:bg-gray-50 transition duration-200 btn-animation">
                                    <i class="<?php echo $hasLiked ? 'fas' : 'far'; ?> fa-heart mr-1"></i>
                                    <?php echo $hasLiked ? 'Liked' : 'Like'; ?>
                                </button>
                                
                                <?php if ($canDownload): ?>
                                <a href="download.php?id=<?php echo $resourceId; ?>" 
                                   class="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition duration-200 btn-animation">
                                    <i class="fas fa-download mr-2"></i>Download
                                </a>
                                <?php elseif ($resource['is_premium'] && !$hasPurchased): ?>
                                <button id="purchaseButton" class="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition duration-200 btn-animation">
                                    <i class="fas fa-shopping-cart mr-2"></i>Purchase ($<?php echo number_format($resource['price'], 2); ?>)
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Related Resources Section -->
            <div class="mb-8">
                <h2 class="text-2xl font-bold text-gray-800 mb-6">Similar Resources</h2>
                
                <!-- This would be populated with related resources from the same category or author -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- This would be populated with PHP, showing similar resources -->
                    <div class="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition duration-200">
                        <div class="text-center p-12 text-gray-500">
                            <i class="fas fa-spinner fa-pulse text-4xl mb-4"></i>
                            <p>Loading similar resources...</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Back to Resources Button -->
            <div class="text-center">
                <a href="resources.php" class="inline-flex items-center px-6 py-3 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition duration-200 btn-animation">
                    <i class="fas fa-arrow-left mr-2"></i>Back to All Resources
                </a>
            </div>
        </div>
    </div>
    
    <script>
        // Like button functionality
        const likeButton = document.getElementById('likeButton');
        if (likeButton) {
            likeButton.addEventListener('click', async () => {
                try {
                    const response = await fetch('view_resource.php?id=<?php echo $resourceId; ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'action=toggle_like'
                    });
                    
                    // Reload the page to update UI
                    window.location.reload();
                } catch (error) {
                    console.error('Error:', error);
                }
            });
        }
        
        // Purchase button functionality (would connect to payment gateway)
        const purchaseButton = document.getElementById('purchaseButton');
        if (purchaseButton) {
            purchaseButton.addEventListener('click', () => {
                // Here you would implement your payment processing logic
                // For example, redirect to a payment gateway or show a payment modal
                alert('Payment processing would be implemented here');
                
                // For testing, you can redirect to simulate successful purchase
                // window.location.href = 'process_payment.php?resource_id=<?php echo $resourceId; ?>';
            });
        }
        
        // Auto-hide success message after 5 seconds
        const successAlert = document.getElementById('successAlert');
        if (successAlert) {
            setTimeout(() => {
                successAlert.style.opacity = '0';
                setTimeout(() => {
                    successAlert.style.display = 'none';
                }, 500);
            }, 5000);
        }
    </script>
</body>
</html>